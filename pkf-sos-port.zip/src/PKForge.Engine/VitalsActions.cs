using PKForge.Domain;
using PKHeX.Core;

namespace PKForge.Engine;

/// <summary>Current-condition edits for one Pokémon: heal, cure status, restore PP. Edits the session only.</summary>
public static class VitalsActions
{
    public enum Kind { HealAll, CureStatus, RestorePp }

    /// <summary>True when something changed. Boxed Pokémon keep no HP or status, so only PP applies to them.</summary>
    public static bool Apply(ISaveEngineSession session, int box, int slot, Kind kind)
    {
        if (session is not SaveEngineSession engine)
            throw new NotSupportedException("This game keeps its own format; healing is only available for stock games.");
        var save = engine.SaveFile;
        var pk = engine.GetEntity(box, slot);
        if (pk.Species == 0 || pk.IsEgg) return false;
        var candidate = pk.Clone();
        var party = box == -1;
        switch (kind)
        {
            case Kind.HealAll:
                if (party) candidate.Heal(); else candidate.HealPP();
                break;
            case Kind.CureStatus:
                if (!party) return false;
                candidate.Status_Condition = 0;
                break;
            case Kind.RestorePp:
                candidate.HealPP();
                break;
        }
        candidate.RefreshChecksum();
        if (candidate.Data.SequenceEqual(pk.Data)) return false;
        if (party) save.SetPartySlotAtIndex(candidate, slot, EntityImportSettings.None);
        else save.SetBoxSlotAtIndex(candidate, box, slot, EntityImportSettings.None);
        return true;
    }
}
