using PKForge.Domain;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;

namespace PKForge.Linux;

/// <summary>Colors and small builders shared by every screen. Sizes are generous: this is a touch screen.</summary>
internal static class Ui
{
    // The original's navy pixel-console palette: deck navy ground, cobalt panels, cyan focus.
    public static readonly FontFamily Font = new("avares://PKForge/Fonts/NDS12.ttf#NDS12, Noto Sans, sans-serif");
    public static IBrush Bg { get; private set; } = new SolidColorBrush(Color.Parse("#141B38"));
    public static IBrush Panel { get; private set; } = new SolidColorBrush(Color.Parse("#1F2D5A"));
    public static IBrush PanelHi { get; private set; } = new SolidColorBrush(Color.Parse("#2B4E95"));
    public static IBrush Edge { get; private set; } = new SolidColorBrush(Color.Parse("#4C7CC4"));
    public static IBrush Blue { get; private set; } = new SolidColorBrush(Color.Parse("#2789CD"));
    public static IBrush Accent { get; private set; } = new SolidColorBrush(Color.Parse("#42BFE8"));
    public static readonly IBrush Ink = new SolidColorBrush(Color.Parse("#F4F8FF"));
    public static readonly IBrush Dim = new SolidColorBrush(Color.Parse("#A8BADC"));
    public static readonly IBrush Warn = new SolidColorBrush(Color.Parse("#FFB454"));
    public static readonly IBrush Gold = new SolidColorBrush(Color.Parse("#FFD54F"));
    public static readonly IBrush Clear = new SolidColorBrush(Color.Parse("#00000000"));

    public sealed record Theme(string Name, string Bg, string Panel, string PanelHi, string Edge, string Blue, string Accent);

    public static readonly Theme[] Themes =
    [
        new("Navy", "#141B38", "#1F2D5A", "#2B4E95", "#4C7CC4", "#2789CD", "#42BFE8"),
        new("Crimson", "#2A1218", "#4A1F2B", "#8A2F45", "#C4607A", "#D13B5A", "#FF8FA8"),
        new("Forest", "#10241A", "#1B3D2B", "#2C6B49", "#5FA67A", "#2E9E5F", "#7BE0A0"),
        new("Violet", "#1D1536", "#32245C", "#55399A", "#8F72D6", "#7A4FD6", "#C3A6FF"),
        new("Sunset", "#2B1A10", "#4D2E1A", "#8F5328", "#D69458", "#E07B26", "#FFC27A"),
        new("Teal", "#0F2327", "#1A3F46", "#2A7080", "#55AFC2", "#1F9FB5", "#6EEAF5"),
        new("Rose", "#2B1426", "#4D2445", "#8A3F7D", "#CC78BE", "#D14FB0", "#FFA6E3"),
        new("Graphite", "#17181B", "#2A2C32", "#454955", "#7B8090", "#5B6275", "#AEB6CC"),
    ];

    public static string CurrentTheme { get; private set; } = "Navy";

    public static void Apply(string? name)
    {
        var t = Themes.FirstOrDefault(x => x.Name == name) ?? Themes[0];
        CurrentTheme = t.Name;
        IBrush B(string c) => new SolidColorBrush(Color.Parse(c));
        Bg = B(t.Bg); Panel = B(t.Panel); PanelHi = B(t.PanelHi); Edge = B(t.Edge); Blue = B(t.Blue); Accent = B(t.Accent);
    }

    public static TextBlock Text(string text, double size = 18, bool bold = false, IBrush? brush = null) => new()
    {
        Text = text,
        FontSize = size,
        FontWeight = bold ? FontWeight.Bold : FontWeight.Normal,
        Foreground = brush ?? Ink,
        TextWrapping = TextWrapping.Wrap,
    };

    private static readonly string[] TypeColors =
    [
        "#A8A77A", "#C22E28", "#A98FF3", "#A33EA1", "#E2BF65", "#B6A136",
        "#A6B91A", "#735797", "#B7B7CE", "#EE8130", "#6390F0", "#7AC74C",
        "#F7D02C", "#F95587", "#96D9D6", "#6F35FC", "#705746", "#D685AD",
    ];

    /// <summary>A coloured type plate like "GRASS" or "POISON".</summary>
    public static Control TypeBadge(int type)
    {
        var color = (uint)type < (uint)TypeColors.Length ? Color.Parse(TypeColors[type]) : Color.Parse("#68A090");
        var light = (0.299 * color.R + 0.587 * color.G + 0.114 * color.B) / 255 >= 0.58;
        return new Border
        {
            Background = new SolidColorBrush(color),
            CornerRadius = new Avalonia.CornerRadius(4),
            Padding = new Avalonia.Thickness(14, 3),
            Margin = new Avalonia.Thickness(0, 0, 8, 0),
            Child = Text(TypeFacts.Name(type).ToUpperInvariant(), 16, true, light ? new SolidColorBrush(Color.Parse("#1B2238")) : Ink),
        };
    }

    public static Button Btn(string text, Action onClick, bool primary = false)
    {
        var button = new Button
        {
            Content = text,
            FontSize = 20,
            MinHeight = 56,
            MinWidth = 120,
            Padding = new Avalonia.Thickness(20, 10),
            Background = primary ? Blue : PanelHi,
            BorderBrush = primary ? Accent : Edge,
            BorderThickness = new Avalonia.Thickness(2),
            Foreground = Ink,
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            CornerRadius = new Avalonia.CornerRadius(6),
        };
        button.Click += (_, _) => onClick();
        return button;
    }

    /// <summary>A controller button drawn like the Deck's: coloured round face buttons, pills for the rest.</summary>
    public static Control PadGlyph(string button)
    {
        var colour = button switch
        {
            "A" => "#3FA34D",
            "B" => "#D64545",
            "X" => "#2F7FD6",
            "Y" => "#D9A91C",
            _ => null,
        };
        if (colour is not null)
            return new Border
            {
                Width = 30,
                Height = 30,
                CornerRadius = new Avalonia.CornerRadius(15),
                Background = new SolidColorBrush(Color.Parse(colour)),
                BorderBrush = new SolidColorBrush(Color.Parse("#FFFFFF")),
                BorderThickness = new Avalonia.Thickness(1.5),
                Child = new TextBlock
                {
                    Text = button,
                    FontSize = 17,
                    FontWeight = FontWeight.Bold,
                    Foreground = new SolidColorBrush(Color.Parse("#FFFFFF")),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                },
            };
        return new Border
        {
            MinWidth = 38,
            Height = 28,
            CornerRadius = new Avalonia.CornerRadius(8),
            Background = PanelHi,
            BorderBrush = Edge,
            BorderThickness = new Avalonia.Thickness(1.5),
            Padding = new Avalonia.Thickness(8, 0),
            Child = new TextBlock
            {
                Text = button,
                FontSize = 15,
                FontWeight = FontWeight.Bold,
                Foreground = Ink,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            },
        };
    }

    public static Control PadHint(string button, string label)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, VerticalAlignment = VerticalAlignment.Center };
        row.Children.Add(PadGlyph(button));
        row.Children.Add(new TextBlock { Text = label, FontSize = 17, Foreground = Ink, VerticalAlignment = VerticalAlignment.Center });
        return row;
    }
}
