using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Mystery gifts: browse the real event distributions a save can receive. Pick a save, pick a card,
/// then either send the Pokémon to the Bank (touches no game file) or receive it straight into the game.
/// Receiving makes a restore point first and only changes the one box slot it fills.
/// </summary>
public sealed class EventsPage : IScreen
{
    private const int MaxRows = 80;

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;

    private DetectedSave? _save;
    private ISaveEngineSession? _session;
    private byte[] _bytes = [];
    private List<EventGift> _gifts = [];
    private string _search = "";
    private EventGift? _picked;
    private string _note = "";
    private bool _busy;

    public EventsPage(ContentControl host, SpriteStore sprites, Action close)
    {
        _host = host;
        _sprites = sprites;
        _close = close;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_picked is not null) { _picked = null; _note = ""; ShowGifts(); return; }
        if (_save is not null) { _save = null; _session = null; Start(); return; }
        _close();
    }

    // ───────────────────────── step 1: choose a save ─────────────────────────

    public void Start()
    {
        var list = new StackPanel { Spacing = 10 };
        list.Children.Add(Ui.Text("Which save should the gift be made for? Cards are matched to the game, so each game has its own list.", 18, false, Ui.Dim));
        var any = false;
        foreach (var save in Shelf.All.Where(s => s.Generation >= 4))
        {
            any = true;
            var chosen = save;
            var button = Ui.Btn($"{save.GameLabel}   ·   {save.TrainerName ?? "—"}", () => Open(chosen));
            button.HorizontalAlignment = HorizontalAlignment.Stretch;
            button.HorizontalContentAlignment = HorizontalAlignment.Left;
            list.Children.Add(button);
        }
        if (!any)
            list.Children.Add(Ui.Text("No Gen 4 or newer saves were found. Mystery gifts start at Gen 4 (Diamond/Pearl, HeartGold/SoulSilver and later). Add a folder on the home screen first.", 18, false, Ui.Warn));
        _host.Content = Frame("Mystery Gifts", new ScrollViewer { Content = list });
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Frame("Mystery Gifts", Ui.Text("Opening the card list…", 22));
        try
        {
            var data = (await Svc.Access.ReadAsync(save.DocumentId)).ToArray();
            var session = Svc.Engine.OpenSession(data, save.EngineHint, save.Format);
            var gifts = await Task.Run(() => Svc.Events.GetGifts(session).Where(g => g.Kind == EventGiftKind.Pokemon).ToList());
            _save = save;
            _session = session;
            _bytes = data;
            _gifts = gifts;
            _search = "";
            _picked = null;
            _note = "";
            ShowGifts();
        }
        catch (Exception error)
        {
            _host.Content = Frame("Mystery Gifts", Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    // ───────────────────────── step 2: the card list ─────────────────────────

    private void ShowGifts()
    {
        var search = new TextBox { Text = _search, MinHeight = 46, FontSize = 18, Margin = new Thickness(0, 0, 0, 10) };
        var rows = new StackPanel { Spacing = 6 };
        search.PropertyChanged += (_, e) =>
        {
            if (e.Property != TextBox.TextProperty) return;
            _search = search.Text ?? "";
            FillRows(rows);
        };
        FillRows(rows);

        var left = new DockPanel();
        var hint = Ui.Text($"{_save!.GameLabel}: {_gifts.Count} cards. Type a name to search.", 16, false, Ui.Dim);
        DockPanel.SetDock(hint, Dock.Top);
        left.Children.Add(hint);
        DockPanel.SetDock(search, Dock.Top);
        left.Children.Add(search);
        left.Children.Add(new ScrollViewer { Content = rows, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });

        var side = new Border
        {
            Width = 380,
            Padding = new Thickness(18),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = Detail() },
        };
        var body = new DockPanel();
        DockPanel.SetDock(side, Dock.Right);
        body.Children.Add(side);
        body.Children.Add(left);
        _host.Content = Frame("Mystery Gifts", body);
    }

    private void FillRows(StackPanel rows)
    {
        rows.Children.Clear();
        var terms = _search.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var matches = _gifts.Where(g =>
        {
            var hay = (Svc.SpeciesName(g.Species) + " " + g.Title + " " + g.Header + " " + (g.Details?.SourceFile ?? "")).ToLowerInvariant();
            return terms.All(t => hay.Contains(t.ToLowerInvariant()));
        }).ToList();

        foreach (var gift in matches.Take(MaxRows))
        {
            var chosen = gift;
            var line = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
            if (_sprites.GetFilled(new SpriteLook(gift.Species, gift.Details?.Form ?? 0, gift.Shiny)) is { } sprite)
                line.Children.Add(new Image { Source = sprite, Width = 64, Height = 64, Stretch = Stretch.Uniform });
            var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            text.Children.Add(Ui.Text((gift.Shiny ? "★ " : "") + Svc.SpeciesName(gift.Species) + "  Lv " + gift.Level, 18, true));
            text.Children.Add(Ui.Text(string.IsNullOrWhiteSpace(gift.Title) ? gift.Header : gift.Title, 14, false, Ui.Dim));
            line.Children.Add(text);
            var button = new Button
            {
                Content = line,
                MinHeight = 60,
                Padding = new Thickness(8, 4),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Background = _picked?.Id == gift.Id ? Ui.PanelHi : Ui.Panel,
                BorderBrush = _picked?.Id == gift.Id ? Ui.Accent : Ui.Clear,
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
            };
            button.Click += (_, _) => { _picked = chosen; _note = ""; ShowGifts(); };
            rows.Children.Add(button);
        }
        if (matches.Count == 0)
            rows.Children.Add(Ui.Text("No cards match.", 18, false, Ui.Dim));
        else if (matches.Count > MaxRows)
            rows.Children.Add(Ui.Text($"Showing {MaxRows} of {matches.Count}. Search to narrow it down.", 15, false, Ui.Dim));
    }

    // ───────────────────────── step 3: the card ─────────────────────────

    private Control Detail()
    {
        var panel = new StackPanel { Spacing = 8 };
        if (_picked is not { } gift)
        {
            panel.Children.Add(Ui.Text("Pick a card", 26, true));
            panel.Children.Add(Ui.Text("You will see what it gives (moves, ball, original trainer) before anything is sent anywhere.", 16, false, Ui.Dim));
            return panel;
        }

        var d = gift.Details;
        if (_sprites.GetFilled(new SpriteLook(gift.Species, d?.Form ?? 0, gift.Shiny)) is { } sprite)
            panel.Children.Add(new Image { Source = sprite, Width = 230, Height = 190, Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Center });
        panel.Children.Add(Ui.Text((gift.Shiny ? "★ " : "") + Svc.SpeciesName(gift.Species), 26, true));
        if (!string.IsNullOrWhiteSpace(gift.Title)) panel.Children.Add(Ui.Text(gift.Title, 17, false, Ui.Gold));

        void Fact(string label, string? value)
        {
            if (!string.IsNullOrWhiteSpace(value)) panel.Children.Add(Ui.Text($"{label}: {value}", 16));
        }
        Fact("Level", gift.Level.ToString());
        if (d is not null)
        {
            Fact("Original trainer", d.OriginalTrainer.Length > 0 ? $"{d.OriginalTrainer} ({d.TrainerId})" : "you (the receiving trainer)");
            Fact("Ball", d.BallName);
            Fact("Held item", d.HeldItemName);
            Fact("Met at", d.MetLocation);
            Fact("Date", d.Date?.ToString("d MMM yyyy"));
            Fact("Moves", string.Join(", ", d.Moves.Where(m => m.Length > 0)));
            Fact("Card", d.Format + (gift.Language == 0 ? "" : ""));
            if (d.IsEgg) panel.Children.Add(Ui.Text("This card gives an Egg.", 16, false, Ui.Warn));
        }

        var toBank = Ui.Btn("Send to the Bank", () => _ = ToBankAsync(gift), primary: true);
        var toGame = Ui.Btn("Receive into " + _save!.GameLabel, () => _ = ToGameAsync(gift));
        toBank.Margin = new Thickness(0, 10, 0, 0);
        panel.Children.Add(toBank);
        panel.Children.Add(toGame);
        if (_note.Length > 0) panel.Children.Add(Ui.Text(_note, 16, false, Ui.Warn));
        return panel;
    }

    private async Task ToBankAsync(EventGift gift)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            var added = await Task.Run(() =>
            {
                var export = Svc.Events.ExportEntity(_session!, gift.Id);
                if (export is null) return null;
                var info = Svc.Engine.TryDescribeEntity(export.Data, "Mystery Gift · " + gift.Title, export.Format);
                return info is null ? null : Svc.Bank.Add(export.Data, info);
            });
            _note = added is null ? "This card could not be converted for the Bank." : $"Sent to the Bank (box {added.Box + 1}). Nothing in your game was touched.";
        }
        catch (Exception error) { _note = "Could not send it: " + error.Message; }
        finally { _busy = false; }
        ShowGifts();
    }

    private async Task ToGameAsync(EventGift gift)
    {
        if (_busy || _save is null || _session is null) return;
        _busy = true;
        try
        {
            var save = _save;
            var snapshot = _session.Snapshot;
            var refusal = Svc.Writer.WhyWritesAreRefused(save.DocumentId, snapshot);
            if (refusal is not null) { _note = refusal; _busy = false; ShowGifts(); return; }

            var free = snapshot.Slots.FirstOrDefault(s => s.Box >= 0 && (s.Species ?? 0) == 0);
            if (free is null) { _note = "No empty box slot in this save. Make room first, or send it to the Bank instead."; _busy = false; ShowGifts(); return; }

            var outcome = Svc.Events.Receive(_session, gift.Id, free.Box, free.Slot);
            if (!outcome.Success) { _note = outcome.Message; _busy = false; ShowGifts(); return; }

            var current = await Svc.Access.ReadAsync(save.DocumentId);
            if (!current.Span.SequenceEqual(_bytes))
            {
                _note = "The save changed on disk since you opened it. Close the emulator and pick the save again.";
                _busy = false;
                ShowGifts();
                return;
            }
            var candidate = _session.Serialize();
            var receipt = await Svc.Writer.WriteScopedAsync(
                save.DocumentId, snapshot, candidate, WriteScope.Only(new SlotRef(free.Box, free.Slot)),
                "Received a mystery gift in PKForge");
            if (receipt.Changed) Svc.Sessions.MarkWritten(save.DocumentId, candidate);
            _note = $"Received! It is in box {free.Box + 1}, slot {free.Slot + 1}. A restore point was made first. Go back and pick the save again before the next gift.";
        }
        catch (Exception error) { _note = "Could not receive it: " + error.Message; }
        finally { _busy = false; }
        ShowGifts();
    }

    // ───────────────────────── layout ─────────────────────────

    private Control Frame(string title, Control body)
    {
        var back = Ui.Btn("‹ Back", Escape);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(back);
        header.Children.Add(Ui.Text(title, 32, true));
        DockPanel.SetDock(header, Dock.Top);
        var root = new DockPanel { Margin = new Thickness(24, 18) };
        root.Children.Add(header);
        root.Children.Add(body);
        return root;
    }
}
