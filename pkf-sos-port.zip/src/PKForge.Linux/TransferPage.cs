using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Send a Pokémon straight from one game to another. Pick the two saves, pick a Pokémon in the first, check the
/// preview (what the conversion changes and whether it stays legal), then Copy it or Move it. The target is
/// written with a restore point first; a Move only removes the original after the target write worked.
/// </summary>
public sealed class TransferPage : IScreen
{
    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;

    private DetectedSave? _from;
    private DetectedSave? _to;
    private Workbench? _bench;
    private int _box;
    private int _boxCount;
    private int _slot = -1;
    private bool _move;
    private TransferPreviewOutcome? _preview;
    private string _note = "";
    private bool _noteIsError;
    private bool _busy;
    private bool _picking = true;

    public TransferPage(ContentControl host, SpriteStore sprites, Action close, DetectedSave? from = null, int box = 0, int slot = -1)
    {
        _host = host;
        _sprites = sprites;
        _close = close;
        _from = from;
        _box = Math.Max(0, box);
        _slot = slot;
        _picking = from is null;
    }

    public IReadOnlyList<(string Button, string Label)> PadHints => _picking ? [] : [("L1 / R1", "Box")];

    public bool OnKey(Key key)
    {
        if (_picking || _bench is null || _busy) return false;
        if (key == Key.PageUp) { MoveBox(-1); return true; }
        if (key == Key.PageDown) { MoveBox(1); return true; }
        return false;
    }

    public void Escape()
    {
        if (_busy) return;
        if (!_picking && _preview is not null) { _preview = null; _note = ""; Render(); return; }
        if (!_picking && _from is not null) { _picking = true; _bench = null; _slot = -1; _preview = null; _note = ""; ShowPicker(); return; }
        _close();
    }

    public void Start()
    {
        if (_from is not null) _ = OpenSourceAsync();
        else ShowPicker();
    }

    // ───────────────────────── step 1: the two games ─────────────────────────

    private void ShowPicker()
    {
        _picking = true;
        var columns = new Grid { ColumnDefinitions = new ColumnDefinitions("*,*"), ColumnSpacing = 18 };
        var left = Column("From this game", _from, save => { _from = save; if (_to?.DocumentId == save.DocumentId) _to = null; ShowPicker(); });
        var right = Column("To this game", _to, save => { _to = save; ShowPicker(); }, exclude: _from);
        Grid.SetColumn(right, 1);
        columns.Children.Add(left);
        columns.Children.Add(right);

        var go = Ui.Btn("Choose a Pokémon ›", () => _ = OpenSourceAsync(), primary: true);
        go.IsEnabled = _from is not null && _to is not null;
        go.HorizontalAlignment = HorizontalAlignment.Right;
        go.Margin = new Thickness(0, 10, 0, 0);
        DockPanel.SetDock(go, Dock.Bottom);
        var body = new DockPanel();
        body.Children.Add(go);
        body.Children.Add(columns);
        _host.Content = Workbench.Frame("Transfer", Escape, body, "‹ Home");
    }

    private Control Column(string title, DetectedSave? selected, Action<DetectedSave> pick, DetectedSave? exclude = null)
    {
        var list = new StackPanel { Spacing = 8 };
        list.Children.Add(Ui.Text(title, 22, true, Ui.Gold));
        var any = false;
        foreach (var save in Shelf.All.Where(s => exclude is null || s.DocumentId != exclude.DocumentId))
        {
            any = true;
            var chosen = save;
            var on = selected is not null && selected.DocumentId == save.DocumentId;
            var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
            if (GameArtStore.Get(save.ArtLabel ?? save.GameLabel) is { } thumb)
                row.Children.Add(new Image { Source = thumb, Width = 48, Height = 48 });
            var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            text.Children.Add(Ui.Text(save.GameLabel.Replace("Pokémon ", ""), 18, true));
            text.Children.Add(Ui.Text(save.TrainerName ?? "", 14, false, Ui.Dim));
            row.Children.Add(text);
            var button = new Button
            {
                Content = row,
                MinHeight = 64,
                Padding = new Thickness(12, 6),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Background = on ? Ui.PanelHi : Ui.Panel,
                BorderBrush = on ? Ui.Accent : Ui.Edge,
                BorderThickness = new Thickness(on ? 3 : 2),
                CornerRadius = new CornerRadius(8),
            };
            button.Click += (_, _) => pick(chosen);
            list.Children.Add(button);
        }
        if (!any) list.Children.Add(Ui.Text("No other saves found. Add folders in Settings.", 16, false, Ui.Warn));
        return new ScrollViewer { Content = list, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
    }

    // ───────────────────────── step 2: pick the Pokémon ─────────────────────────

    private async Task OpenSourceAsync()
    {
        if (_from is null) return;
        _picking = false;
        _host.Content = Workbench.Frame("Transfer", Escape, Ui.Text("Opening the game…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(_from);
            _boxCount = Math.Max(1, _bench.Session.Snapshot.Slots.Where(s => s.Box >= 0).Select(s => s.Box + 1).DefaultIfEmpty(0).Max());
            _box = Math.Clamp(_box, 0, _boxCount - 1);
            _preview = null;
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _picking = true;
            _host.Content = Workbench.Frame("Transfer", ShowPicker, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private void MoveBox(int delta)
    {
        _box = (_box + delta + _boxCount) % _boxCount;
        _slot = -1;
        _preview = null;
        _note = "";
        Render();
    }

    private void Render()
    {
        var bench = _bench!;
        var session = bench.Session;

        // left half: the source box
        var left = new DockPanel();
        var prev = Ui.Btn("‹", () => MoveBox(-1));
        var next = Ui.Btn("›", () => MoveBox(1));
        prev.MinWidth = next.MinWidth = 64;
        prev.IsEnabled = next.IsEnabled = !_busy;
        string boxName;
        try { boxName = session.GetBoxName(_box); } catch (Exception) { boxName = "BOX"; }
        var title = Ui.Text($"{bench.Save.GameLabel.Replace("Pokémon ", "")} · Box {_box + 1}/{_boxCount} · {boxName}", 18, true);
        title.HorizontalAlignment = HorizontalAlignment.Center;
        title.VerticalAlignment = VerticalAlignment.Center;
        var nav = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
        DockPanel.SetDock(prev, Dock.Left);
        DockPanel.SetDock(next, Dock.Right);
        nav.Children.Add(prev);
        nav.Children.Add(next);
        nav.Children.Add(title);
        DockPanel.SetDock(nav, Dock.Top);
        left.Children.Add(nav);

        var grid = new UniformGrid { Columns = 6 };
        var slots = Math.Max(30, session.Snapshot.Slots.Count(s => s.Box == 0));
        for (var slot = 0; slot < slots; slot++) grid.Children.Add(Tile(session, slot));
        left.Children.Add(new ScrollViewer { Content = grid, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });

        var right = new Border
        {
            Width = 470,
            Margin = new Thickness(16, 0, 0, 0),
            Padding = new Thickness(18),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = RightPanel(), HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled },
        };
        var body = new DockPanel();
        DockPanel.SetDock(right, Dock.Right);
        body.Children.Add(right);
        body.Children.Add(left);
        _host.Content = Workbench.Frame("Transfer", Escape, body, "‹ Back");
    }

    private Control Tile(ISaveEngineSession session, int slot)
    {
        Control content = new Panel();
        var empty = true;
        try
        {
            var d = session.ReadEntity(_box, slot);
            empty = d.IsEmpty;
            if (!d.IsEmpty && _sprites.GetFilled(d.Look) is { } sprite)
                content = new Image { Source = sprite, Stretch = Stretch.Uniform, Margin = new Thickness(0) };
        }
        catch (Exception) { }
        var on = slot == _slot;
        var button = new Button
        {
            Content = content,
            Height = 84,
            Margin = new Thickness(2),
            Padding = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Background = on ? Ui.PanelHi : Ui.Bg,
            BorderBrush = on ? Ui.Accent : Ui.Clear,
            BorderThickness = new Thickness(3),
            CornerRadius = new CornerRadius(6),
            IsEnabled = !empty && !_busy,
        };
        button.Click += (_, _) => { _slot = slot; _preview = null; _note = ""; Render(); };
        return button;
    }

    // ───────────────────────── the right half ─────────────────────────

    private Control RightPanel()
    {
        var bench = _bench!;
        var panel = new StackPanel { Spacing = 10 };

        // the chosen Pokémon
        EntityDetail? detail = null;
        if (_slot >= 0)
        {
            try { detail = bench.Session.ReadEntity(_box, _slot); } catch (Exception) { }
            if (detail is { IsEmpty: true }) detail = null;
        }
        if (detail is null)
        {
            panel.Children.Add(Ui.Text("Pick a Pokémon", 24, true));
            panel.Children.Add(Ui.Text("Tap one in the box on the left.", 16, false, Ui.Dim));
        }
        else
        {
            var head = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
            if (_sprites.GetFilled(detail.Look) is { } sprite)
                head.Children.Add(new Image { Source = sprite, Width = 112, Height = 112, Stretch = Stretch.Uniform });
            var info = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            var name = string.IsNullOrWhiteSpace(detail.Nickname) ? detail.SpeciesName : detail.Nickname;
            info.Children.Add(Ui.Text(name, 24, true));
            info.Children.Add(Ui.Text($"{detail.SpeciesName} · Lv {detail.Level}", 16, false, Ui.Dim));
            head.Children.Add(info);
            panel.Children.Add(head);
        }

        // the destination
        panel.Children.Add(Ui.Text("Send to", 20, true, Ui.Gold));
        if (_to is null)
        {
            panel.Children.Add(Column("", _to, save => { _to = save; _preview = null; Render(); }, exclude: _from));
        }
        else
        {
            panel.Children.Add(Ui.Text(_to.GameLabel + (string.IsNullOrEmpty(_to.TrainerName) ? "" : " · " + _to.TrainerName), 18, true));
            var change = Ui.Btn("Change game", () => { _to = null; _preview = null; _note = ""; Render(); });
            change.MinHeight = 44; change.FontSize = 16;
            change.HorizontalAlignment = HorizontalAlignment.Left;
            panel.Children.Add(change);
        }

        if (detail is not null && _to is not null)
        {
            var mode = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
            var copy = Ui.Btn("Copy", () => { _move = false; Render(); }, primary: !_move);
            var move = Ui.Btn("Move", () => { _move = true; Render(); }, primary: _move);
            copy.MinWidth = move.MinWidth = 0; copy.MinHeight = move.MinHeight = 46; copy.FontSize = move.FontSize = 17;
            move.IsEnabled = bench.Refusal is null;
            mode.Children.Add(copy);
            mode.Children.Add(move);
            panel.Children.Add(mode);
            panel.Children.Add(Ui.Text(_move
                ? "Move: it is removed from the first game after the second one has it."
                : "Copy: it stays in the first game too.", 14, false, Ui.Dim));
            if (bench.Refusal is not null)
                panel.Children.Add(Ui.Text("Move is off for this game: " + bench.Refusal, 14, false, Ui.Warn));

            if (_preview is null)
            {
                var check = Ui.Btn("Check it", () => _ = PreviewAsync(), primary: true);
                check.IsEnabled = !_busy;
                panel.Children.Add(check);
            }
            else
            {
                panel.Children.Add(PreviewView(_preview));
            }
        }

        if (_busy) panel.Children.Add(Ui.Text("Working…", 16, false, Ui.Gold));
        else if (_note.Length > 0) panel.Children.Add(Ui.Text(_note, 16, false, _noteIsError ? Ui.Warn : Ui.Gold));
        return panel;
    }

    private Control PreviewView(TransferPreviewOutcome outcome)
    {
        var panel = new StackPanel { Spacing = 8 };
        if (!outcome.Success || outcome.Preview is null)
        {
            panel.Children.Add(Ui.Text(outcome.Message, 17, false, Ui.Warn));
            return panel;
        }
        var preview = outcome.Preview;
        panel.Children.Add(Ui.Text(outcome.Message, 17, true));
        panel.Children.Add(Ui.Text(preview.Verdict, 17, true, preview.Legality == TransferLegality.Legal ? Ui.Gold : Ui.Warn));
        void Lines(string heading, IReadOnlyList<string> lines, IBrush? brush = null)
        {
            if (lines.Count == 0) return;
            panel.Children.Add(Ui.Text(heading, 16, true, brush));
            foreach (var line in lines.Take(12)) panel.Children.Add(Ui.Text("• " + line, 14));
        }
        Lines("What changes", preview.Changes);
        Lines("Warnings", preview.Warnings, Ui.Warn);
        Lines("Legality notes", preview.LegalityLines);
        panel.Children.Add(Ui.Text("A restore point is made first. Close the emulator before you confirm.", 14, false, Ui.Dim));
        var go = Ui.Btn(_move ? "Move it" : "Copy it", () => _ = SendAsync(), primary: true);
        go.IsEnabled = !_busy;
        panel.Children.Add(go);
        return panel;
    }

    // ───────────────────────── doing it ─────────────────────────

    private (byte[] Data, string? Format, string Name)? Pokemon()
    {
        var bench = _bench!;
        var d = bench.Session.ReadEntity(_box, _slot);
        if (d.IsEmpty) return null;
        var export = bench.Session.ExportSlot(_box, _slot);
        var name = string.IsNullOrWhiteSpace(d.Nickname) ? d.SpeciesName : d.Nickname;
        return (export.Data, export.Format, name);
    }

    private async Task PreviewAsync()
    {
        if (_bench is null || _to is null || _slot < 0 || _busy) return;
        _busy = true; _note = ""; Render();
        try
        {
            var mon = Pokemon();
            if (mon is null) { _note = "That slot is empty."; _noteIsError = true; }
            else _preview = await Svc.Transfers.PreviewAsync(mon.Value.Data, mon.Value.Name, _to, CancellationToken.None, mon.Value.Format);
        }
        catch (Exception error) { _note = "Could not check: " + error.Message; _noteIsError = true; }
        _busy = false;
        Render();
    }

    private async Task SendAsync()
    {
        if (_bench is null || _to is null || _from is null || _slot < 0 || _busy) return;
        _busy = true; _note = ""; Render();
        try
        {
            var mon = Pokemon();
            if (mon is null) throw new InvalidOperationException("That slot is empty.");
            var (data, format, name) = mon.Value;
            var outcome = await Svc.Transfers.SendToGameAsync(data, name, _to, CancellationToken.None, format);
            if (!outcome.Success)
            {
                _note = "Nothing was changed. " + outcome.Message;
                _noteIsError = true;
            }
            else
            {
                _note = outcome.Message + " ";
                _noteIsError = false;
                if (_move)
                {
                    try
                    {
                        await Svc.Transfers.ReleaseFromGameAsync(_from, [new SlotRef(_box, _slot)], $"{name} moved to {_to.GameLabel}");
                        _note += "It has been taken out of " + _from.GameLabel.Replace("Pokémon ", "") + ".";
                    }
                    catch (Exception error)
                    {
                        _note += "But it could not be removed from the first game (" + error.Message + "), so it is in both places.";
                        _noteIsError = true;
                    }
                }
                else _note += "The original is untouched.";
                _slot = -1;
                _preview = null;
                try { await _bench.ReloadAsync(); } catch (Exception) { }
            }
        }
        catch (Exception error)
        {
            _note = "Nothing was changed: " + error.Message;
            _noteIsError = true;
        }
        _busy = false;
        Render();
    }
}
