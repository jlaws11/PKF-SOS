using System.Runtime.InteropServices;

namespace PKForge.Linux;

/// <summary>
/// Windows game controllers (Xbox pads and anything that shows up as one) through XInput.
/// Raises <see cref="Pressed"/> on a background thread, with held directions repeating like the Linux reader.
/// </summary>
internal sealed class XInputPad
{
    public event Action<PadButton>? Pressed;

    [StructLayout(LayoutKind.Sequential)]
    private struct Gamepad
    {
        public ushort Buttons;
        public byte LeftTrigger;
        public byte RightTrigger;
        public short ThumbLX;
        public short ThumbLY;
        public short ThumbRX;
        public short ThumbRY;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct State
    {
        public uint PacketNumber;
        public Gamepad Pad;
    }

    [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")]
    private static extern uint GetState14(uint user, out State state);

    [DllImport("xinput9_1_0.dll", EntryPoint = "XInputGetState")]
    private static extern uint GetState910(uint user, out State state);

    private static bool _use910;

    private static uint GetState(uint user, out State state)
    {
        if (!_use910)
        {
            try { return GetState14(user, out state); }
            catch (DllNotFoundException) { _use910 = true; }
            catch (EntryPointNotFoundException) { _use910 = true; }
        }
        return GetState910(user, out state);
    }

    private readonly CancellationTokenSource _cts = new();

    public void Start() => _ = Task.Factory.StartNew(Poll, TaskCreationOptions.LongRunning);

    public void Stop() => _cts.Cancel();

    private void Poll()
    {
        var previous = new ushort[4];
        PadButton? held = null;
        var heldSince = DateTime.UtcNow;
        var lastRepeat = DateTime.UtcNow;
        var firstGone = false;

        while (!_cts.IsCancellationRequested)
        {
            try
            {
                var names = new List<string>();
                PadButton? direction = null;
                for (uint user = 0; user < 4; user++)
                {
                    State state;
                    try
                    {
                        if (GetState(user, out state) != 0) { previous[user] = 0; continue; }
                    }
                    catch (Exception)
                    {
                        if (!firstGone) { GamepadInput.Note("XInput is not available on this machine"); firstGone = true; }
                        Thread.Sleep(2000);
                        continue;
                    }
                    names.Add($"XInput controller {user + 1} (connected)");
                    var b = state.Pad.Buttons;
                    var fresh = (ushort)(b & ~previous[user]);
                    previous[user] = b;

                    void Press(ushort mask, PadButton button)
                    {
                        if ((fresh & mask) == 0) return;
                        GamepadInput.Note("pad button " + button + " (xinput " + (user + 1) + ")");
                        Pressed?.Invoke(button);
                    }
                    Press(0x1000, PadButton.A);
                    Press(0x2000, PadButton.B);
                    Press(0x4000, PadButton.X);
                    Press(0x8000, PadButton.Y);
                    Press(0x0100, PadButton.L1);
                    Press(0x0200, PadButton.R1);
                    Press(0x0020, PadButton.Select);
                    Press(0x0010, PadButton.Start);

                    var x = state.Pad.ThumbLX;
                    var y = state.Pad.ThumbLY;
                    if ((b & 0x0001) != 0) direction ??= PadButton.Up;
                    else if ((b & 0x0002) != 0) direction ??= PadButton.Down;
                    else if ((b & 0x0004) != 0) direction ??= PadButton.Left;
                    else if ((b & 0x0008) != 0) direction ??= PadButton.Right;
                    else if (Math.Abs((int)y) > 16000 && Math.Abs((int)y) >= Math.Abs((int)x)) direction ??= y > 0 ? PadButton.Up : PadButton.Down;
                    else if (Math.Abs((int)x) > 16000) direction ??= x < 0 ? PadButton.Left : PadButton.Right;
                }
                if (names.Count > 0) GamepadInput.Devices = [.. names];
                else GamepadInput.Devices = ["No XInput controller connected."];

                var now = DateTime.UtcNow;
                if (direction != held)
                {
                    held = direction;
                    heldSince = lastRepeat = now;
                    if (direction is { } d) Pressed?.Invoke(d);
                }
                else if (direction is { } d2 && (now - heldSince).TotalMilliseconds > 380 && (now - lastRepeat).TotalMilliseconds > 110)
                {
                    lastRepeat = now;
                    Pressed?.Invoke(d2);
                }
            }
            catch (Exception error)
            {
                Services.AppPaths.LogCrash("xinput: " + error.Message);
                Thread.Sleep(2000);
            }
            Thread.Sleep(16);
        }
    }
}
