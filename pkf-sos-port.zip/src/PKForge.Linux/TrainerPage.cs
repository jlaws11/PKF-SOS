using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The trainer card: name, IDs, gender, money, play time, and (where the game keeps them) Battle Points and coins.
/// Nothing is written until Save; Save makes a restore point first.
/// </summary>
public sealed class TrainerPage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;
    private readonly SpriteStore _sprites;
    private readonly AppSettings _settings;

    private Workbench? _bench;
    private string _note = "";
    private bool _noteIsError;

    private TextBox _name = null!, _tid = null!, _sid = null!, _money = null!, _hours = null!, _minutes = null!, _bp = null!, _coins = null!;
    private int _gender;

        private readonly DetectedSave? _preset;

    public TrainerPage(ContentControl host, SpriteStore sprites, AppSettings settings, Action close, DetectedSave? preset = null)
    {
        _settings = settings;
        _sprites = sprites;
        _host = host;
        _close = close;
        _preset = preset;
    }

    private TrainerStats? _stats;

    public IReadOnlyList<(string Button, string Label)> PadHints => _bench is null ? [] : [("X", "Save")];

    public bool OnKey(Key key)
    {
        if (key == Key.X && _bench is { Refusal: null } && _stats is not null) { _ = SaveAsync(_stats); return true; }
        return false;
    }

    public void Escape()
    {
        if (_bench is null) { _close(); return; }
        _bench = null;
        if (_preset is not null) { _close(); return; }
        Start();
    }

    public void Start()
    {
        if (_preset is not null) { Open(_preset); return; }
        _host.Content = Workbench.Frame("Trainer Card", _close,
            Workbench.SavePicker("Which save's trainer card do you want to edit?", _ => true,
                "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Trainer Card", Escape, Ui.Text("Opening the trainer card…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            _note = _bench.Refusal ?? "";
            _noteIsError = _bench.Refusal is not null;
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Trainer Card", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private TextBox Box(string text, bool enabled = true) => new()
    {
        Text = text,
        FontSize = 20,
        MinHeight = 50,
        MinWidth = 260,
        IsEnabled = enabled,
        VerticalContentAlignment = VerticalAlignment.Center,
    };

    private void Render()
    {
        var bench = _bench!;
        var session = bench.Session;
        var trainer = session.GetTrainer();
        var stats = session.GetTrainerStats();
        _stats = stats;
        var editable = bench.Refusal is null;
        _gender = trainer.Gender;

        _name = Box(trainer.Name, editable);
        _tid = Box(trainer.TID.ToString(), editable);
        _sid = Box(trainer.SID.ToString(), editable);
        _money = Box(trainer.Money.ToString(), editable);
        _hours = Box(stats.PlayTimeHours.ToString(), editable);
        _minutes = Box(stats.PlayTimeMinutes.ToString(), editable);
        _bp = Box(stats.BP.ToString(), editable);
        _coins = Box(stats.Coins.ToString(), editable);

        var form = new StackPanel { Spacing = 10, MaxWidth = 720 };
        form.Children.Add(ProfileCard(bench, session, trainer, stats));
        void Row(string label, Control field, string? hint = null)
        {
            var row = new DockPanel { Margin = new Thickness(0, 2) };
            var text = Ui.Text(label, 20);
            text.Width = 220;
            text.VerticalAlignment = VerticalAlignment.Center;
            DockPanel.SetDock(text, Dock.Left);
            row.Children.Add(text);
            var right = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
            right.Children.Add(field);
            if (hint is not null)
            {
                var h = Ui.Text(hint, 14, false, Ui.Dim);
                h.VerticalAlignment = VerticalAlignment.Center;
                right.Children.Add(h);
            }
            row.Children.Add(right);
            form.Children.Add(row);
        }

        Row("Name", _name);
        Row("Trainer ID (TID)", _tid, "0 to 65535");
        Row("Secret ID (SID)", _sid, "0 to 65535");

        var genderRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        Button male = null!, female = null!;
        void PaintGender()
        {
            male.Background = _gender == 0 ? Ui.Blue : Ui.PanelHi;
            female.Background = _gender == 1 ? Ui.Blue : Ui.PanelHi;
        }
        male = Ui.Btn("Boy", () => { _gender = 0; PaintGender(); });
        female = Ui.Btn("Girl", () => { _gender = 1; PaintGender(); });
        male.IsEnabled = female.IsEnabled = editable;
        male.MinWidth = female.MinWidth = 110;
        genderRow.Children.Add(male);
        genderRow.Children.Add(female);
        PaintGender();
        Row("Gender", genderRow);

        Row("Money", _money);
        if (stats.SupportsPlayTime)
        {
            Row("Play time hours", _hours, $"0 to {stats.PlayTimeHoursMax}");
            Row("Play time minutes", _minutes, "0 to 59");
        }
        if (stats.SupportsBP) Row("Battle Points", _bp, $"0 to {stats.BPMax}");
        if (stats.SupportsCoins) Row("Coins", _coins, $"0 to {stats.CoinsMax}");

        form.Children.Add(Ui.Text(
            "Changing the name or IDs does not change Pokémon you already own: they keep their original trainer.", 15, false, Ui.Dim));

        var save = Ui.Btn("Save to the game", () => _ = SaveAsync(stats), primary: true);
        save.IsEnabled = editable;
        save.HorizontalAlignment = HorizontalAlignment.Left;
        form.Children.Add(save);
        form.Children.Add(Ui.Text(_note, 16, false, _noteIsError ? Ui.Warn : Ui.Gold));

        _host.Content = Workbench.Frame($"Trainer Card · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape,
            new ScrollViewer { Content = form, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });
    }

    /// <summary>The card's header: game cover, the lead party Pokémon as the profile picture, and the name with its ID.</summary>
    private Control ProfileCard(Workbench bench, ISaveEngineSession session, TrainerInfo trainer, TrainerStats stats)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 18 };
        if (GameArtStore.Get(bench.Save.ArtLabel ?? bench.Save.GameLabel) is { } cover)
            row.Children.Add(new Image { Source = cover, Width = 96, Height = 96, Stretch = Stretch.Uniform });

        EntityDetail? lead = null;
        try { var d = session.ReadEntity(-1, 0); if (!d.IsEmpty) lead = d; } catch (Exception) { }
        IImage? picture = null;
        var custom = _settings.Avatars.TryGetValue(bench.Save.DocumentId, out var avatarPath) && File.Exists(avatarPath);
        if (custom)
        {
            try
            {
                using var stream = File.OpenRead(avatarPath!);
                picture = Bitmap.DecodeToWidth(stream, 320);
            }
            catch (Exception) { custom = false; }
        }
        if (picture is null && lead is not null) picture = _sprites.Get(lead.Look);
        if (picture is not null)
        {
            var frame = new Border
            {
                Width = 120, Height = 120,
                Background = Ui.Bg,
                BorderBrush = Ui.Accent,
                BorderThickness = new Thickness(3),
                CornerRadius = new CornerRadius(60),
                ClipToBounds = true,
                Child = new Image
                {
                    Source = picture,
                    Stretch = custom ? Stretch.UniformToFill : Stretch.Uniform,
                    Margin = custom ? new Thickness(0) : new Thickness(10),
                },
            };
            row.Children.Add(frame);
        }

        var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Spacing = 2 };
        text.Children.Add(Ui.Text(trainer.Name, 30, true));
        text.Children.Add(Ui.Text($"ID No. {trainer.TID:00000}", 18, false, Ui.Gold));
        text.Children.Add(Ui.Text(bench.Save.GameLabel.Replace("Pokémon ", ""), 16, false, Ui.Dim));
        if (stats.SupportsPlayTime)
            text.Children.Add(Ui.Text($"Play time {stats.PlayTimeHours}:{stats.PlayTimeMinutes:00}", 16, false, Ui.Dim));
        if (lead is not null)
            text.Children.Add(Ui.Text($"Lead: {lead.SpeciesName} Lv {lead.Level}", 16, false, Ui.Dim));
        var pictureButtons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, Margin = new Thickness(0, 8, 0, 0) };
        var choose = Ui.Btn("Choose picture…", () => _ = ChoosePictureAsync(bench.Save.DocumentId));
        choose.MinWidth = 0; choose.MinHeight = 40; choose.FontSize = 14; choose.Padding = new Thickness(10, 2);
        pictureButtons.Children.Add(choose);
        if (custom)
        {
            var reset = Ui.Btn("Use lead Pokémon", () => { _settings.Avatars.Remove(bench.Save.DocumentId); SettingsStore.Save(_settings); Render(); });
            reset.MinWidth = 0; reset.MinHeight = 40; reset.FontSize = 14; reset.Padding = new Thickness(10, 2);
            pictureButtons.Children.Add(reset);
        }
        text.Children.Add(pictureButtons);
        row.Children.Add(text);
        return new Border
        {
            Background = Ui.Panel,
            BorderBrush = Ui.Edge,
            BorderThickness = new Thickness(2),
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(18),
            Margin = new Thickness(0, 0, 0, 10),
            Child = row,
        };
    }

    private async Task ChoosePictureAsync(string documentId)
    {
        try
        {
            var top = TopLevel.GetTopLevel(_host);
            if (top is null) return;
            var picked = await top.StorageProvider.OpenFilePickerAsync(new Avalonia.Platform.Storage.FilePickerOpenOptions
            {
                Title = "Choose a picture for the trainer card",
                AllowMultiple = false,
                FileTypeFilter = [Avalonia.Platform.Storage.FilePickerFileTypes.ImageAll],
            });
            if (picked.Count == 0 || picked[0].TryGetLocalPath() is not { } source) return;

            var folder = Path.Combine(AppPaths.DataDir, "avatars");
            Directory.CreateDirectory(folder);
            var hash = Convert.ToHexString(System.Security.Cryptography.SHA1.HashData(System.Text.Encoding.UTF8.GetBytes(documentId)))[..16];
            var target = Path.Combine(folder, hash + Path.GetExtension(source).ToLowerInvariant());
            File.Copy(source, target, overwrite: true);
            // Make sure it decodes before we commit to it.
            using (var test = File.OpenRead(target)) _ = Bitmap.DecodeToWidth(test, 64);
            _settings.Avatars[documentId] = target;
            SettingsStore.Save(_settings);
            _note = "Picture set.";
            _noteIsError = false;
        }
        catch (Exception error)
        {
            _note = "Could not use that picture: " + error.Message;
            _noteIsError = true;
        }
        Render();
    }

    private bool Fail(string message)
    {
        _note = message;
        _noteIsError = true;
        return false;
    }

    private async Task SaveAsync(TrainerStats stats)
    {
        var bench = _bench;
        if (bench is null) return;
        try
        {
            var name = (_name.Text ?? "").Trim();
            if (name.Length == 0) { Fail("The name cannot be empty."); Render(); return; }
            if (!int.TryParse(_tid.Text?.Trim(), out var tid) || tid is < 0 or > 65535) { Fail("The Trainer ID must be a number from 0 to 65535."); Render(); return; }
            if (!int.TryParse(_sid.Text?.Trim(), out var sid) || sid is < 0 or > 65535) { Fail("The Secret ID must be a number from 0 to 65535."); Render(); return; }
            if (!uint.TryParse(_money.Text?.Trim(), out var money)) { Fail("Money must be a whole number."); Render(); return; }

            bench.Session.SetTrainer(new TrainerInfo(name, tid, sid, money, _gender));

            int? Num(TextBox box, bool supported)
            {
                if (!supported) return null;
                if (!int.TryParse(box.Text?.Trim(), out var value) || value < 0)
                    throw new InvalidOperationException("Play time, Battle Points and coins must be whole numbers.");
                return value;
            }
            bench.Session.SetTrainerStats(new TrainerStatsEdit(
                Num(_hours, stats.SupportsPlayTime), Num(_minutes, stats.SupportsPlayTime),
                Num(_bp, stats.SupportsBP), Num(_coins, stats.SupportsCoins)));

            _note = await bench.CommitAsync("Edited the trainer card in PKForge");
            _noteIsError = false;
        }
        catch (Exception error)
        {
            // An edit that failed half-way must not ride along with the next save.
            try { await bench.ReloadAsync(); } catch (Exception) { }
            _note = "Could not save: " + error.Message;
            _noteIsError = true;
        }
        Render();
    }
}
