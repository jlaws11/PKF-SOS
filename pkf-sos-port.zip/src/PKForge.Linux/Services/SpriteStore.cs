using Avalonia.Media.Imaging;
using PKForge.Domain;

namespace PKForge.Linux.Services;

/// <summary>Loads the bundled PKHeX sprites from assets/, using the same candidate order as the Android app.</summary>
public sealed class SpriteStore
{
    private readonly string _root = Path.Combine(AppContext.BaseDirectory, "assets");
    private readonly Dictionary<string, Bitmap?> _cache = [];

    public Bitmap? Get(SpriteLook look)
    {
        if (_cache.TryGetValue(look.CacheKey, out var cached)) return cached;
        Bitmap? bitmap = null;
        foreach (var candidate in SpriteCatalog.BundledCandidates(look))
        {
            var path = Path.Combine(_root, candidate.Path);
            if (!File.Exists(path)) continue;
            try
            {
                bitmap = new Bitmap(path);
                break;
            }
            catch (Exception) { /* a broken file falls through to the next candidate */ }
        }
        _cache[look.CacheKey] = bitmap;
        return bitmap;
    }

    private readonly Dictionary<string, Bitmap?> _filled = [];

    /// <summary>
    /// The sprite trimmed to its visible pixels so it fills whatever box it is drawn in. Small
    /// Pokémon are enlarged more than big ones (the crop never gets smaller than a minimum size),
    /// so size differences still show but nothing is lost in a corner of an empty canvas.
    /// </summary>
    public Bitmap? GetFilled(SpriteLook look)
    {
        if (_filled.TryGetValue(look.CacheKey, out var cached)) return cached;
        Bitmap? result = null;
        try
        {
            foreach (var candidate in SpriteCatalog.BundledCandidates(look))
            {
                var path = Path.Combine(_root, candidate.Path);
                if (!File.Exists(path)) continue;
                using var source = SkiaSharp.SKBitmap.Decode(path);
                if (source is null) continue;
                result = source.Width <= 100 ? Trim(source) : new Bitmap(path);
                break;
            }
        }
        catch (Exception) { result = null; }
        result ??= Get(look);
        _filled[look.CacheKey] = result;
        return result;
    }

    private static Bitmap? Trim(SkiaSharp.SKBitmap source)
    {
        int minX = source.Width, minY = source.Height, maxX = -1, maxY = -1;
        for (var y = 0; y < source.Height; y++)
            for (var x = 0; x < source.Width; x++)
                if (source.GetPixel(x, y).Alpha > 20)
                {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
        if (maxX < 0) return null;
        const int MinW = 40, MinH = 34;
        var cw = Math.Max(maxX - minX + 3, MinW);
        var ch = Math.Max(maxY - minY + 3, MinH);
        var x0 = (minX + maxX + 1) / 2 - cw / 2;
        var y0 = (minY + maxY + 1) / 2 - ch / 2;
        using var cropped = new SkiaSharp.SKBitmap(cw, ch, SkiaSharp.SKColorType.Rgba8888, SkiaSharp.SKAlphaType.Premul);
        using (var canvas = new SkiaSharp.SKCanvas(cropped))
        {
            canvas.Clear(SkiaSharp.SKColors.Transparent);
            canvas.DrawBitmap(source, -x0, -y0);
        }
        using var image = SkiaSharp.SKImage.FromBitmap(cropped);
        using var data = image.Encode(SkiaSharp.SKEncodedImageFormat.Png, 100);
        using var stream = new MemoryStream(data.ToArray());
        return new Bitmap(stream);
    }
}
