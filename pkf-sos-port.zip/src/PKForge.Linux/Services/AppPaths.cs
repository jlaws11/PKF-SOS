namespace PKForge.Linux.Services;

public static class AppPaths
{
    public static string Home => Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

    /// <summary>Settings and crash notes live here (~/.local/share/PKForge).</summary>
    public static string DataDir
    {
        get
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PKForge");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    /// <summary>Reads a whole file even while an emulator has it open (Windows refuses a plain read then).</summary>
    public static byte[] ReadShared(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }

    /// <summary>Where restore points are kept, for messages shown to the player.</summary>
    public static string BackupsHint => Path.Combine(DataDir, "backups");

    public static void LogCrash(string text)
    {
        try { File.AppendAllText(Path.Combine(DataDir, "crash.log"), $"[{DateTime.Now:O}] {text}\n\n"); }
        catch (Exception) { /* nowhere left to report to */ }
    }
}
