using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;

namespace PKForge.Linux;

/// <summary>Colors and small builders shared by every screen. Sizes are generous: this is a touch screen.</summary>
internal static class Ui
{
    public static readonly IBrush Bg = new SolidColorBrush(Color.Parse("#1E2327"));
    public static readonly IBrush Panel = new SolidColorBrush(Color.Parse("#2A3138"));
    public static readonly IBrush PanelHi = new SolidColorBrush(Color.Parse("#3A4651"));
    public static readonly IBrush Accent = new SolidColorBrush(Color.Parse("#D64545"));
    public static readonly IBrush Ink = new SolidColorBrush(Color.Parse("#FFFFFF"));
    public static readonly IBrush Dim = new SolidColorBrush(Color.Parse("#9AA7B2"));
    public static readonly IBrush Warn = new SolidColorBrush(Color.Parse("#FFB454"));
    public static readonly IBrush Gold = new SolidColorBrush(Color.Parse("#FFD54F"));
    public static readonly IBrush Clear = new SolidColorBrush(Color.Parse("#00000000"));

    public static TextBlock Text(string text, double size = 18, bool bold = false, IBrush? brush = null) => new()
    {
        Text = text,
        FontSize = size,
        FontWeight = bold ? FontWeight.Bold : FontWeight.Normal,
        Foreground = brush ?? Ink,
        TextWrapping = TextWrapping.Wrap,
    };

    public static Button Btn(string text, Action onClick, bool primary = false)
    {
        var button = new Button
        {
            Content = text,
            FontSize = 20,
            MinHeight = 56,
            MinWidth = 120,
            Padding = new Avalonia.Thickness(20, 10),
            Background = primary ? Accent : PanelHi,
            Foreground = Ink,
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            CornerRadius = new Avalonia.CornerRadius(10),
        };
        button.Click += (_, _) => onClick();
        return button;
    }
}
