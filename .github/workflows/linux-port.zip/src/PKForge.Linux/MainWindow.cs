using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Stage 1 of the Linux port: point the app at a folder, see the saves in it, open one and browse its boxes.
/// Read-only: nothing here ever writes to a save file.
/// </summary>
public sealed class MainWindow : Window
{
    private static readonly (string Label, int Kind)[] KindChoices =
    [
        ("Auto-detect (recommended)", -1),
        ("RetroArch (GBA / GB / DS saves)", (int)EmulatorKind.RetroArch),
        ("Azahar / Citra (3DS)", (int)EmulatorKind.Azahar),
        ("melonDS (DS)", (int)EmulatorKind.MelonDS),
    ];

    private readonly ISaveEngine _engine = new SaveEngine();
    private readonly IGameDataService _data = new GameDataService();
    private readonly LinuxEmulatorScanner _scanner;
    private readonly SpriteStore _sprites = new();
    private readonly AppSettings _settings = SettingsStore.Load();
    private readonly ContentControl _host = new();

    private CancellationTokenSource? _scanCts;
    private Action? _back;
    private Func<Key, bool>? _keys;

    private List<DetectedSave> _lastSaves = [];
    private string _status = "";
    private TextBlock _statusBlock = new();
    private StackPanel _resultsPanel = new();
    private TextBox _pathBox = new();
    private ComboBox _kindBox = new();

    public MainWindow()
    {
        _scanner = new LinuxEmulatorScanner(_engine);
        Title = "PKForge";
        Width = 1280;
        Height = 800;
        MinWidth = 800;
        MinHeight = 500;
        Background = Ui.Bg;
        Content = _host;
        KeyDown += OnKeyDown;
        ShowHome();
    }

    private void OnKeyDown(object? sender, KeyEventArgs e)
    {
        if (_keys?.Invoke(e.Key) == true)
        {
            e.Handled = true;
            return;
        }
        if (e.Key == Key.Escape && _back is not null)
        {
            _back();
            e.Handled = true;
        }
    }

    // ─────────────────────────────── Home ───────────────────────────────

    private void ShowHome()
    {
        _back = null;
        _keys = null;

        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 18 };
        root.Children.Add(Ui.Text("PKForge", 42, true));
        root.Children.Add(Ui.Text("Linux preview · view-only. Your save files are never changed.", 18, false, Ui.Dim));

        if (_settings.Folders.Count > 0)
        {
            root.Children.Add(Ui.Text("Your folders", 24, true));
            foreach (var folder in _settings.Folders.ToList())
                root.Children.Add(FolderRow(folder));
        }

        root.Children.Add(Ui.Text("Add a folder that has your saves", 24, true));
        _pathBox = new TextBox
        {
            Text = DefaultFolder(),
            FontSize = 20,
            MinHeight = 56,
            VerticalContentAlignment = VerticalAlignment.Center,
        };
        var browse = Ui.Btn("Browse…", () => _ = BrowseAsync());
        browse.Margin = new Thickness(12, 0, 0, 0);
        DockPanel.SetDock(browse, Dock.Right);
        var pathRow = new DockPanel { LastChildFill = true };
        pathRow.Children.Add(browse);
        pathRow.Children.Add(_pathBox);
        root.Children.Add(pathRow);

        var suggestions = SuggestedFolders().ToList();
        if (suggestions.Count > 0)
        {
            root.Children.Add(Ui.Text("Folders found on this device (tap one to use it):", 16, false, Ui.Dim));
            var chips = new WrapPanel();
            foreach (var path in suggestions)
            {
                var chip = Ui.Btn(path.Replace(AppPaths.Home, "~"), () => _pathBox.Text = path);
                chip.MinHeight = 44;
                chip.FontSize = 16;
                chip.Margin = new Thickness(0, 0, 10, 10);
                chips.Children.Add(chip);
            }
            root.Children.Add(chips);
        }

        root.Children.Add(Ui.Text("What kind of saves are in it?", 16, false, Ui.Dim));
        _kindBox = new ComboBox
        {
            ItemsSource = KindChoices.Select(k => k.Label).ToList(),
            SelectedIndex = 0,
            FontSize = 20,
            MinHeight = 56,
            HorizontalAlignment = HorizontalAlignment.Stretch,
        };
        root.Children.Add(_kindBox);
        root.Children.Add(Ui.Btn("Add folder and scan", () => _ = AddFolderAsync(), primary: true));

        _statusBlock = Ui.Text(_status, 18, false, Ui.Warn);
        root.Children.Add(_statusBlock);
        _resultsPanel = new StackPanel { Spacing = 12 };
        root.Children.Add(_resultsPanel);
        RenderResults();

        _host.Content = new ScrollViewer
        {
            Content = root,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        };
    }

    private static string DefaultFolder()
    {
        var desktop = Path.Combine(AppPaths.Home, "Desktop");
        return Directory.Exists(desktop) ? desktop : AppPaths.Home;
    }

    /// <summary>Places where Steam Deck emulator setups usually keep saves; only ones that exist are offered.</summary>
    private static IEnumerable<string> SuggestedFolders()
    {
        var home = AppPaths.Home;
        string[] candidates =
        [
            Path.Combine(home, "Desktop"),
            Path.Combine(home, "Emulation", "saves"),
            Path.Combine(home, "Emulation", "saves", "retroarch", "saves"),
            Path.Combine(home, ".local", "share", "azahar-emu"),
            Path.Combine(home, ".var", "app", "org.azahar_emu.Azahar", "data", "azahar-emu"),
            Path.Combine(home, ".config", "retroarch", "saves"),
            Path.Combine(home, ".var", "app", "org.libretro.RetroArch", "config", "retroarch", "saves"),
        ];
        return candidates.Where(Directory.Exists);
    }

    private Control FolderRow(WatchedFolder folder)
    {
        var kindText = folder.Kind < 0
            ? "Auto-detect"
            : KindChoices.FirstOrDefault(k => k.Kind == folder.Kind).Label ?? "Custom";

        var info = new StackPanel { Spacing = 2, VerticalAlignment = VerticalAlignment.Center };
        info.Children.Add(Ui.Text(folder.Path.Replace(AppPaths.Home, "~"), 20, true));
        info.Children.Add(Ui.Text(kindText, 15, false, Ui.Dim));

        var scan = Ui.Btn("Scan", () => _ = ScanAsync(folder), primary: true);
        scan.Margin = new Thickness(10, 0, 0, 0);
        var remove = Ui.Btn("Remove", () =>
        {
            _settings.Folders.Remove(folder);
            SettingsStore.Save(_settings);
            ShowHome();
        });
        remove.Margin = new Thickness(10, 0, 0, 0);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal };
        buttons.Children.Add(scan);
        buttons.Children.Add(remove);
        DockPanel.SetDock(buttons, Dock.Right);

        var row = new DockPanel { LastChildFill = true };
        row.Children.Add(buttons);
        row.Children.Add(info);

        return new Border
        {
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Padding = new Thickness(18, 12),
            Child = row,
        };
    }

    private async Task BrowseAsync()
    {
        try
        {
            var picked = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            {
                Title = "Choose the folder with your saves",
                AllowMultiple = false,
            });
            if (picked.Count > 0 && picked[0].TryGetLocalPath() is { } path)
                _pathBox.Text = path;
        }
        catch (Exception error)
        {
            SetStatus("The folder chooser could not open (" + error.Message + "). Type the path instead.");
        }
    }

    private async Task AddFolderAsync()
    {
        var path = (_pathBox.Text ?? "").Trim();
        if (path.StartsWith('~'))
            path = Path.Combine(AppPaths.Home, path.TrimStart('~').TrimStart('/'));
        if (!Directory.Exists(path))
        {
            SetStatus("That folder doesn't exist: " + path);
            return;
        }

        var kind = KindChoices[Math.Max(0, _kindBox.SelectedIndex)].Kind;
        var existing = _settings.Folders.FirstOrDefault(f => f.Path == path);
        if (existing is null)
        {
            existing = new WatchedFolder { Path = path, Kind = kind };
            _settings.Folders.Add(existing);
        }
        else
        {
            existing.Kind = kind;
        }
        SettingsStore.Save(_settings);
        ShowHome();
        await ScanAsync(existing);
    }

    private async Task ScanAsync(WatchedFolder folder)
    {
        _scanCts?.Cancel();
        _scanCts = new CancellationTokenSource();
        var token = _scanCts.Token;

        _lastSaves = [];
        _resultsPanel.Children.Clear();
        SetStatus("Scanning " + folder.Path.Replace(AppPaths.Home, "~") + " …");
        try
        {
            EmulatorKind? kind = folder.Kind < 0 ? null : (EmulatorKind)folder.Kind;
            var report = await _scanner.ScanAsync(folder.Path, kind, token);
            if (token.IsCancellationRequested) return;

            _lastSaves = report.Saves;
            if (report.Saves.Count > 0)
            {
                SetStatus($"Found {report.Saves.Count} save(s). Tap one to open it.");
            }
            else
            {
                var why = $"No saves found. Looked at {report.FilesSeen} file(s).";
                if (report.Rejected.Count > 0)
                    why += " These looked like saves but could not be read: " + string.Join(", ", report.Rejected.Take(5)) + ".";
                if (report.Log.Count > 0)
                    why += " " + report.Log[^1];
                SetStatus(why);
            }
            RenderResults();
        }
        catch (OperationCanceledException)
        {
            // a newer scan replaced this one
        }
        catch (Exception error)
        {
            SetStatus("Scan failed: " + error.Message);
        }
    }

    private void SetStatus(string text)
    {
        _status = text;
        _statusBlock.Text = text;
    }

    private void RenderResults()
    {
        _resultsPanel.Children.Clear();
        foreach (var save in _lastSaves)
            _resultsPanel.Children.Add(SaveCard(save));
    }

    private Control SaveCard(DetectedSave save)
    {
        var parts = new[]
        {
            save.TrainerName,
            save.PlayTime,
            save.Generation > 0 ? $"Gen {save.Generation}" : null,
        };
        var line = string.Join(" · ", parts.Where(p => !string.IsNullOrWhiteSpace(p)));
        var where = (save.FolderHint is null ? "" : save.FolderHint + "/") + save.FileName;

        var text = new StackPanel { Spacing = 4 };
        text.Children.Add(Ui.Text(save.GameLabel, 24, true));
        if (line.Length > 0) text.Children.Add(Ui.Text(line, 18, false, Ui.Dim));
        text.Children.Add(Ui.Text(where, 14, false, Ui.Dim));

        var button = new Button
        {
            Content = text,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Left,
            Padding = new Thickness(20, 14),
            MinHeight = 88,
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
        };
        button.Click += (_, _) => OpenSave(save);
        return button;
    }

    // ─────────────────────────────── Save viewer ───────────────────────────────

    private void OpenSave(DetectedSave save)
    {
        SaveSnapshot snapshot;
        try
        {
            var bytes = File.ReadAllBytes(save.DocumentId);
            snapshot = _engine.Open(bytes, save.EngineHint);
        }
        catch (Exception error)
        {
            SetStatus("Could not open that save: " + error.Message);
            return;
        }
        ShowSave(save, snapshot);
    }

    private string SpeciesName(int species) =>
        species >= 0 && species < _data.SpeciesNames.Count && _data.SpeciesNames[species].Length > 0
            ? _data.SpeciesNames[species]
            : "#" + species;

    private void ShowSave(DetectedSave save, SaveSnapshot snapshot)
    {
        var boxes = snapshot.Slots
            .GroupBy(s => s.Box)
            .OrderBy(g => g.Key)
            .Select(g => g.OrderBy(s => s.Slot).ToList())
            .ToList();
        if (boxes.Count == 0)
        {
            SetStatus("This save has no boxes to show.");
            return;
        }

        _back = ShowHome;
        var boxIndex = 0;
        SlotSummary? selected = null;

        var grid = new UniformGrid { Columns = 6 };
        var detail = new StackPanel { Spacing = 10 };
        var boxLabel = Ui.Text("", 24, true);
        boxLabel.HorizontalAlignment = HorizontalAlignment.Center;
        boxLabel.VerticalAlignment = VerticalAlignment.Center;

        void RenderBox()
        {
            boxLabel.Text = $"Box {boxIndex + 1} of {boxes.Count}";
            grid.Children.Clear();
            foreach (var slot in boxes[boxIndex])
            {
                var current = slot;
                var isSelected = selected is { } s && s.Box == current.Box && s.Slot == current.Slot;
                grid.Children.Add(SlotTile(current, isSelected, () =>
                {
                    selected = current;
                    RenderBox();
                    RenderDetail();
                }));
            }
        }

        void RenderDetail()
        {
            detail.Children.Clear();
            var slot = selected;
            if (slot is null || slot.Species is not int species || species <= 0)
            {
                detail.Children.Add(Ui.Text("Tap a Pokémon to see it here.", 20, false, Ui.Dim));
                return;
            }

            var sprite = _sprites.Get(slot.Look);
            if (sprite is not null)
            {
                detail.Children.Add(new Image
                {
                    Source = sprite,
                    Width = 220,
                    Height = 180,
                    Stretch = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
            }
            detail.Children.Add(Ui.Text(SpeciesName(species), 30, true));
            if (!string.IsNullOrEmpty(slot.Nickname))
                detail.Children.Add(Ui.Text("Nickname: " + slot.Nickname, 20));
            if (slot.Form > 0)
                detail.Children.Add(Ui.Text("Form " + slot.Form, 18, false, Ui.Dim));
            if (slot.IsShiny)
                detail.Children.Add(Ui.Text("★ Shiny", 20, true, Ui.Gold));
            if (slot.IsEgg)
                detail.Children.Add(Ui.Text("Egg", 20, false, Ui.Dim));
            if (!slot.IsLegal)
                detail.Children.Add(Ui.Text("Not legal according to the checker", 18, false, Ui.Warn));
            detail.Children.Add(Ui.Text($"Box {slot.Box + 1}, slot {slot.Slot + 1}", 16, false, Ui.Dim));
        }

        void Go(int delta)
        {
            boxIndex = (boxIndex + delta + boxes.Count) % boxes.Count;
            selected = null;
            RenderBox();
            RenderDetail();
        }

        _keys = key =>
        {
            switch (key)
            {
                case Key.Left:
                case Key.PageUp:
                    Go(-1);
                    return true;
                case Key.Right:
                case Key.PageDown:
                    Go(1);
                    return true;
                default:
                    return false;
            }
        };

        // header
        var back = Ui.Btn("‹ Back", ShowHome);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var titles = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        titles.Children.Add(Ui.Text(save.GameLabel, 28, true));
        titles.Children.Add(Ui.Text($"{save.TrainerName} · {save.PlayTime} · Generation {snapshot.Generation}", 16, false, Ui.Dim));
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(back);
        header.Children.Add(titles);
        DockPanel.SetDock(header, Dock.Top);

        // box picker
        var prev = Ui.Btn("‹ Prev", () => Go(-1));
        DockPanel.SetDock(prev, Dock.Left);
        var next = Ui.Btn("Next ›", () => Go(1));
        DockPanel.SetDock(next, Dock.Right);
        var nav = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        nav.Children.Add(prev);
        nav.Children.Add(next);
        nav.Children.Add(boxLabel);
        DockPanel.SetDock(nav, Dock.Top);

        // details
        var detailBorder = new Border
        {
            Width = 380,
            Padding = new Thickness(20),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = detail,
        };
        DockPanel.SetDock(detailBorder, Dock.Right);

        var root = new DockPanel { Margin = new Thickness(24) };
        root.Children.Add(header);
        root.Children.Add(nav);
        root.Children.Add(detailBorder);
        root.Children.Add(grid);

        RenderBox();
        RenderDetail();
        _host.Content = root;
    }

    private Control SlotTile(SlotSummary slot, bool selected, Action onTap)
    {
        var content = new Grid();
        if (slot.Species is int species && species > 0)
        {
            var sprite = _sprites.Get(slot.Look);
            if (sprite is not null)
            {
                content.Children.Add(new Image
                {
                    Source = sprite,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(4),
                });
            }
            else
            {
                var name = Ui.Text(SpeciesName(species), 13, false, Ui.Dim);
                name.HorizontalAlignment = HorizontalAlignment.Center;
                name.VerticalAlignment = VerticalAlignment.Center;
                content.Children.Add(name);
            }

            if (slot.IsShiny)
            {
                var star = Ui.Text("★", 18, true, Ui.Gold);
                star.HorizontalAlignment = HorizontalAlignment.Right;
                star.VerticalAlignment = VerticalAlignment.Top;
                star.Margin = new Thickness(0, 2, 6, 0);
                content.Children.Add(star);
            }
            if (!slot.IsLegal)
            {
                var warn = Ui.Text("!", 18, true, Ui.Warn);
                warn.HorizontalAlignment = HorizontalAlignment.Left;
                warn.VerticalAlignment = VerticalAlignment.Top;
                warn.Margin = new Thickness(6, 2, 0, 0);
                content.Children.Add(warn);
            }
        }

        var button = new Button
        {
            Content = content,
            Height = 92,
            Margin = new Thickness(3),
            Padding = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalContentAlignment = VerticalAlignment.Stretch,
            Background = selected ? Ui.PanelHi : Ui.Panel,
            BorderBrush = selected ? Ui.Accent : Ui.Clear,
            BorderThickness = new Thickness(selected ? 3 : 1),
            CornerRadius = new CornerRadius(8),
        };
        button.Click += (_, _) => onTap();
        return button;
    }
}
