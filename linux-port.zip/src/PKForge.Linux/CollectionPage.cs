using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The collection dex: every species you own anywhere (all your saves and the Bank) and every one you
/// still need, a generation at a time. Tap a species to see where your copies are and where to get it.
/// Read-only: nothing here writes to any file.
/// </summary>
public sealed class CollectionPage : IScreen
{
    private const int Columns = 8;

    private sealed record Copy(string Where, bool Shiny, int Form, DetectedSave? Save, int Box, int Slot, Guid? BankId);

    private enum Filter { All, Owned, Missing, Shiny }

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;
    private readonly Action<EditTarget, Action<bool>> _openEditor;

    private readonly Dictionary<int, List<Copy>> _owned = [];
    private CollectionDexProgress _progress = null!;
    private List<string> _notes = [];
    private int _gen = 1;
    private Filter _filter = Filter.All;
    private int? _selected;
    private int _lookupToken;

    public CollectionPage(ContentControl host, SpriteStore sprites, Action<EditTarget, Action<bool>> openEditor, Action close)
    {
        _openEditor = openEditor;
        _host = host;
        _sprites = sprites;
        _close = close;
    }

    public void Escape() => _close();

    public bool OnKey(Key key)
    {
        switch (key)
        {
            case Key.Left:
            case Key.PageUp:
                ChangeGen(-1);
                return true;
            case Key.Right:
            case Key.PageDown:
                ChangeGen(1);
                return true;
            default:
                return false;
        }
    }

    private void ChangeGen(int delta)
    {
        if (_progress is null) return;
        _gen = (_gen - 1 + delta + 9) % 9 + 1;
        _selected = null;
        Render();
    }

    // ───────────────────────── loading ─────────────────────────

    public async void Start()
    {
        _host.Content = Frame("Collection", Ui.Text("Reading your saves and the Bank…", 22));
        _owned.Clear();
        _notes = [];
        try
        {
            var progress = new Progress<string>(line => _host.Content = Frame("Collection", Ui.Text(line, 22)));
            var shelf = await Shelf.ReadAsync(progress, CancellationToken.None);

            foreach (var source in shelf.Sources)
            {
                if (source.Exclusion is LivingDexExclusion.RomHack)
                {
                    _notes.Add($"{source.Label} is a ROM hack, so it is not counted.");
                    continue;
                }
                if (source.Exclusion is LivingDexExclusion.Unreadable)
                {
                    _notes.Add($"{source.Label} could not be read, so it is not counted.");
                    continue;
                }
                foreach (var holding in source.Holdings)
                {
                    if (holding.IsEgg) continue;
                    var place = holding.IsParty
                        ? $"{source.Label} party"
                        : $"{source.Label} · box {holding.Box + 1}, slot {holding.Slot + 1}";
                    if (!_owned.TryGetValue(holding.Species, out var list))
                        _owned[holding.Species] = list = [];
                    list.Add(new Copy(place, holding.Shiny, holding.Form,
                        shelf.Saves.GetValueOrDefault(source.Id), holding.Box, holding.Slot, holding.BankId));
                }
            }

            _progress = CollectionDex.Compute(
                _owned.SelectMany(p => p.Value.Select(c => (p.Key, c.Shiny))),
                CollectionDex.MaxSpecies, Svc.Data.SpeciesNames);
            Render();
        }
        catch (Exception error)
        {
            _host.Content = Frame("Collection", Ui.Text("Could not read your collection: " + error.Message, 20, false, Ui.Warn));
        }
    }

    // ───────────────────────── the dex ─────────────────────────

    private bool Owns(int species) => _owned.ContainsKey(species);
    private bool OwnsShiny(int species) => _owned.TryGetValue(species, out var l) && l.Any(c => c.Shiny);

    private bool Shown(int species) => _filter switch
    {
        Filter.Owned => Owns(species),
        Filter.Missing => !Owns(species),
        Filter.Shiny => OwnsShiny(species),
        _ => true,
    };

    private void Render()
    {
        var progress = _progress;
        var body = new DockPanel();

        // summary
        var summary = Ui.Text(
            $"{progress.Owned} of {progress.TotalSpecies} species owned  ·  ★ {progress.Shiny} shiny", 22, true,
            progress.Owned == progress.TotalSpecies ? Ui.Gold : Ui.Ink);
        DockPanel.SetDock(summary, Dock.Top);
        body.Children.Add(summary);

        // generation tabs
        var tabs = new WrapPanel { Margin = new Thickness(0, 10, 0, 0) };
        foreach (var segment in progress.Segments)
        {
            var generation = segment.Generation;
            var tab = Ui.Btn($"Gen {generation} · {segment.Owned}/{segment.Total}", () =>
            {
                _gen = generation;
                _selected = null;
                Render();
            }, primary: generation == _gen);
            tab.MinWidth = 0;
            tab.MinHeight = 46;
            tab.FontSize = 16;
            tab.Padding = new Thickness(12, 4);
            tab.Margin = new Thickness(0, 0, 8, 8);
            tabs.Children.Add(tab);
        }
        DockPanel.SetDock(tabs, Dock.Top);
        body.Children.Add(tabs);

        // filters
        var filters = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, Margin = new Thickness(0, 0, 0, 10) };
        foreach (var (label, value) in new[] { ("All", Filter.All), ("Owned", Filter.Owned), ("Missing", Filter.Missing), ("★ Shiny", Filter.Shiny) })
        {
            var chosen = value;
            var chip = Ui.Btn(label, () =>
            {
                _filter = chosen;
                Render();
            }, primary: chosen == _filter);
            chip.MinWidth = 0;
            chip.MinHeight = 44;
            chip.FontSize = 16;
            chip.Padding = new Thickness(14, 4);
            filters.Children.Add(chip);
        }
        DockPanel.SetDock(filters, Dock.Top);
        body.Children.Add(filters);

        // the grid for this generation
        var (_, first, last) = CollectionDex.GenRanges[_gen - 1];
        var grid = new UniformGrid { Columns = Columns };
        var shown = 0;
        for (var id = first; id <= last; id++)
        {
            if (id >= Svc.Data.SpeciesNames.Count || Svc.Data.SpeciesNames[id].Length == 0) continue;
            if (!Shown(id)) continue;
            grid.Children.Add(Tile(id));
            shown++;
        }
        var gridHost = new StackPanel();
        gridHost.Children.Add(grid);
        if (shown == 0)
            gridHost.Children.Add(Ui.Text(_filter == Filter.Missing ? "You have every species in this generation!" : "Nothing to show here.", 20, false, Ui.Dim));
        foreach (var note in _notes)
            gridHost.Children.Add(Ui.Text(note, 14, false, Ui.Dim));

        // the side panel
        var side = new Border
        {
            Width = 360,
            Padding = new Thickness(18),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = Detail() },
        };
        DockPanel.SetDock(side, Dock.Right);
        body.Children.Add(side);
        body.Children.Add(new ScrollViewer
        {
            Content = gridHost,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        });

        _host.Content = Frame("Collection", body);
    }

    private Control Tile(int species)
    {
        var owned = Owns(species);
        var content = new Grid();
        if (_sprites.Get(new SpriteLook(species, 0, false)) is { } sprite)
        {
            content.Children.Add(new Image
            {
                Source = sprite,
                Stretch = Stretch.Uniform,
                Margin = new Thickness(4, 4, 4, 14),
                Opacity = owned ? 1.0 : 0.22,
            });
        }
        var number = Ui.Text($"#{species:000}", 12, false, owned ? Ui.Ink : Ui.Dim);
        number.HorizontalAlignment = HorizontalAlignment.Center;
        number.VerticalAlignment = VerticalAlignment.Bottom;
        content.Children.Add(number);
        if (OwnsShiny(species))
        {
            var star = Ui.Text("★", 16, true, Ui.Gold);
            star.HorizontalAlignment = HorizontalAlignment.Right;
            star.VerticalAlignment = VerticalAlignment.Top;
            star.Margin = new Thickness(0, 1, 5, 0);
            content.Children.Add(star);
        }

        var chosen = _selected == species;
        var button = new Button
        {
            Content = content,
            Height = 96,
            Margin = new Thickness(3),
            Padding = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalContentAlignment = VerticalAlignment.Stretch,
            Background = chosen ? Ui.PanelHi : Ui.Panel,
            BorderBrush = chosen ? Ui.Accent : Ui.Clear,
            BorderThickness = new Thickness(chosen ? 3 : 1),
            CornerRadius = new CornerRadius(8),
        };
        button.Click += (_, _) =>
        {
            _selected = species;
            Render();
        };
        return button;
    }

    // ───────────────────────── side panel ─────────────────────────

    private Control Detail()
    {
        var panel = new StackPanel { Spacing = 8 };
        if (_selected is not { } species)
        {
            var (_, first, last) = CollectionDex.GenRanges[_gen - 1];
            var segment = _progress.Segments[_gen - 1];
            panel.Children.Add(Ui.Text($"Generation {_gen}", 26, true));
            panel.Children.Add(Ui.Text($"#{first:000} to #{last:000}", 16, false, Ui.Dim));
            panel.Children.Add(Ui.Text($"{segment.Owned} of {segment.Total} owned", 20));
            panel.Children.Add(Ui.Text($"{segment.Shiny} shiny", 20, false, Ui.Gold));
            panel.Children.Add(Ui.Text("Tap a species to see where your copies are and where you can get it. Faded ones are the species you still need.", 16, false, Ui.Dim));
            return panel;
        }

        if (_sprites.Get(new SpriteLook(species, 0, false)) is { } sprite)
        {
            panel.Children.Add(new Image
            {
                Source = sprite,
                Width = 200,
                Height = 170,
                Stretch = Stretch.Uniform,
                Opacity = Owns(species) ? 1.0 : 0.4,
                HorizontalAlignment = HorizontalAlignment.Center,
            });
        }
        panel.Children.Add(Ui.Text($"{Svc.SpeciesName(species)}  #{species:000}", 26, true));

        if (_owned.TryGetValue(species, out var copies))
        {
            panel.Children.Add(Ui.Text($"You own {copies.Count}:", 20, true, Ui.Gold));
            foreach (var copy in copies.Take(14))
            {
                var row = new DockPanel { Margin = new Thickness(0, 2) };
                var edit = Ui.Btn("Edit", () => _ = EditAsync(copy));
                edit.MinWidth = 0;
                edit.MinHeight = 40;
                edit.FontSize = 15;
                edit.Padding = new Thickness(12, 2);
                edit.IsEnabled = copy.BankId is not null || (copy.Save is not null && copy.Box >= 0);
                DockPanel.SetDock(edit, Dock.Right);
                row.Children.Add(edit);
                var label = Ui.Text((copy.Shiny ? "★ " : "• ") + copy.Where, 15);
                label.VerticalAlignment = VerticalAlignment.Center;
                row.Children.Add(label);
                panel.Children.Add(row);
            }
            if (copies.Count > 14)
                panel.Children.Add(Ui.Text($"…and {copies.Count - 14} more.", 15, false, Ui.Dim));
        }
        else
        {
            panel.Children.Add(Ui.Text("You don't have this one yet.", 20, true, Ui.Warn));
        }

        panel.Children.Add(Ui.Text("Where to get it", 20, true));
        var where = Ui.Text("Looking it up…", 15, false, Ui.Dim);
        panel.Children.Add(where);
        _ = FillEncountersAsync(species, where);
        return panel;
    }

    private async Task EditAsync(Copy copy)
    {
        try
        {
            EditTarget target;
            if (copy.BankId is { } id)
            {
                var entry = Svc.Bank.GetAll().FirstOrDefault(e => e.Id == id)
                    ?? throw new InvalidOperationException("That Bank entry is gone.");
                target = EditTarget.ForBank(entry);
            }
            else if (copy.Save is not null && copy.Box >= 0)
                target = await EditTarget.ForSaveAsync(copy.Save, copy.Box, copy.Slot);
            else return;
            _openEditor(target, _ => Start());
        }
        catch (Exception error)
        {
            _host.Content = Frame("Collection", Ui.Text("Could not open it for editing: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private async Task FillEncountersAsync(int species, TextBlock target)
    {
        var token = ++_lookupToken;
        try
        {
            var listings = await Task.Run(() => Svc.Encounters.Describe(species, 0));
            if (token != _lookupToken) return;

            var lines = new List<string>();
            foreach (var game in listings.Where(g => g.Obtainable))
            {
                var card = game.Cards.FirstOrDefault();
                if (card is null)
                {
                    lines.Add($"{game.GameName}: obtainable");
                    continue;
                }
                var levels = card.LevelMin == card.LevelMax ? $"Lv {card.LevelMin}" : $"Lv {card.LevelMin}-{card.LevelMax}";
                lines.Add($"{game.GameName}: {card.Location} ({card.Kind}, {levels})");
            }
            target.Foreground = Ui.Ink;
            target.Text = lines.Count == 0
                ? "No way to get it in the main games, or it is not in the offline data."
                : string.Join("\n", lines.Take(18));
        }
        catch (Exception error)
        {
            if (token == _lookupToken) target.Text = "Could not look it up: " + error.Message;
        }
    }

    // ───────────────────────── layout ─────────────────────────

    private Control Frame(string title, Control body)
    {
        var back = Ui.Btn("‹ Home", _close);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(back);
        header.Children.Add(Ui.Text(title, 32, true));
        DockPanel.SetDock(header, Dock.Top);

        var root = new DockPanel { Margin = new Thickness(24, 18) };
        root.Children.Add(header);
        root.Children.Add(body);
        return root;
    }
}
