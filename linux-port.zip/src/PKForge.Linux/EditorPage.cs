using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The Pokémon editor. Every change is made on a throwaway copy in memory; "Save" is the only thing
/// that writes, and for a game save it always makes a restore point first. Leaving without saving
/// changes nothing.
/// </summary>
public sealed class EditorPage : IScreen
{
    private static readonly string[] StatNames = ["HP", "Attack", "Defense", "Sp. Atk", "Sp. Def", "Speed"];

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly EditTarget _target;
    private readonly Action<bool> _done;

    private EntityDetail _d = null!;
    private LegalityReport? _legality;
    private string _note = "";
    private bool _dirty;
    private bool _busy;
    private Action _escape;

    public EditorPage(ContentControl host, SpriteStore sprites, EditTarget target, Action<bool> done)
    {
        _host = host;
        _sprites = sprites;
        _target = target;
        _done = done;
        _escape = RequestClose;
    }

    private ISaveEngineSession S => _target.Session;
    private int Gen => S.Generation;

    public void Escape()
    {
        if (!_busy) _escape();
    }

    public void Start()
    {
        Refresh();
        Render();
    }

    private void Finish(bool saved)
    {
        try { S.Dispose(); } catch (Exception) { /* nothing left to release */ }
        _done(saved);
    }

    private void RequestClose()
    {
        if (!_dirty) { Finish(false); return; }
        var body = new StackPanel { Spacing = 16 };
        body.Children.Add(Ui.Text("Leave without saving?", 30, true));
        body.Children.Add(Ui.Text("Your changes have not been saved and will be lost. Nothing has been written anywhere.", 20, false, Ui.Dim));
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        actions.Children.Add(Ui.Btn("Keep editing", Render, primary: true));
        actions.Children.Add(Ui.Btn("Discard changes", () => Finish(false)));
        body.Children.Add(actions);
        _escape = Render;
        Page("Discard changes?", body);
    }

    /// <summary>Re-reads the Pokémon and its legality after every change.</summary>
    private void Refresh()
    {
        _d = S.ReadEntity(_target.Box, _target.Slot);
        try { _legality = Svc.Legality.Analyze(S, _target.Box, _target.Slot); }
        catch (Exception) { _legality = null; }
    }

    private void Apply(EntityEdit edit, bool rerender = true)
    {
        try
        {
            S.ApplyEdit(_target.Box, _target.Slot, edit);
            _dirty = true;
            _note = "";
        }
        catch (Exception error)
        {
            _note = "That change was not accepted: " + error.Message;
        }
        Refresh();
        if (rerender) Render();
    }

    // ───────────────────────── the main screen ─────────────────────────

    private void Render()
    {
        _escape = RequestClose;
        var d = _d;

        // left: who it is
        var left = new StackPanel { Spacing = 8 };
        if (_sprites.Get(d.Look) is { } sprite)
            left.Children.Add(new Image { Source = sprite, Width = 240, Height = 200, Stretch = Stretch.Uniform });
        left.Children.Add(Ui.Text(Svc.SpeciesName(d.Species), 28, true));
        left.Children.Add(Ui.Text($"Level {d.Level}" + (d.IsShiny ? "  ★ Shiny" : ""), 18, false, d.IsShiny ? Ui.Gold : Ui.Dim));

        if (_legality is { } legal)
        {
            left.Children.Add(Ui.Text(legal.Valid ? "Legal ✓" : "Not legal ✗", 22, true, legal.Valid ? Ui.Gold : Ui.Warn));
            if (!legal.Valid)
                foreach (var line in legal.Lines.Take(6))
                    left.Children.Add(Ui.Text("• " + line, 14, false, Ui.Warn));
        }
        if (d.Stats is { Count: 6 } stats)
        {
            left.Children.Add(Ui.Text("Stats", 18, true));
            for (var i = 0; i < 6; i++)
                left.Children.Add(Ui.Text($"{StatNames[i]}  {stats[i]}", 16, false, Ui.Dim));
        }
        var leftBorder = new Border
        {
            Width = 300,
            Padding = new Thickness(16),
            Margin = new Thickness(0, 0, 16, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = left },
        };
        DockPanel.SetDock(leftBorder, Dock.Left);

        // right: what can change
        var rows = new StackPanel { Spacing = 8 };
        if (_target.Refusal is { } refusal)
            rows.Children.Add(Ui.Text("This save cannot be written, so you can look but not save: " + refusal, 16, false, Ui.Warn));
        if (_note.Length > 0)
            rows.Children.Add(Ui.Text(_note, 16, false, Ui.Warn));

        rows.Children.Add(NicknameRow());
        rows.Children.Add(Stepper("Level", d.Level, 1, 100, v => Apply(new EntityEdit(Level: v))));
        rows.Children.Add(Stepper("Friendship", d.Friendship, 0, 255, v => Apply(new EntityEdit(Friendship: v))));
        rows.Children.Add(ToggleRow("Shiny", d.IsShiny, v => Apply(new EntityEdit(IsShiny: v))));

        if (Gen >= 3)
        {
            var natures = Svc.Data.NatureNames;
            rows.Children.Add(PickRow("Nature", d.Nature < natures.Count ? natures[d.Nature] : "?",
                () => PickNature()));
            var abilities = S.GetAbilityChoices(d.Species, d.Form);
            if (abilities.Count > 0)
                rows.Children.Add(PickRow("Ability", AbilityName(d.Ability), () => PickAbility(abilities)));
        }
        if (Gen >= 2)
            rows.Children.Add(PickRow("Held item", d.HeldItem == 0 ? "— none —" : ItemName(d.HeldItem), PickItem));
        if (Gen >= 3)
            rows.Children.Add(PickRow("Ball", BallName(d.Ball), PickBall));

        rows.Children.Add(Ui.Text("Moves", 22, true));
        var moves = new[] { d.Move1, d.Move2, d.Move3, d.Move4 };
        for (var i = 0; i < 4; i++)
        {
            var index = i;
            rows.Children.Add(PickRow($"Move {i + 1}", moves[i] == 0 ? "— none —" : MoveName(moves[i]), () => PickMove(index)));
        }

        var caps = S.GetTrainingCaps();
        var ivLabel = Gen <= 2 ? "DVs" : "IVs";
        var evLabel = Gen <= 2 ? "Stat experience" : "EVs";

        rows.Children.Add(Ui.Text(ivLabel, 22, true));
        for (var i = 0; i < 6; i++)
        {
            var index = i;
            rows.Children.Add(Stepper(StatNames[i], d.IVs[i], 0, caps.IvMax, v => SetStat(true, index, v), bigStep: 5));
        }
        rows.Children.Add(Ui.Btn($"Max all {ivLabel}", () =>
            Apply(new EntityEdit(IVs: [caps.IvMax, caps.IvMax, caps.IvMax, caps.IvMax, caps.IvMax, caps.IvMax]))));

        rows.Children.Add(Ui.Text(evLabel, 22, true));
        for (var i = 0; i < 6; i++)
        {
            var index = i;
            rows.Children.Add(Stepper(StatNames[i], d.EVs[i], 0, caps.EvMax, v => SetStat(false, index, v), bigStep: 10));
        }
        rows.Children.Add(Ui.Text(Gen >= 3 && caps.EvMax <= 255 ? $"EV total: {d.EVs.Sum()} of 510" : $"Total: {d.EVs.Sum()}", 16, false, Ui.Dim));
        rows.Children.Add(Ui.Btn($"Zero all {evLabel}", () => Apply(new EntityEdit(EVs: [0, 0, 0, 0, 0, 0]))));

        var rightScroll = new ScrollViewer
        {
            Content = rows,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Padding = new Thickness(0, 0, 12, 0),
        };

        // bottom: actions
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12, Margin = new Thickness(0, 12, 0, 0) };
        actions.Children.Add(Ui.Btn("Make it legal", Legalize));
        actions.Children.Add(Ui.Btn("Copy as Showdown", () => _ = CopyShowdownAsync()));
        actions.Children.Add(Ui.Btn(_dirty ? "Save changes…" : "No changes yet", ShowConfirm, primary: _dirty));
        DockPanel.SetDock(actions, Dock.Bottom);

        var back = Ui.Btn("‹ Back", Escape);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(back);
        header.Children.Add(Ui.Text($"Edit · {_target.Where}" + (_dirty ? "  (unsaved changes)" : ""), 28, true));
        DockPanel.SetDock(header, Dock.Top);

        var root = new DockPanel { Margin = new Thickness(24, 18) };
        root.Children.Add(header);
        root.Children.Add(actions);
        root.Children.Add(leftBorder);
        root.Children.Add(rightScroll);
        _host.Content = root;
    }

    private void SetStat(bool iv, int index, int value)
    {
        var current = (iv ? _d.IVs : _d.EVs).ToArray();
        var caps = S.GetTrainingCaps();
        value = Math.Clamp(value, 0, iv ? caps.IvMax : caps.EvMax);
        if (!iv && Gen >= 3 && caps.EvMax <= 255)
        {
            // The game stops at 510 EVs in total.
            var others = current.Sum() - current[index];
            value = Math.Min(value, Math.Max(0, 510 - others));
        }
        current[index] = value;
        Apply(iv ? new EntityEdit(IVs: current) : new EntityEdit(EVs: current));
    }

    // ───────────────────────── names ─────────────────────────

    private static string Name(IReadOnlyList<string> list, int id) =>
        id >= 0 && id < list.Count && list[id].Length > 0 ? list[id] : "#" + id;

    private string MoveName(int id) => Name(Svc.Data.MoveNames, id);
    private string AbilityName(int id) => Name(Svc.Data.AbilityNames, id);
    private async Task CopyShowdownAsync()
    {
        try
        {
            var text = S.GetShowdownText(_target.Box, _target.Slot);
            _note = await Workbench.CopyAsync(_host, text)
                ? "Copied the Showdown text. Paste it anywhere."
                : "The clipboard would not take it.";
        }
        catch (Exception error) { _note = "Could not make the text: " + error.Message; }
        Render();
    }

    private string ItemName(int id) => Name(S.GetItemNames(), id);
    private string BallName(int id) => Name(Svc.Data.BallNames, id);

    // ───────────────────────── row builders ─────────────────────────

    private static Control Row(string label, Control value, Control? action = null)
    {
        var grid = new Grid { ColumnDefinitions = new ColumnDefinitions("200,*,Auto"), MinHeight = 56 };
        var labelBlock = Ui.Text(label, 20, false, Ui.Dim);
        labelBlock.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumn(labelBlock, 0);
        value.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumn(value, 1);
        grid.Children.Add(labelBlock);
        grid.Children.Add(value);
        if (action is not null)
        {
            Grid.SetColumn(action, 2);
            grid.Children.Add(action);
        }
        return new Border
        {
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(16, 4),
            Child = grid,
        };
    }

    private Control PickRow(string label, string current, Action pick)
    {
        var change = Ui.Btn("Change", pick);
        change.MinHeight = 44;
        return Row(label, Ui.Text(current, 22, true), change);
    }

    private Control ToggleRow(string label, bool value, Action<bool> set)
    {
        var button = Ui.Btn(value ? "Yes" : "No", () => set(!value), primary: value);
        button.MinHeight = 44;
        return Row(label, Ui.Text(value ? "Yes" : "No", 22, true), button);
    }

    private Control NicknameRow()
    {
        var box = new TextBox
        {
            Text = _d.Nickname,
            FontSize = 20,
            MinHeight = 44,
            MaxLength = Gen >= 6 ? 12 : 10,
            VerticalContentAlignment = VerticalAlignment.Center,
        };
        var set = Ui.Btn("Set", () =>
        {
            var text = (box.Text ?? "").Trim();
            if (text.Length > 0) Apply(new EntityEdit(Nickname: text));
        });
        set.MinHeight = 44;
        return Row("Nickname", box, set);
    }

    private Control Stepper(string label, int value, int min, int max, Action<int> set, int bigStep = 10)
    {
        Button Small(string text, int delta)
        {
            var b = Ui.Btn(text, () => set(Math.Clamp(value + delta, min, max)));
            b.MinWidth = 64;
            b.MinHeight = 44;
            b.Padding = new Thickness(8, 4);
            b.FontSize = 18;
            b.Margin = new Thickness(4, 0);
            return b;
        }

        var valueText = Ui.Text(value.ToString(), 24, true);
        valueText.TextAlignment = TextAlignment.Center;
        valueText.Width = 70;
        valueText.VerticalAlignment = VerticalAlignment.Center;

        var controls = new StackPanel { Orientation = Orientation.Horizontal };
        controls.Children.Add(Small($"−{bigStep}", -bigStep));
        controls.Children.Add(Small("−1", -1));
        controls.Children.Add(valueText);
        controls.Children.Add(Small("+1", 1));
        controls.Children.Add(Small($"+{bigStep}", bigStep));

        var grid = new Grid { ColumnDefinitions = new ColumnDefinitions("200,*"), MinHeight = 56 };
        var labelBlock = Ui.Text(label, 20, false, Ui.Dim);
        labelBlock.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumn(controls, 1);
        grid.Children.Add(labelBlock);
        grid.Children.Add(controls);
        return new Border
        {
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(16, 4),
            Child = grid,
        };
    }

    // ───────────────────────── pickers ─────────────────────────

    private void PickNature()
    {
        var names = Svc.Data.NatureNames;
        var items = Enumerable.Range(0, names.Count).Where(i => names[i].Length > 0).Select(i => (i, names[i])).ToList();
        Picker("Choose a nature", items, _d.Nature, id => Apply(new EntityEdit(Nature: id)));
    }

    private void PickAbility(IReadOnlyList<int> choices)
    {
        var items = choices.Distinct().Select(id => (id, AbilityName(id))).ToList();
        Picker("Choose an ability", items, _d.Ability, id => Apply(new EntityEdit(Ability: id)));
    }

    private void PickItem()
    {
        var names = S.GetItemNames();
        var items = new List<(int, string)> { (0, "— none —") };
        for (var i = 1; i < names.Count; i++)
            if (names[i].Length > 0) items.Add((i, names[i]));
        Picker("Choose a held item", items, _d.HeldItem, id => Apply(new EntityEdit(HeldItem: id)));
    }

    private void PickBall()
    {
        var names = Svc.Data.BallNames;
        var items = Enumerable.Range(1, Math.Max(0, names.Count - 1)).Where(i => names[i].Length > 0).Select(i => (i, names[i])).ToList();
        Picker("Choose a ball", items, _d.Ball, id => Apply(new EntityEdit(Ball: id)));
    }

    private void PickMove(int index)
    {
        var names = Svc.Data.MoveNames;
        var items = new List<(int, string)> { (0, "— none —") };
        for (var i = 1; i < names.Count; i++)
            if (names[i].Length > 0) items.Add((i, names[i]));
        var current = new[] { _d.Move1, _d.Move2, _d.Move3, _d.Move4 }[index];
        Picker($"Choose move {index + 1}", items, current, id =>
        {
            Apply(index switch
            {
                0 => new EntityEdit(Move1: id),
                1 => new EntityEdit(Move2: id),
                2 => new EntityEdit(Move3: id),
                _ => new EntityEdit(Move4: id),
            });
        });
    }

    /// <summary>A searchable list. Type to narrow it down; the first 60 matches are shown.</summary>
    private void Picker(string title, IReadOnlyList<(int Id, string Name)> items, int current, Action<int> choose)
    {
        _escape = Render;
        var list = new StackPanel { Spacing = 6 };
        var search = new TextBox
        {
            FontSize = 22,
            MinHeight = 56,
            VerticalContentAlignment = VerticalAlignment.Center,
        };

        void Fill()
        {
            list.Children.Clear();
            var query = (search.Text ?? "").Trim();
            var shown = items
                .Where(i => query.Length == 0 || i.Name.Contains(query, StringComparison.OrdinalIgnoreCase))
                .Take(60)
                .ToList();
            foreach (var item in shown)
            {
                var picked = item;
                var isCurrent = picked.Id == current;
                var button = new Button
                {
                    Content = Ui.Text((isCurrent ? "● " : "") + picked.Name, 20, isCurrent),
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    HorizontalContentAlignment = HorizontalAlignment.Left,
                    MinHeight = 52,
                    Padding = new Thickness(16, 6),
                    Background = isCurrent ? Ui.PanelHi : Ui.Panel,
                    CornerRadius = new CornerRadius(8),
                };
                button.Click += (_, _) => choose(picked.Id);
                list.Children.Add(button);
            }
            if (shown.Count == 0)
                list.Children.Add(Ui.Text("Nothing matches.", 20, false, Ui.Dim));
            else if (shown.Count == 60)
                list.Children.Add(Ui.Text("Showing the first 60. Type more to narrow it down.", 16, false, Ui.Dim));
        }

        search.PropertyChanged += (_, e) =>
        {
            if (e.Property == TextBox.TextProperty) Fill();
        };
        Fill();

        var body = new DockPanel();
        var hint = Ui.Text("Type in the box to search:", 16, false, Ui.Dim);
        DockPanel.SetDock(hint, Dock.Top);
        body.Children.Add(hint);
        DockPanel.SetDock(search, Dock.Top);
        body.Children.Add(search);
        body.Children.Add(new ScrollViewer
        {
            Content = list,
            Margin = new Thickness(0, 10, 0, 0),
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        });
        Frame(title, body, Render);
    }

    // ───────────────────────── legalize / save ─────────────────────────

    private void Legalize()
    {
        try
        {
            var outcome = Svc.Legalizer.LegalizeSlot(S, _target.Box, _target.Slot);
            if (outcome.Success) _dirty = true;
            _note = outcome.Message;
        }
        catch (Exception error)
        {
            _note = "Could not make it legal: " + error.Message;
        }
        Refresh();
        Render();
    }

    private void ShowConfirm()
    {
        if (!_dirty) return;
        _escape = Render;
        var body = new StackPanel { Spacing = 16 };
        if (_target.Refusal is { } refusal)
        {
            body.Children.Add(Ui.Text("Cannot save", 30, true, Ui.Warn));
            body.Children.Add(Ui.Text(refusal, 20));
            body.Children.Add(Ui.Btn("‹ Back", Render));
            Page("Save changes", body);
            return;
        }

        body.Children.Add(Ui.Text(_target.IsBank ? "Save to the Bank?" : $"Write this to {_target.Where}?", 30, true));
        body.Children.Add(Ui.Text(_target.IsBank
            ? "The Pokémon in the Bank is replaced with your edited version."
            : "Only this one Pokémon changes. A restore point of the whole save is made first, so you can undo it. Close the emulator before you save.",
            20, false, Ui.Dim));
        if (_legality is { Valid: false })
            body.Children.Add(Ui.Text("⚠ The checker says this Pokémon is not legal. The game will still load it, but it may be refused online or by other tools.", 18, false, Ui.Warn));
        if (_target.Caution is { } caution)
            body.Children.Add(Ui.Text("⚠ " + caution, 18, false, Ui.Warn));

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        actions.Children.Add(Ui.Btn("Cancel", Render));
        actions.Children.Add(Ui.Btn("Yes, save it", () => _ = SaveAsync(), primary: true));
        body.Children.Add(actions);
        Page("Save changes", body);
    }

    private async Task SaveAsync()
    {
        _busy = true;
        Page("Saving", Ui.Text("Saving…", 22));
        try
        {
            var message = await _target.SaveAsync();
            _busy = false;
            _escape = () => Finish(true);
            var body = new StackPanel { Spacing = 16 };
            body.Children.Add(Ui.Text("Done!", 30, true, Ui.Gold));
            body.Children.Add(Ui.Text(message, 20));
            body.Children.Add(Ui.Btn("Done", () => Finish(true), primary: true));
            Page("Saved", body);
        }
        catch (Exception error)
        {
            _busy = false;
            _escape = Render;
            var body = new StackPanel { Spacing = 16 };
            body.Children.Add(Ui.Text("Nothing was saved.", 30, true, Ui.Warn));
            body.Children.Add(Ui.Text(error.Message, 20));
            body.Children.Add(Ui.Btn("‹ Back to the editor", Render));
            Page("Not saved", body);
        }
    }

    // ───────────────────────── layout helpers ─────────────────────────

    private void Page(string title, Control body) => Frame(title, new ScrollViewer
    {
        Content = body,
        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
    }, null);

    private void Frame(string title, Control body, Action? back)
    {
        var backButton = Ui.Btn("‹ Back", back ?? Escape);
        backButton.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(backButton, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 16) };
        header.Children.Add(backButton);
        header.Children.Add(Ui.Text(title, 30, true));
        DockPanel.SetDock(header, Dock.Top);

        var root = new DockPanel { Margin = new Thickness(28, 20) };
        root.Children.Add(header);
        root.Children.Add(body);
        _host.Content = root;
    }
}
