using Avalonia;
using PKForge.Linux.Services;

namespace PKForge.Linux;

internal static class Program
{
    [STAThread]
    public static int Main(string[] args)
    {
        // Every crash leaves a note the player can send back.
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            AppPaths.LogCrash(e.ExceptionObject?.ToString() ?? "unknown error");
        try
        {
            return BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }
        catch (Exception error)
        {
            AppPaths.LogCrash(error.ToString());
            throw;
        }
    }

    public static AppBuilder BuildAvaloniaApp() => AppBuilder.Configure<App>().UsePlatformDetect();
}
