using Avalonia.Input;

namespace PKForge.Linux;

/// <summary>A full-window screen that wants the Back key (Esc) and, optionally, the other keys.</summary>
public interface IScreen
{
    void Escape();
    bool OnKey(Key key) => false;
}
