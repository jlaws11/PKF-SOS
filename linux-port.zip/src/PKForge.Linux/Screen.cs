using Avalonia.Input;

namespace PKForge.Linux;

/// <summary>A full-window screen that wants the Back key (Esc) and, optionally, the other keys.</summary>
public interface IScreen
{
    void Escape();
    bool OnKey(Key key) => false;

    /// <summary>Extra controller hints for the bar along the bottom, e.g. ("X", "Save"). Read whenever the screen redraws.</summary>
    IReadOnlyList<(string Button, string Label)> PadHints => [];
}
