using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;

namespace PKForge.Linux;

/// <summary>Colors and small builders shared by every screen. Sizes are generous: this is a touch screen.</summary>
internal static class Ui
{
    // The original's navy pixel-console palette: deck navy ground, cobalt panels, cyan focus.
    public static readonly FontFamily Font = new("avares://PKForge/Fonts/NDS12.ttf#NDS12, Noto Sans, sans-serif");
    public static readonly IBrush Bg = new SolidColorBrush(Color.Parse("#141B38"));
    public static readonly IBrush Panel = new SolidColorBrush(Color.Parse("#1F2D5A"));
    public static readonly IBrush PanelHi = new SolidColorBrush(Color.Parse("#2B4E95"));
    public static readonly IBrush Edge = new SolidColorBrush(Color.Parse("#4C7CC4"));
    public static readonly IBrush Blue = new SolidColorBrush(Color.Parse("#2789CD"));
    public static readonly IBrush Accent = new SolidColorBrush(Color.Parse("#42BFE8"));
    public static readonly IBrush Ink = new SolidColorBrush(Color.Parse("#F4F8FF"));
    public static readonly IBrush Dim = new SolidColorBrush(Color.Parse("#A8BADC"));
    public static readonly IBrush Warn = new SolidColorBrush(Color.Parse("#FFB454"));
    public static readonly IBrush Gold = new SolidColorBrush(Color.Parse("#FFD54F"));
    public static readonly IBrush Clear = new SolidColorBrush(Color.Parse("#00000000"));

    public static TextBlock Text(string text, double size = 18, bool bold = false, IBrush? brush = null) => new()
    {
        Text = text,
        FontSize = size,
        FontWeight = bold ? FontWeight.Bold : FontWeight.Normal,
        Foreground = brush ?? Ink,
        TextWrapping = TextWrapping.Wrap,
    };

    public static Button Btn(string text, Action onClick, bool primary = false)
    {
        var button = new Button
        {
            Content = text,
            FontSize = 20,
            MinHeight = 56,
            MinWidth = 120,
            Padding = new Avalonia.Thickness(20, 10),
            Background = primary ? Blue : PanelHi,
            BorderBrush = primary ? Accent : Edge,
            BorderThickness = new Avalonia.Thickness(2),
            Foreground = Ink,
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            CornerRadius = new Avalonia.CornerRadius(6),
        };
        button.Click += (_, _) => onClick();
        return button;
    }
}
