using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Make a Pokémon from nothing: pick the game it must be legal in, then build it (species, level, shiny, nature)
/// or paste Showdown sets. Send it to the Bank (touches no game file) or straight into the game.
/// </summary>
public sealed class GeneratePage : IScreen
{
    private const int MaxRows = 60;

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;
    private readonly int? _preset;

    private Workbench? _bench;
    private bool _showdownTab;
    private string _search = "";
    private int _species;
    private int _level = 50;
    private bool _shiny;
    private int _nature = -1;
    private int _form;
    private string _showdown = "";
    private string _note = "";
    private bool _noteIsError;
    private bool _busy;

    public GeneratePage(ContentControl host, SpriteStore sprites, int? presetSpecies, Action close)
    {
        _host = host;
        _sprites = sprites;
        _preset = presetSpecies;
        _close = close;
    }

    public IReadOnlyList<(string Button, string Label)> PadHints => _bench is null ? [] : [("L1 / R1", "Build / Showdown")];

    public bool OnKey(Key key)
    {
        if (_bench is null || _busy) return false;
        if (key is Key.PageUp or Key.PageDown) { _showdownTab = !_showdownTab; _note = ""; Render(); return true; }
        return false;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_bench is null) { _close(); return; }
        _bench = null;
        Start();
    }

    // ───────────────────────── step 1: which game ─────────────────────────

    public void Start()
    {
        _host.Content = Workbench.Frame("Generate Pokémon", _close,
            Workbench.SavePicker(
                _preset is { } p
                    ? $"Which game should {Svc.SpeciesName(p)} be made for? It will be built to be legal in that game."
                    : "Which game should the Pokémon be made for? It will be built to be legal in that game.",
                _ => true, "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Back");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Generate Pokémon", Escape, Ui.Text("Getting the game ready…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            _species = _preset ?? 0;
            _showdownTab = false;
            _note = _bench.Refusal ?? "";
            _noteIsError = _bench.Refusal is not null;
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Generate Pokémon", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    // ───────────────────────── the page ─────────────────────────

    private void Render()
    {
        var bench = _bench!;
        var tabs = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, Margin = new Thickness(0, 0, 0, 10) };
        tabs.Children.Add(Chip("Build one", !_showdownTab, () => { _showdownTab = false; _note = ""; Render(); }));
        tabs.Children.Add(Chip("Paste Showdown sets", _showdownTab, () => { _showdownTab = true; _note = ""; Render(); }));

        var body = new DockPanel();
        DockPanel.SetDock(tabs, Dock.Top);
        body.Children.Add(tabs);
        body.Children.Add(_showdownTab ? ShowdownBody() : BuildBody());
        _host.Content = Workbench.Frame($"Generate · made for {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape, body);
    }

    private Button Chip(string text, bool on, Action click)
    {
        var b = Ui.Btn(text, click, primary: on);
        b.MinWidth = 0; b.MinHeight = 46; b.FontSize = 16; b.Padding = new Thickness(14, 4);
        return b;
    }

    private Control NoteBlock() => Ui.Text(_busy ? "Working…" : _note, 16, false, _noteIsError ? Ui.Warn : Ui.Gold);

    // ── build one ──

    private Control BuildBody()
    {
        var session = _bench!.Session;
        var max = Math.Min(session.MaxSpeciesId, CollectionDex.MaxSpecies);

        var search = new TextBox { Text = _search, MinHeight = 46, FontSize = 18, Margin = new Thickness(0, 0, 0, 8) };
        var rows = new StackPanel { Spacing = 6 };
        void Fill()
        {
            rows.Children.Clear();
            var terms = _search.ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var found = 0;
            for (var id = 1; id <= max && found < MaxRows; id++)
            {
                var name = Svc.SpeciesName(id);
                if (name.StartsWith('#')) continue;
                if (terms.Length > 0 && !terms.All(t => name.ToLowerInvariant().Contains(t) || id.ToString() == t)) continue;
                found++;
                var chosen = id;
                var line = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
                if (_sprites.Get(new SpriteLook(id, 0, false)) is { } sprite)
                    line.Children.Add(new Image { Source = sprite, Width = 44, Height = 44, Stretch = Stretch.Uniform });
                var label = Ui.Text($"{name}   #{id:000}", 18, id == _species);
                label.VerticalAlignment = VerticalAlignment.Center;
                line.Children.Add(label);
                var on = id == _species;
                var button = new Button
                {
                    Content = line,
                    MinHeight = 54,
                    Padding = new Thickness(8, 2),
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    HorizontalContentAlignment = HorizontalAlignment.Left,
                    Background = on ? Ui.PanelHi : Ui.Panel,
                    BorderBrush = on ? Ui.Accent : Ui.Clear,
                    BorderThickness = new Thickness(2),
                    CornerRadius = new CornerRadius(8),
                };
                button.Click += (_, _) => { _species = chosen; _form = 0; _note = ""; Render(); };
                rows.Children.Add(button);
            }
            if (found == 0) rows.Children.Add(Ui.Text("No species match.", 18, false, Ui.Dim));
        }
        search.PropertyChanged += (_, e) =>
        {
            if (e.Property != TextBox.TextProperty) return;
            _search = search.Text ?? "";
            Fill();
        };
        Fill();

        var left = new DockPanel();
        DockPanel.SetDock(search, Dock.Top);
        left.Children.Add(search);
        left.Children.Add(new ScrollViewer { Content = rows, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });

        var side = new StackPanel { Spacing = 10 };
        if (_species == 0)
        {
            side.Children.Add(Ui.Text("Pick a species", 24, true));
            side.Children.Add(Ui.Text("Search by name or dex number on the left.", 16, false, Ui.Dim));
        }
        else
        {
            if (_sprites.Get(new SpriteLook(_species, _form, _shiny)) is { } sprite)
                side.Children.Add(new Image { Source = sprite, Width = 170, Height = 150, Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Center });
            side.Children.Add(Ui.Text(Svc.SpeciesName(_species), 26, true));

            side.Children.Add(Stepper("Level", _level.ToString(), [("−10", -10), ("−1", -1), ("+1", 1), ("+10", 10)], d => { _level = Math.Clamp(_level + d, 1, 100); Render(); }));
            if (_species < Svc.Data.FormFlags.Count && Svc.Data.FormFlags[_species].HasForms)
                side.Children.Add(Stepper("Form", _form.ToString(), [("−1", -1), ("+1", 1)], d => { _form = Math.Max(0, _form + d); Render(); }));
            var natures = Svc.Data.NatureNames;
            side.Children.Add(Stepper("Nature", _nature < 0 ? "Auto" : natures[_nature], [("‹", -1), ("›", 1)],
                d => { _nature = Math.Clamp(_nature + d, -1, natures.Count - 1); Render(); }));
            var shiny = Ui.Btn(_shiny ? "★ Shiny: yes" : "Shiny: no", () => { _shiny = !_shiny; Render(); }, primary: _shiny);
            shiny.HorizontalAlignment = HorizontalAlignment.Left;
            side.Children.Add(shiny);

            side.Children.Add(Ui.Text("Moves, ability and the rest are chosen for you so it comes out legal.", 14, false, Ui.Dim));
            side.Children.Add(SendButtons(forShowdown: false));
        }
        side.Children.Add(NoteBlock());
        return Split(left, side);
    }

    private Control Stepper(string label, string value, (string Text, int Delta)[] buttons, Action<int> change)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
        var name = Ui.Text(label, 18);
        name.Width = 72;
        name.VerticalAlignment = VerticalAlignment.Center;
        row.Children.Add(name);
        var half = buttons.Length / 2;
        for (var i = 0; i < buttons.Length; i++)
        {
            if (i == half)
            {
                var v = Ui.Text(value, 20, true, Ui.Gold);
                v.MinWidth = 70;
                v.TextAlignment = TextAlignment.Center;
                v.VerticalAlignment = VerticalAlignment.Center;
                row.Children.Add(v);
            }
            var (text, delta) = buttons[i];
            var b = Ui.Btn(text, () => change(delta));
            b.MinWidth = 0; b.MinHeight = 44; b.FontSize = 16; b.Padding = new Thickness(8, 2);
            row.Children.Add(b);
        }
        return row;
    }

    private Control SendButtons(bool forShowdown)
    {
        var bench = _bench!;
        var panel = new StackPanel { Spacing = 8, Margin = new Thickness(0, 6, 0, 0) };
        var bank = Ui.Btn("Make it → the Bank", () => _ = MakeAsync(toBank: true, forShowdown), primary: true);
        var game = Ui.Btn($"Make it → {bench.Save.GameLabel.Replace("Pokémon ", "")}", () => _ = MakeAsync(toBank: false, forShowdown));
        game.IsEnabled = bench.Refusal is null && !_busy;
        bank.IsEnabled = !_busy;
        bank.HorizontalAlignment = game.HorizontalAlignment = HorizontalAlignment.Stretch;
        panel.Children.Add(bank);
        panel.Children.Add(game);
        panel.Children.Add(Ui.Text("The Bank touches no game file. Putting it in the game uses the first empty box slot and makes a restore point first.", 14, false, Ui.Dim));
        return panel;
    }

    // ── showdown ──

    private Control ShowdownBody()
    {
        var box = new TextBox
        {
            Text = _showdown,
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            FontSize = 16,
            MinHeight = 320,
            VerticalContentAlignment = VerticalAlignment.Top,
        };
        box.PropertyChanged += (_, e) =>
        {
            if (e.Property == TextBox.TextProperty) _showdown = box.Text ?? "";
        };

        var left = new DockPanel();
        var hint = Ui.Text("Paste one or more Showdown / PokePaste sets. Separate sets with a blank line.", 16, false, Ui.Dim);
        DockPanel.SetDock(hint, Dock.Top);
        left.Children.Add(hint);
        left.Children.Add(box);

        var side = new StackPanel { Spacing = 10 };
        side.Children.Add(Ui.Text("Import", 24, true));
        side.Children.Add(SendButtons(forShowdown: true));
        side.Children.Add(NoteBlock());
        return Split(left, side);
    }

    private static Control Split(Control left, Control right)
    {
        var side = new Border
        {
            Width = 470,
            Padding = new Thickness(18),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = right, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Padding = new Thickness(0, 0, 14, 0) },
        };
        var body = new DockPanel();
        DockPanel.SetDock(side, Dock.Right);
        body.Children.Add(side);
        body.Children.Add(left);
        return body;
    }

    // ───────────────────────── making it ─────────────────────────

    private static List<string> SplitSets(string text) =>
        [.. System.Text.RegularExpressions.Regex.Split(text.Replace("\r\n", "\n").Trim(), @"\n\s*\n").Select(s => s.Trim()).Where(s => s.Length > 0)];

    private async Task MakeAsync(bool toBank, bool showdown)
    {
        var bench = _bench;
        if (bench is null || _busy) return;
        var session = bench.Session;
        List<string> sets = [];
        if (showdown)
        {
            sets = SplitSets(_showdown);
            if (sets.Count == 0) { _note = "Paste at least one set first."; _noteIsError = true; Render(); return; }
        }
        else if (_species == 0)
        {
            _note = "Pick a species first.";
            _noteIsError = true;
            Render();
            return;
        }

        _busy = true;
        _note = "";
        Render();
        try
        {
            var request = new GenerationRequest(_species, _level, _shiny, _nature < 0 ? null : _nature, null, null, null, _form);
            var (made, notes) = await Task.Run(() => toBank ? MakeForBank(session, showdown, sets, request) : MakeForGame(session, showdown, sets, request));

            if (!toBank && made > 0)
            {
                _note = await bench.CommitAsync("Generated a Pokémon in PKForge");
                _note = $"Added {made}. " + _note;
            }
            else if (toBank)
                _note = made > 0 ? $"Added {made} to the Bank." : "Nothing was added.";
            else
                _note = "Nothing was added.";
            if (notes.Count > 0) _note += " " + string.Join(" ", notes.Take(3));
            _noteIsError = made == 0;
        }
        catch (Exception error)
        {
            try { await bench.ReloadAsync(); } catch (Exception) { }
            _note = "That did not work: " + error.Message;
            _noteIsError = true;
        }
        _busy = false;
        Render();
    }

    /// <summary>The generator can come back at a different level than asked; set the asked one.</summary>
    private static void SetLevel(ISaveEngineSession session, int box, int slot, int? level)
    {
        if (level is not { } wanted) return;
        try
        {
            if (session.ReadEntity(box, slot).Level != wanted)
                session.ApplyEdit(box, slot, new EntityEdit(Level: wanted));
        }
        catch (Exception) { }
    }

    private static (int Made, List<string> Notes) MakeForBank(ISaveEngineSession session, bool showdown, List<string> sets, GenerationRequest request)
    {
        var notes = new List<string>();
        var made = 0;
        if (!showdown)
        {
            var spare = session.Snapshot.Slots.FirstOrDefault(s => s.Box >= 0 && (s.Species ?? 0) == 0);
            if (spare is not null)
            {
                // Build it in a spare slot of the throwaway copy so the level can be set exactly.
                var outcome = Svc.Legalizer.Generate(session, spare.Box, spare.Slot, request);
                if (!outcome.Success) { notes.Add(outcome.Message); return (made, notes); }
                SetLevel(session, spare.Box, spare.Slot, request.Level);
                var export = session.ExportSlot(spare.Box, spare.Slot);
                var info = Svc.Engine.TryDescribeEntity(export.Data, "Generated", export.Format);
                session.ReleaseSlot(spare.Box, spare.Slot);
                if (info is null) { notes.Add("It was built but could not be converted for the Bank."); return (made, notes); }
                Svc.Bank.Add(export.Data, info);
                made++;
                return (made, notes);
            }
            var entity = Svc.Legalizer.GenerateData(session, request);
            if (entity is null) notes.Add("A legal one could not be built with those choices. Try another level, form or nature.");
            else { Svc.Bank.Add(entity.Data, entity.Info); made++; }
            return (made, notes);
        }
        foreach (var set in sets)
        {
            var entity = Svc.Legalizer.GenerateDataFromShowdown(session, set);
            var title = set.Split('\n')[0].Trim();
            if (entity is null) { notes.Add($"“{title}” could not be built legally."); continue; }
            Svc.Bank.Add(entity.Data, entity.Info);
            made++;
        }
        return (made, notes);
    }

    private static (int Made, List<string> Notes) MakeForGame(ISaveEngineSession session, bool showdown, List<string> sets, GenerationRequest request)
    {
        var notes = new List<string>();
        var free = new Queue<SlotSummary>(session.Snapshot.Slots.Where(s => s.Box >= 0 && (s.Species ?? 0) == 0));
        var made = 0;
        var jobs = showdown ? sets.Count : 1;
        for (var i = 0; i < jobs; i++)
        {
            if (free.Count == 0) { notes.Add("The boxes are full, so the rest were skipped."); break; }
            var slot = free.Dequeue();
            var outcome = showdown
                ? Svc.Legalizer.GenerateFromShowdown(session, slot.Box, slot.Slot, sets[i])
                : Svc.Legalizer.Generate(session, slot.Box, slot.Slot, request);
            if (outcome.Success) { made++; if (!showdown) SetLevel(session, slot.Box, slot.Slot, request.Level); }
            else notes.Add(outcome.Message);
        }
        return (made, notes);
    }
}
