using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The Pokédex editor: pick a save, then tap a species to cycle it between not seen, seen and caught.
/// Complete / clear shortcuts for the whole dex. Nothing is written until Save.
/// </summary>
public sealed class DexPage : IScreen
{
    private const int Columns = 8;

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;

    private Workbench? _bench;
    private readonly Dictionary<int, (bool Seen, bool Caught)> _state = [];
    private List<int> _species = [];
    private int _gen = 1;
    private bool _dirty;
    private bool _confirmDiscard;
    private string _note = "";

        private readonly DetectedSave? _preset;

    public DexPage(ContentControl host, SpriteStore sprites, Action close, DetectedSave? preset = null)
    {
        _host = host;
        _sprites = sprites;
        _close = close;
        _preset = preset;
    }

    public void Escape()
    {
        if (_bench is null) { _close(); return; }
        if (_dirty && !_confirmDiscard)
        {
            _confirmDiscard = true;
            _note = "You have unsaved changes. Press Back again to throw them away, or tap Save.";
            Render();
            return;
        }
        _bench = null;
        _dirty = false;
        _confirmDiscard = false;
        if (_preset is not null) { _close(); return; }
        Start();
    }

    public IReadOnlyList<(string Button, string Label)> PadHints =>
        _bench is null ? [] : [("L1 / R1", "Generation"), ("X", "Save")];

    public bool OnKey(Key key)
    {
        if (_bench is null) return false;
        if (key == Key.X && _dirty && _bench.Refusal is null) { _ = SaveAsync(); return true; }
        if (key is Key.PageUp) { Step(-1); return true; }
        if (key is Key.PageDown) { Step(1); return true; }
        return false;
    }

    private void Step(int delta)
    {
        var gens = Gens();
        if (gens.Count == 0) return;
        var at = Math.Max(0, gens.FindIndex(g => g == _gen));
        _gen = gens[(at + delta + gens.Count) % gens.Count];
        Render();
    }

    public void Start()
    {
        if (_preset is not null) { Open(_preset); return; }
        _host.Content = Workbench.Frame("Pokédex", _close,
            Workbench.SavePicker("Which save's Pokédex do you want to edit?", _ => true,
                "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Pokédex", Escape, Ui.Text("Opening the Pokédex…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            await Task.Run(LoadStates);
            _gen = Gens().FirstOrDefault(1);
            _dirty = false;
            _confirmDiscard = false;
            _note = _bench.Refusal ?? "";
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Pokédex", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private void LoadStates()
    {
        var session = _bench!.Session;
        _state.Clear();
        _species = [];
        var max = Math.Min(session.MaxSpeciesId, CollectionDex.MaxSpecies);
        for (var id = 1; id <= max; id++)
        {
            if (!session.IsDexSpecies(id)) continue;
            var entry = session.GetDexEntry(id);
            _state[id] = (entry.Seen, entry.Caught);
            _species.Add(id);
        }
    }

    private List<int> Gens() =>
        CollectionDex.GenRanges.Where(r => _species.Any(s => s >= r.First && s <= r.Last)).Select(r => r.Generation).ToList();

    // ───────────────────────── the dex ─────────────────────────

    private void Render()
    {
        var bench = _bench!;
        var editable = bench.Refusal is null;
        var seen = _state.Count(s => s.Value.Seen || s.Value.Caught);
        var caught = _state.Count(s => s.Value.Caught);

        var body = new DockPanel();
        var summary = Ui.Text($"Seen {seen} · Caught {caught} · of {_species.Count} in this game", 20, true);
        DockPanel.SetDock(summary, Dock.Top);
        body.Children.Add(summary);

        var tabs = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        foreach (var gen in Gens())
        {
            var g = gen;
            var tab = Ui.Btn($"Gen {g}", () => { _gen = g; Render(); }, primary: g == _gen);
            tab.MinWidth = 0; tab.MinHeight = 44; tab.FontSize = 16; tab.Padding = new Thickness(14, 4);
            tab.Margin = new Thickness(0, 0, 8, 8);
            tabs.Children.Add(tab);
        }
        DockPanel.SetDock(tabs, Dock.Top);
        body.Children.Add(tabs);

        // bottom bar
        var bar = new WrapPanel { Margin = new Thickness(0, 10, 0, 0) };
        Button Tool(string text, Action action, bool primary = false)
        {
            var b = Ui.Btn(text, action, primary);
            b.MinWidth = 0; b.MinHeight = 48; b.FontSize = 16; b.Padding = new Thickness(14, 4);
            b.Margin = new Thickness(0, 0, 8, 6);
            b.IsEnabled = editable;
            return b;
        }
        bar.Children.Add(Tool("Complete Pokédex", CompleteAll));
        bar.Children.Add(Tool($"Complete Gen {_gen}", () => SetRange(true, true)));
        bar.Children.Add(Tool($"Clear Gen {_gen}", () => SetRange(false, false)));
        var save = Tool("Save to the game", () => _ = SaveAsync(), true);
        save.IsEnabled = _dirty && editable;
        bar.Children.Add(save);
        bar.Children.Add(Ui.Text(_note, 15, false, Ui.Warn));
        DockPanel.SetDock(bar, Dock.Bottom);
        body.Children.Add(bar);

        var range = CollectionDex.GenRanges.First(r => r.Generation == _gen);
        var grid = new UniformGrid { Columns = Columns };
        foreach (var id in _species.Where(s => s >= range.First && s <= range.Last))
            grid.Children.Add(Tile(id, editable));
        body.Children.Add(new ScrollViewer
        {
            Content = grid,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        });

        _host.Content = Workbench.Frame($"Pokédex · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape, body);
    }

    private Control Tile(int id, bool editable)
    {
        var (seen, caught) = _state[id];
        var content = new Grid();
        if (_sprites.Get(new SpriteLook(id, 0, false)) is { } sprite)
        {
            content.Children.Add(new Image
            {
                Source = sprite,
                Stretch = Stretch.Uniform,
                Margin = new Thickness(4, 4, 4, 18),
                Opacity = caught ? 1.0 : seen ? 0.55 : 0.2,
            });
        }
        var status = caught ? "caught" : seen ? "seen" : "—";
        var label = Ui.Text($"#{id:000} {status}", 12, false, caught ? Ui.Gold : seen ? Ui.Ink : Ui.Dim);
        label.HorizontalAlignment = HorizontalAlignment.Center;
        label.VerticalAlignment = VerticalAlignment.Bottom;
        content.Children.Add(label);

        var button = new Button
        {
            Content = content,
            Height = 100,
            Margin = new Thickness(3),
            Padding = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalContentAlignment = VerticalAlignment.Stretch,
            Background = Ui.Panel,
            BorderBrush = caught ? Ui.Accent : Ui.Clear,
            BorderThickness = new Thickness(2),
            CornerRadius = new CornerRadius(8),
            IsEnabled = editable,
        };
        button.Click += (_, _) => Cycle(id);
        return button;
    }

    private void Cycle(int id)
    {
        var (seen, caught) = _state[id];
        // not seen -> seen -> caught -> not seen
        var next = caught ? (false, false) : seen ? (true, true) : (true, false);
        if (Apply(id, next.Item1, next.Item2)) Render();
    }

    private bool Apply(int id, bool seen, bool caught)
    {
        try
        {
            _bench!.Session.SetDexEntry(id, seen, caught);
            var entry = _bench.Session.GetDexEntry(id);
            _state[id] = (entry.Seen, entry.Caught);
            _dirty = true;
            _confirmDiscard = false;
            _note = "";
            return true;
        }
        catch (Exception error)
        {
            _note = error.Message;
            Render();
            return false;
        }
    }

    private void SetRange(bool seen, bool caught)
    {
        var range = CollectionDex.GenRanges.First(r => r.Generation == _gen);
        foreach (var id in _species.Where(s => s >= range.First && s <= range.Last))
            if (!Apply(id, seen, caught)) return;
        Render();
    }

    private void CompleteAll()
    {
        try
        {
            _bench!.Session.CompleteDex();
            LoadStates();
            _dirty = true;
            _confirmDiscard = false;
            _note = "Every species is now seen and caught. Tap Save to keep it.";
        }
        catch (Exception error) { _note = error.Message; }
        Render();
    }

    private async Task SaveAsync()
    {
        var bench = _bench;
        if (bench is null) return;
        try
        {
            _note = await bench.CommitAsync("Edited the Pokédex in PKForge");
            await Task.Run(LoadStates);
            _dirty = false;
            _confirmDiscard = false;
        }
        catch (Exception error) { _note = "Could not save: " + error.Message; }
        Render();
    }
}
