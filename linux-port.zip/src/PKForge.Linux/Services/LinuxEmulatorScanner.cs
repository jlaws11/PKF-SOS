using PKForge.Domain;
using PKForge.Infrastructure;

namespace PKForge.Linux.Services;

/// <summary>What a scan found, plus the evidence for "why wasn't my save found?".</summary>
public sealed class ScanReport
{
    public List<DetectedSave> Saves { get; set; } = [];
    public int FilesSeen { get; set; }
    public List<string> Rejected { get; } = [];
    public List<string> Log { get; } = [];
}

/// <summary>
/// Walks a normal folder looking for parseable Pokémon saves: the Linux twin of the Android scanner.
/// File names are only a pre-filter; every candidate's bytes must pass the engine before it is listed.
/// </summary>
public sealed class LinuxEmulatorScanner(ISaveEngine engine)
{
    private const long MaxSaveBytes = 32L * 1024 * 1024;
    private const int MaxDepth = 8;

    /// <summary>Emulator folders that can never hold saves, pruned so a whole-emulator folder stays fast.</summary>
    private static readonly HashSet<string> PrunedDirectories = new(StringComparer.OrdinalIgnoreCase)
    {
        "assets", "autoconfig", "cheats", "config", "cores", "database", "downloads", "filters",
        "info", "logs", "overlays", "playlists", "remaps", "screenshots", "shaders", "states",
        "system", "thumbnails", "cache", "temp", "roms", "shader_cache",
    };

    /// <param name="kind">null = detect: look for a 3DS layout and for flat save files.</param>
    public Task<ScanReport> ScanAsync(string folder, EmulatorKind? kind, CancellationToken cancellationToken) =>
        Task.Run(() => Scan(folder, kind, cancellationToken), cancellationToken);

    private ScanReport Scan(string folder, EmulatorKind? kind, CancellationToken cancellationToken)
    {
        var report = new ScanReport();
        if (!Directory.Exists(folder))
        {
            report.Log.Add("Folder not found: " + folder);
            return report;
        }

        var found = new List<DetectedSave>();
        try
        {
            if (kind is null)
            {
                found.AddRange(ScanThreeDs(folder, EmulatorKind.Azahar, report, cancellationToken));
                found.AddRange(ScanFlat(folder, EmulatorKind.RetroArch, report, cancellationToken));
            }
            else if (kind is EmulatorKind.Azahar or EmulatorKind.CitraMmj)
            {
                found.AddRange(ScanThreeDs(folder, kind.Value, report, cancellationToken));
            }
            else
            {
                found.AddRange(ScanFlat(folder, kind.Value, report, cancellationToken));
            }
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception error)
        {
            report.Log.Add("Scan stopped by an error: " + error.Message);
        }

        report.Saves = EmulatorSaveHeuristics.Normalize(found);
        return report;
    }

    private static bool IsDirectory(FileSystemInfo info) => Directory.Exists(info.FullName);

    private static bool IsPruned(string folderName, EmulatorKind kind) =>
        PrunedDirectories.Contains(folderName)
        && (kind == EmulatorKind.RetroArch || !string.Equals(folderName, "roms", StringComparison.OrdinalIgnoreCase));

    private List<DetectedSave> ScanFlat(string root, EmulatorKind kind, ScanReport report, CancellationToken cancellationToken)
    {
        var results = new List<DetectedSave>();
        Walk(new DirectoryInfo(root), MaxDepth);
        return results;

        void Walk(DirectoryInfo directory, int depth)
        {
            cancellationToken.ThrowIfCancellationRequested();
            FileSystemInfo[] children;
            try { children = directory.GetFileSystemInfos(); }
            catch (Exception) { return; } // unreadable folder: skip it

            var siblings = children.Where(c => !IsDirectory(c)).Select(c => c.Name).ToArray();
            foreach (var child in children)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (IsDirectory(child))
                {
                    if (depth > 1 && !IsPruned(child.Name, kind))
                        Walk(new DirectoryInfo(child.FullName), depth - 1);
                    continue;
                }

                report.FilesSeen++;
                if (!EmulatorSaveHeuristics.IsCandidateFileName(child.Name, kind)) continue;
                var save = TryDetect(child.FullName, kind, child.Name, siblings);
                if (save is not null) results.Add(save);
                else report.Rejected.Add(child.Name);
            }
        }
    }

    /// <summary>Citra-family 3DS (Azahar, Lime3DS): sdmc/Nintendo 3DS/ID0/ID1/title/00040000/game/data/00000001/main.</summary>
    private List<DetectedSave> ScanThreeDs(string root, EmulatorKind kind, ScanReport report, CancellationToken cancellationToken)
    {
        var results = new List<DetectedSave>();

        IEnumerable<TreeEntry<FileSystemInfo>> ListChildren(FileSystemInfo node)
        {
            var directory = node as DirectoryInfo ?? (Directory.Exists(node.FullName) ? new DirectoryInfo(node.FullName) : null);
            if (directory is null) return [];
            try
            {
                return directory.GetFileSystemInfos()
                    .Select(x => new TreeEntry<FileSystemInfo>(x.Name, IsDirectory(x), x))
                    .ToList();
            }
            catch (Exception)
            {
                return [];
            }
        }

        FileSystemInfo rootNode = new DirectoryInfo(root);
        var rootName = Path.GetFileName(root.TrimEnd('/'));
        foreach (var hit in ThreeDsSaveLayout.FindMainSaves<FileSystemInfo>(
                     rootNode, rootName, ListChildren, line => report.Log.Add(line), cancellationToken))
        {
            report.FilesSeen++;
            var save = TryDetect(hit.File.FullName, kind, $"3DS save ({hit.TitleId})", null);
            if (save is not null) results.Add(save);
            else report.Rejected.Add($"3DS save {hit.TitleId}");
        }
        return results;
    }

    /// <summary>Reads a candidate and reports it only if the engine can parse its bytes.</summary>
    private DetectedSave? TryDetect(string path, EmulatorKind kind, string gameLabel, IReadOnlyList<string>? siblings)
    {
        try
        {
            var info = new FileInfo(path);
            // Saves are small; a ROM or archive with a matching extension must not stall the scan.
            if (!info.Exists || info.Length == 0 || info.Length > MaxSaveBytes) return null;

            var bytes = File.ReadAllBytes(path);
            var description = engine.TryDescribe(bytes, info.Name);
            if (description is null) return null;

            var romName = EmulatorSaveHeuristics.FindSiblingRom(info.Name, siblings);
            var guess = SaveIdentityRules.Guess(description.GameName, description.Generation, info.Name, romName, gameLabel);
            return new DetectedSave(
                path,
                info.Name,
                guess.Label,
                kind,
                EmulatorSaveHeuristics.RequiresExtraCare(kind),
                new DateTimeOffset(info.LastWriteTimeUtc),
                Generation: description.Generation,
                TrainerName: description.TrainerName,
                PlayTime: description.PlayTime,
                Guess: guess,
                RomFileName: romName,
                FolderHint: EmulatorSaveHeuristics.FolderHint(path),
                Language: description.Language);
        }
        catch (Exception)
        {
            return null; // unreadable candidates are simply not saves
        }
    }
}
