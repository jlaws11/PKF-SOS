using PKForge.Domain;
using PKForge.Engine;
using PKForge.Infrastructure;

namespace PKForge.Linux.Services;

/// <summary>What the autopilot read: planner input plus the files behind it.</summary>
public sealed record LivingDexShelf(
    LivingDexCatalog Catalog,
    IReadOnlyList<LivingDexSource> Sources,
    IReadOnlyDictionary<string, DetectedSave> Saves);

/// <summary>Every save found in the watched folders, shared by all screens.</summary>
public static class Shelf
{
    private static readonly Dictionary<string, List<DetectedSave>> ByFolder = new(StringComparer.Ordinal);
    private static readonly Lock Gate = new();

    public static void Set(string folder, IEnumerable<DetectedSave> saves)
    {
        lock (Gate) ByFolder[folder] = [.. saves];
    }

    public static void Forget(string folder)
    {
        lock (Gate) ByFolder.Remove(folder);
    }

    public static IReadOnlyList<DetectedSave> All
    {
        get
        {
            lock (Gate)
            {
                var seen = new HashSet<string>(StringComparer.Ordinal);
                return [.. ByFolder.Values.SelectMany(x => x).Where(s => seen.Add(s.DocumentId))];
            }
        }
    }

    /// <summary>"Pokémon HeartGold" → "HeartGold": every label on the plan is a cartridge name.</summary>
    public static string CartridgeName(string label)
    {
        var trimmed = System.Text.RegularExpressions.Regex
            .Replace(label.Normalize(System.Text.NormalizationForm.FormC), @"(?i)^pok[eé]mon\s+", "").Trim();
        return trimmed.Length > 0 ? trimmed : label;
    }

    /// <summary>Reads every save and the Bank into planner sources, deciding which saves are off limits and why.</summary>
    public static async Task<LivingDexShelf> ReadAsync(IProgress<string>? progress, CancellationToken cancellationToken)
    {
        var visible = All;
        var catalog = await Task.Run(LivingDexCatalogBuilder.Build, cancellationToken).ConfigureAwait(false);
        var sources = new List<LivingDexSource>();
        var saves = new Dictionary<string, DetectedSave>(StringComparer.Ordinal);

        await Task.Run(async () =>
        {
            foreach (var save in visible)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (!saves.TryAdd(save.DocumentId, save)) continue;
                var label = CartridgeName(save.GameLabel);
                progress?.Report($"Reading {label}…");
                try
                {
                    var bytes = await Svc.Access.ReadAsync(save.DocumentId, cancellationToken).ConfigureAwait(false);
                    using var session = Svc.Engine.OpenSession(bytes, save.EngineHint, save.Format);
                    var (exclusion, reason) = Judge(save, session);
                    sources.Add(LivingDexSources.FromSession(save.DocumentId, label, session, bytes.Span, exclusion, reason, Caution(save)));
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception error)
                {
                    sources.Add(new LivingDexSource(save.DocumentId, label, LivingDexSourceKind.Save, save.Generation, 0, [],
                        LivingDexExclusion.Unreadable, $"Could not be read: {error.Message}"));
                }
            }
            sources.Add(LivingDexSources.FromBank(Svc.Bank));
        }, cancellationToken).ConfigureAwait(false);
        return new LivingDexShelf(catalog, sources, saves);
    }

    private static (LivingDexExclusion, string?) Judge(DetectedSave save, ISaveEngineSession session)
    {
        var hack = save.Format is SaveFormat.Unbound or SaveFormat.RadicalRed or SaveFormat.GsChronicles
            || session is not SaveEngineSession
            || Svc.Writer.LayoutRiskOf(save.DocumentId, session.Snapshot) is not null
            || session.GameNames.Any(n => n.Contains("Luminescent", StringComparison.OrdinalIgnoreCase)
                                          || n.Contains("Compass", StringComparison.OrdinalIgnoreCase));
        if (hack) return (LivingDexExclusion.RomHack, null);
        if (Svc.Writer.WhyWritesAreRefused(save.DocumentId, session.Snapshot) is { } refusal)
            return (LivingDexExclusion.ReadOnly, refusal);
        if (!session.SupportsBoxTools) return (LivingDexExclusion.Unsupported, null);
        return (LivingDexExclusion.None, null);
    }

    /// <summary>No API tells whether an emulator holds the file; a fresh write is the tell.</summary>
    public static string? Caution(DetectedSave save)
    {
        if (save.RequiresExtraCare) return $"{save.Emulator} console storage: close the emulator before applying.";
        if (save.LastModified is { } modified && DateTimeOffset.UtcNow - modified < TimeSpan.FromMinutes(10))
            return $"Saved {Math.Max(1, (int)(DateTimeOffset.UtcNow - modified).TotalMinutes)} min ago: close the game in the emulator first.";
        return null;
    }
}
