namespace PKForge.Linux.Services;

public static class AppPaths
{
    public static string Home => Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

    /// <summary>Settings and crash notes live here (~/.local/share/PKForge).</summary>
    public static string DataDir
    {
        get
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PKForge");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    public static void LogCrash(string text)
    {
        try { File.AppendAllText(Path.Combine(DataDir, "crash.log"), $"[{DateTime.Now:O}] {text}\n\n"); }
        catch (Exception) { /* nowhere left to report to */ }
    }
}
