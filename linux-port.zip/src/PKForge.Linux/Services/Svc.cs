using PKForge.Domain;
using PKForge.Engine;
using PKForge.Infrastructure;

namespace PKForge.Linux.Services;

/// <summary>
/// The app's long-lived services, wired the same way the Android app wires them in MauiProgram:
/// one engine, one safe writer (validate, back up, write atomically), one bank.
/// </summary>
public static class Svc
{
    public static readonly ISaveEngine Engine = new SaveEngine();
    public static readonly IGameDataService Data = new GameDataService();
    public static readonly ISaveFileAccess Access = new LinuxSaveFileAccess();
    public static readonly IBackupService Backups = new FileBackupService(Path.Combine(AppPaths.DataDir, "backups"));
    public static readonly IBankService Bank = new FileBankService(Path.Combine(AppPaths.DataDir, "bank"));
    public static readonly ISaveIdentityStore Identities = new JsonSaveIdentityStore(Path.Combine(AppPaths.DataDir, "save-identities.json"));
    public static readonly ISafeSaveWriter Writer = new SafeSaveWriter(Engine, Backups, Access, Identities);
    public static readonly ISaveSessionService Sessions = new SaveSessionService(Access, Engine, Identities);
    public static readonly IEvolutionService Evolutions = new EvolutionService();
    public static readonly ILegalityService Legality = new LegalityService();
    public static readonly ILegalizerService Legalizer = new LegalizerService();
    private static readonly Lazy<IEncounterLookup> EncounterDb = new(() => new EncounterLookupService());
    /// <summary>"Where can I get this?" for any species; built on first use because it loads the encounter tables.</summary>
    public static IEncounterLookup Encounters => EncounterDb.Value;

    public static readonly IEventDatabaseService Events = new EventDatabaseService();

    public static readonly TransferService Transfers = new(Engine, Writer, Access, Sessions, Legality);

    public static LivingDexExecutor CreateLivingDexExecutor() =>
        new(Engine, Writer, Access, Bank, Evolutions, Legality);

    public static string SpeciesName(int species) =>
        species >= 0 && species < Data.SpeciesNames.Count && Data.SpeciesNames[species].Length > 0
            ? Data.SpeciesNames[species]
            : "#" + species;
}
