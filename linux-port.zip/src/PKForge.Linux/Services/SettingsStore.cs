using System.Text.Json;

namespace PKForge.Linux.Services;

/// <summary>A folder the player pointed the app at. Kind -1 means detect automatically.</summary>
public sealed class WatchedFolder
{
    public string Path { get; set; } = "";
    public int Kind { get; set; } = -1;
}

public sealed class AppSettings
{
    public List<WatchedFolder> Folders { get; set; } = [];
    /// <summary>First Bank box of the living dex region, once a run created it.</summary>
    public int? BankStartBox { get; set; }
    /// <summary>Custom trainer-card pictures, keyed by the save's document id; the value is a copied image file.</summary>
    public Dictionary<string, string> Avatars { get; set; } = [];
}

public static class SettingsStore
{
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };

    private static string FilePath => System.IO.Path.Combine(AppPaths.DataDir, "settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings();
        }
        catch (Exception error) { AppPaths.LogCrash("settings load: " + error); }
        return new AppSettings();
    }

    public static void Save(AppSettings settings)
    {
        try { File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, Options)); }
        catch (Exception error) { AppPaths.LogCrash("settings save: " + error); }
    }
}
