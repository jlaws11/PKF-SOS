using Avalonia.Media.Imaging;
using PKForge.Domain;

namespace PKForge.Linux.Services;

/// <summary>Loads the bundled PKHeX sprites from assets/, using the same candidate order as the Android app.</summary>
public sealed class SpriteStore
{
    private readonly string _root = Path.Combine(AppContext.BaseDirectory, "assets");
    private readonly Dictionary<string, Bitmap?> _cache = [];

    public Bitmap? Get(SpriteLook look)
    {
        if (_cache.TryGetValue(look.CacheKey, out var cached)) return cached;
        Bitmap? bitmap = null;
        foreach (var candidate in SpriteCatalog.BundledCandidates(look))
        {
            var path = Path.Combine(_root, candidate.Path);
            if (!File.Exists(path)) continue;
            try
            {
                bitmap = new Bitmap(path);
                break;
            }
            catch (Exception) { /* a broken file falls through to the next candidate */ }
        }
        _cache[look.CacheKey] = bitmap;
        return bitmap;
    }
}
