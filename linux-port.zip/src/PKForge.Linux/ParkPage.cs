using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>One Pokémon living in the park. This lives only in PKForge's own file: it never touches a save or the Bank.</summary>
public sealed class ParkResident
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public int Species { get; set; }
    public int Form { get; set; }
    public bool Shiny { get; set; }
    public string Name { get; set; } = "";
    public double Fullness { get; set; } = 70;
    public double Joy { get; set; } = 60;
    public DateTimeOffset Updated { get; set; } = DateTimeOffset.UtcNow;
}

internal static class ParkStore
{
    private static string FilePath => System.IO.Path.Combine(AppPaths.DataDir, "park.json");

    public static List<ParkResident> Load()
    {
        try
        {
            if (File.Exists(FilePath))
                return JsonSerializer.Deserialize<List<ParkResident>>(File.ReadAllText(FilePath)) ?? [];
        }
        catch (Exception error) { AppPaths.LogCrash("park load: " + error); }
        return [];
    }

    public static void Save(List<ParkResident> residents)
    {
        try { File.WriteAllText(FilePath, JsonSerializer.Serialize(residents)); }
        catch (Exception error) { AppPaths.LogCrash("park save: " + error); }
    }
}

/// <summary>
/// The Park: Pokémon you invite wander around, chat, get hungry and lonely. Pet them and feed them.
/// It is a mini-game only; nothing here reads or changes your saves.
/// </summary>
public sealed class ParkPage : IScreen
{
    private const int MaxResidents = 10;
    private const double SpriteSize = 104;

    private sealed class Walker
    {
        public required ParkResident Who { get; init; }
        public required Button Body { get; init; }
        public required Border Bubble { get; init; }
        public required TextBlock BubbleText { get; init; }
        public double X, Y, TX, TY;
        public double Speed = 40;
        public DateTime PauseUntil = DateTime.MinValue;
        public DateTime BubbleUntil = DateTime.MinValue;
    }

    private sealed class Particle
    {
        public required Control Visual { get; init; }
        public double X, Y, VX, VY, Age, Life;
    }

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;

    private readonly List<ParkResident> _residents = ParkStore.Load();
    private readonly List<Walker> _walkers = [];
    private readonly List<Particle> _particles = [];
    private readonly Canvas _canvas = new() { ClipToBounds = true };
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(50) };
    private readonly Random _rng = new();

    private Walker? _selected;
    private bool _inviting;
    private DateTime _last = DateTime.UtcNow;
    private DateTime _nextChat = DateTime.UtcNow.AddSeconds(3);
    private DateTime _nextSave = DateTime.UtcNow.AddSeconds(30);
    private DateTime _nextDecay = DateTime.UtcNow.AddSeconds(5);
    private (Walker Who, string Line, DateTime At)? _reply;
    private string _note = "";

    private readonly TextBlock _nameText = Ui.Text("", 22, true);
    private readonly TextBlock _stateText = Ui.Text("", 15, false, Ui.Dim);
    private readonly Border _fullBar = new() { Height = 14, CornerRadius = new CornerRadius(7), HorizontalAlignment = HorizontalAlignment.Left };
    private readonly Border _joyBar = new() { Height = 14, CornerRadius = new CornerRadius(7), HorizontalAlignment = HorizontalAlignment.Left };
    private const double BarWidth = 180;

    public ParkPage(ContentControl host, SpriteStore sprites, Action close)
    {
        _host = host;
        _sprites = sprites;
        _close = close;
        _timer.Tick += (_, _) => Tick();
        _canvas.PropertyChanged += (_, e) =>
        {
            if (e.Property == Visual.BoundsProperty) Decorate();
        };
    }

    public IReadOnlyList<(string Button, string Label)> PadHints => _inviting ? [] : [("A", "Pet"), ("X", "Feed")];

    public bool OnKey(Key key)
    {
        if (_inviting) return false;
        if (key == Key.X) { Feed(); return true; }
        return false;
    }

    public void Escape()
    {
        if (_inviting) { _inviting = false; Show(); return; }
        _timer.Stop();
        ParkStore.Save(_residents);
        _close();
    }

    // ───────────────────────── the park ─────────────────────────

    public void Start() => Show();

    private void Show()
    {
        _timer.Stop();
        _walkers.Clear();
        _particles.Clear();
        _canvas.Children.Clear();
        _selected = null;
        CatchUp();

        var sky = new LinearGradientBrush
        {
            StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative),
            EndPoint = new RelativePoint(0, 1, RelativeUnit.Relative),
            GradientStops =
            [
                new GradientStop(Color.Parse("#8FD3F4"), 0.0),
                new GradientStop(Color.Parse("#B9E7C0"), 0.28),
                new GradientStop(Color.Parse("#6FBF73"), 0.30),
                new GradientStop(Color.Parse("#4E9F5B"), 1.0),
            ],
        };
        var stage = new Border { Background = sky, CornerRadius = new CornerRadius(14), ClipToBounds = true, Child = _canvas };
        foreach (var resident in _residents) AddWalker(resident);
        if (_residents.Count == 0)
        {
            var empty = Ui.Text("The park is empty. Invite a Pokémon to move in!", 26, true, Brushes.White);
            empty.HorizontalAlignment = HorizontalAlignment.Center;
            empty.VerticalAlignment = VerticalAlignment.Center;
            var wrap = new Grid();
            wrap.Children.Add(empty);
            stage.Child = null;
            stage.Child = new Grid { Children = { _canvas, wrap } };
        }

        var body = new DockPanel();
        var panel = BottomPanel();
        DockPanel.SetDock(panel, Dock.Bottom);
        body.Children.Add(panel);
        body.Children.Add(stage);
        _host.Content = Workbench.Frame("Park", Escape, body, "‹ Home");
        Select(_walkers.FirstOrDefault());
        _last = DateTime.UtcNow;
        _timer.Start();
    }

    private Control BottomPanel()
    {
        _fullBar.Background = new SolidColorBrush(Color.Parse("#E8913A"));
        _joyBar.Background = new SolidColorBrush(Color.Parse("#E55D87"));

        Control Meter(string label, Border bar)
        {
            var track = new Border
            {
                Width = BarWidth,
                Height = 14,
                CornerRadius = new CornerRadius(7),
                Background = Ui.Bg,
                Child = bar,
            };
            var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
            var name = Ui.Text(label, 15);
            name.Width = 92;
            name.VerticalAlignment = VerticalAlignment.Center;
            row.Children.Add(name);
            row.Children.Add(track);
            return row;
        }

        var info = new StackPanel { Spacing = 4, MinWidth = 330 };
        info.Children.Add(_nameText);
        info.Children.Add(Meter("Fullness", _fullBar));
        info.Children.Add(Meter("Happiness", _joyBar));
        info.Children.Add(_stateText);

        var pet = Ui.Btn("Pet", Pet, primary: true);
        var feed = Ui.Btn("Feed berry", Feed);
        var home = Ui.Btn("Send home", SendHome);
        var invite = Ui.Btn("Invite…", () => { _timer.Stop(); _inviting = true; _ = ShowInviteAsync(); });
        invite.IsEnabled = _residents.Count < MaxResidents;
        foreach (var b in new[] { pet, feed, home, invite }) { b.MinWidth = 0; b.MinHeight = 52; b.FontSize = 17; b.Padding = new Thickness(14, 4); }
        var buttons = new WrapPanel { ItemSpacing = 8, LineSpacing = 8, VerticalAlignment = VerticalAlignment.Center };
        buttons.Children.Add(pet);
        buttons.Children.Add(feed);
        buttons.Children.Add(home);
        buttons.Children.Add(invite);

        var row2 = new DockPanel { Margin = new Thickness(0, 10, 0, 0) };
        DockPanel.SetDock(info, Dock.Left);
        row2.Children.Add(info);
        row2.Children.Add(buttons);
        return new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(12), Padding = new Thickness(16, 10), Margin = new Thickness(0, 10, 0, 0), Child = row2 };
    }

    private void Decorate()
    {
        foreach (var old in _canvas.Children.Where(c => c.Tag as string == "decor").ToList()) _canvas.Children.Remove(old);
        var w = _canvas.Bounds.Width;
        var h = _canvas.Bounds.Height;
        if (w < 100 || h < 100) return;
        var decor = new List<Control>();
        void Place(Control c, double x, double y) { c.Tag = "decor"; c.IsHitTestVisible = false; Canvas.SetLeft(c, x); Canvas.SetTop(c, y); decor.Add(c); }
        Place(new Ellipse { Width = w * 0.22, Height = h * 0.16, Fill = new SolidColorBrush(Color.Parse("#4DA3D9")), Stroke = new SolidColorBrush(Color.Parse("#9ADBF7")), StrokeThickness = 4 }, w * 0.68, h * 0.66);
        foreach (var (fx, fy) in new[] { (0.06, 0.06), (0.30, 0.02), (0.55, 0.05), (0.88, 0.04) })
        {
            Place(new Rectangle { Width = 14, Height = 40, Fill = new SolidColorBrush(Color.Parse("#7A5230")) }, w * fx + 28, h * fy + 70);
            Place(new Ellipse { Width = 70, Height = 80, Fill = new SolidColorBrush(Color.Parse("#2F8A48")) }, w * fx, h * fy);
        }
        var colours = new[] { "#FFFFFF", "#FFD54F", "#F48FB1", "#FFAB91" };
        var r = new Random(7);
        for (var i = 0; i < 26; i++)
            Place(new Ellipse { Width = 9, Height = 9, Fill = new SolidColorBrush(Color.Parse(colours[i % colours.Length])) }, r.NextDouble() * w, h * 0.34 + r.NextDouble() * h * 0.62);
        for (var i = decor.Count - 1; i >= 0; i--) _canvas.Children.Insert(0, decor[i]);
    }

    // ───────────────────────── residents ─────────────────────────

    private void AddWalker(ParkResident who)
    {
        var picture = new Image { Width = SpriteSize - 8, Height = SpriteSize - 8, Stretch = Stretch.Uniform };
        if (_sprites.Get(new SpriteLook(who.Species, who.Form, who.Shiny)) is { } bitmap) picture.Source = bitmap;
        var body = new Button
        {
            Content = picture,
            Width = SpriteSize,
            Height = SpriteSize,
            Padding = new Thickness(0),
            Background = Brushes.Transparent,
            BorderBrush = Brushes.Transparent,
            BorderThickness = new Thickness(0),
            CornerRadius = new CornerRadius(14),
        };
        var text = new TextBlock { FontSize = 15, Foreground = new SolidColorBrush(Color.Parse("#1B2447")), TextWrapping = TextWrapping.Wrap, MaxWidth = 190, TextAlignment = TextAlignment.Center };
        var bubble = new Border
        {
            Background = Brushes.White,
            CornerRadius = new CornerRadius(12),
            Padding = new Thickness(10, 6),
            BorderBrush = new SolidColorBrush(Color.Parse("#1B2447")),
            BorderThickness = new Thickness(2),
            IsVisible = false,
            IsHitTestVisible = false,
            Child = text,
        };
        var walker = new Walker { Who = who, Body = body, Bubble = bubble, BubbleText = text };
        body.Click += (_, _) => { Select(walker); Pet(); };
        body.AddHandler(InputElement.GotFocusEvent, (s, e) => Select(walker));
        _walkers.Add(walker);
        _canvas.Children.Add(body);
        _canvas.Children.Add(bubble);

        walker.X = 80 + _rng.NextDouble() * 500;
        walker.Y = 150 + _rng.NextDouble() * 200;
        walker.TX = walker.X;
        walker.TY = walker.Y;
        walker.Speed = 28 + _rng.NextDouble() * 30;
        walker.PauseUntil = DateTime.UtcNow.AddSeconds(_rng.NextDouble() * 2);
        Place(walker);
    }

    private static void Place(Walker w)
    {
        Canvas.SetLeft(w.Body, w.X);
        Canvas.SetTop(w.Body, w.Y);
        Canvas.SetLeft(w.Bubble, w.X - 40);
        Canvas.SetTop(w.Bubble, w.Y - 46);
    }

    private void Select(Walker? walker)
    {
        _selected = walker;
        RefreshMeters();
    }

    private void RefreshMeters()
    {
        if (_selected is null)
        {
            _nameText.Text = _residents.Count == 0 ? "Nobody here yet" : "Tap a Pokémon";
            _fullBar.Width = 0;
            _joyBar.Width = 0;
            _stateText.Text = _note;
            return;
        }
        var who = _selected.Who;
        _nameText.Text = who.Name;
        _fullBar.Width = BarWidth * Math.Clamp(who.Fullness, 0, 100) / 100;
        _joyBar.Width = BarWidth * Math.Clamp(who.Joy, 0, 100) / 100;
        _stateText.Text = _note.Length > 0 ? _note : Mood(who);
    }

    private static string Mood(ParkResident who) =>
        who.Fullness < 25 ? "Very hungry!" :
        who.Joy < 30 ? "Feeling lonely." :
        who.Joy > 75 && who.Fullness > 50 ? "Having the best time!" :
        "Doing fine.";

    // ───────────────────────── actions ─────────────────────────

    private void Pet()
    {
        if (_selected is not { } w) return;
        w.Who.Joy = Math.Min(100, w.Who.Joy + 12);
        w.PauseUntil = DateTime.UtcNow.AddSeconds(2.5);
        Burst(w, "♥", "#E55D87", 4);
        Say(w, w.Who.Joy > 70 ? Pick("So happy!", "Hehe, that tickles!", "More, please!") : Pick("Thank you!", "That feels nice.", "Aww…"));
        _note = "";
        ParkStore.Save(_residents);
        RefreshMeters();
    }

    private void Feed()
    {
        if (_selected is not { } w) return;
        if (w.Who.Fullness >= 96)
        {
            Say(w, Pick("I'm stuffed!", "No more, I'm full!", "Maybe later…"));
            return;
        }
        w.Who.Fullness = Math.Min(100, w.Who.Fullness + 28);
        w.Who.Joy = Math.Min(100, w.Who.Joy + 4);
        w.PauseUntil = DateTime.UtcNow.AddSeconds(3);
        Burst(w, "●", "#D93B3B", 3);
        Say(w, Pick("Yum!", "Delicious berry!", "Nom nom nom!"));
        _note = "";
        ParkStore.Save(_residents);
        RefreshMeters();
    }

    private void SendHome()
    {
        if (_selected is not { } w) return;
        _residents.Remove(w.Who);
        ParkStore.Save(_residents);
        Show();
    }

    // ───────────────────────── the clock ─────────────────────────

    /// <summary>Hunger and loneliness keep ticking while the app is closed, but never past "a bit sad".</summary>
    private void CatchUp()
    {
        var now = DateTimeOffset.UtcNow;
        foreach (var r in _residents) Decay(r, now);
    }

    private static void Decay(ParkResident r, DateTimeOffset now)
    {
        var minutes = Math.Clamp((now - r.Updated).TotalMinutes, 0, 8 * 60);
        r.Updated = now;
        if (minutes <= 0) return;
        r.Fullness = Math.Max(8, r.Fullness - minutes * 0.7);
        var lonely = r.Fullness < 30 ? 0.9 : 0.25;
        r.Joy = Math.Max(10, r.Joy - minutes * lonely);
    }

    private void Tick()
    {
        var now = DateTime.UtcNow;
        var dt = Math.Min(0.25, (now - _last).TotalSeconds);
        _last = now;
        var w = _canvas.Bounds.Width;
        var h = _canvas.Bounds.Height;

        foreach (var walker in _walkers)
        {
            if (walker.BubbleUntil < now) walker.Bubble.IsVisible = false;
            if (walker == _selected && walker.PauseUntil > now) { Place(walker); continue; }
            if (walker.PauseUntil > now) continue;
            var dx = walker.TX - walker.X;
            var dy = walker.TY - walker.Y;
            var dist = Math.Sqrt(dx * dx + dy * dy);
            if (dist < 4)
            {
                walker.PauseUntil = now.AddSeconds(1.5 + _rng.NextDouble() * 4);
                if (w > 200 && h > 200)
                {
                    walker.TX = 20 + _rng.NextDouble() * Math.Max(10, w - SpriteSize - 40);
                    walker.TY = h * 0.30 + _rng.NextDouble() * Math.Max(10, h * 0.70 - SpriteSize - 20);
                }
                continue;
            }
            var speed = walker.Who.Fullness < 25 ? walker.Speed * 0.5 : walker.Speed;
            var step = Math.Min(dist, speed * dt);
            walker.X += dx / dist * step;
            walker.Y += dy / dist * step;
            Place(walker);
        }

        if (_reply is { } pending && pending.At <= now)
        {
            Say(pending.Who, pending.Line);
            _reply = null;
        }
        if (_walkers.Count >= 1 && now >= _nextChat)
        {
            Chat();
            _nextChat = now.AddSeconds(3 + _rng.NextDouble() * 4);
        }
        if (now >= _nextDecay)
        {
            foreach (var r in _residents) Decay(r, DateTimeOffset.UtcNow);
            _nextDecay = now.AddSeconds(5);
            RefreshMeters();
        }
        if (now >= _nextSave)
        {
            ParkStore.Save(_residents);
            _nextSave = now.AddSeconds(30);
        }
        MoveParticles(dt);
    }

    // ───────────────────────── chat and effects ─────────────────────────

    private static string Pick(params string[] lines) => lines[Random.Shared.Next(lines.Length)];

    private void Say(Walker w, string line)
    {
        w.BubbleText.Text = line;
        w.Bubble.IsVisible = true;
        w.BubbleUntil = DateTime.UtcNow.AddSeconds(3.2);
        Place(w);
    }

    private void Chat()
    {
        var speaker = _walkers[_rng.Next(_walkers.Count)];
        var who = speaker.Who;
        var others = _walkers.Where(o => o != speaker).OrderBy(o => Dist(speaker, o)).ToList();
        var friend = others.FirstOrDefault();

        string line;
        var roll = _rng.NextDouble();
        if (who.Fullness < 30 && roll < 0.6) line = Pick("I'm so hungry…", "Is there any food around?", "My tummy is rumbling…");
        else if (who.Joy < 30 && roll < 0.6) line = Pick("Pet me?", "Feeling a bit lonely.", "Anyone there?");
        else if (friend is not null && roll < 0.55)
        {
            var other = friend.Who.Name;
            line = Pick($"Hi, {other}!", $"{other}! Over here!", $"Want to play, {other}?", $"Nice day, {other}!");
            _reply = (friend, Pick($"Hello, {who.Name}!", "Sure!", "Hehe, hi!", "Yeah!", $"{friend.Who.Name}!"), DateTime.UtcNow.AddSeconds(1.8));
        }
        else if (who.Joy > 70) line = Pick("I love it here!", "Best day ever!", "What a nice park.", "♪ ♪ ♪");
        else line = Pick($"{who.Name}!", $"{who.Name}, {who.Name}!", "Nice weather.", "Hmm hm hm…");
        Say(speaker, line);
    }

    private static double Dist(Walker a, Walker b) => Math.Abs(a.X - b.X) + Math.Abs(a.Y - b.Y);

    private void Burst(Walker w, string glyph, string colour, int count)
    {
        for (var i = 0; i < count; i++)
        {
            var visual = new TextBlock { Text = glyph, FontSize = 24, Foreground = new SolidColorBrush(Color.Parse(colour)), IsHitTestVisible = false };
            _canvas.Children.Add(visual);
            var p = new Particle
            {
                Visual = visual,
                X = w.X + 24 + _rng.NextDouble() * 50,
                Y = w.Y + 6,
                VX = (_rng.NextDouble() - 0.5) * 30,
                VY = -40 - _rng.NextDouble() * 30,
                Life = 1.1,
            };
            _particles.Add(p);
        }
    }

    private void MoveParticles(double dt)
    {
        for (var i = _particles.Count - 1; i >= 0; i--)
        {
            var p = _particles[i];
            p.Age += dt;
            if (p.Age >= p.Life)
            {
                _canvas.Children.Remove(p.Visual);
                _particles.RemoveAt(i);
                continue;
            }
            p.X += p.VX * dt;
            p.Y += p.VY * dt;
            p.Visual.Opacity = 1 - p.Age / p.Life;
            Canvas.SetLeft(p.Visual, p.X);
            Canvas.SetTop(p.Visual, p.Y);
        }
    }

    // ───────────────────────── inviting ─────────────────────────

    private async Task ShowInviteAsync()
    {
        _host.Content = Workbench.Frame("Invite to the park", Escape, Ui.Text("Looking at your collection…", 22));
        try
        {
            var shelf = await Shelf.ReadAsync(null, CancellationToken.None);
            var seen = new HashSet<(int, int, bool)>();
            var candidates = new List<(int Species, int Form, bool Shiny, string Name)>();
            foreach (var source in shelf.Sources)
            {
                if (source.IsExcluded && source.Exclusion is LivingDexExclusion.Unreadable) continue;
                foreach (var h in source.Holdings)
                {
                    if (h.IsEgg || !seen.Add((h.Species, h.Form, h.Shiny))) continue;
                    var name = string.IsNullOrWhiteSpace(h.Nickname) ? Svc.SpeciesName(h.Species) : h.Nickname!;
                    candidates.Add((h.Species, h.Form, h.Shiny, name));
                }
            }
            candidates.Sort((a, b) => a.Species.CompareTo(b.Species));

            var search = new TextBox { MinHeight = 46, FontSize = 18, Margin = new Thickness(0, 0, 0, 8) };
            var rows = new StackPanel { Spacing = 6 };
            void Fill(string term)
            {
                rows.Children.Clear();
                var t = term.Trim().ToLowerInvariant();
                var shown = 0;
                foreach (var c in candidates)
                {
                    if (t.Length > 0 && !c.Name.ToLowerInvariant().Contains(t) && !Svc.SpeciesName(c.Species).ToLowerInvariant().Contains(t)) continue;
                    if (shown++ >= 60) break;
                    var pick = c;
                    var line = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
                    if (_sprites.Get(new SpriteLook(c.Species, c.Form, c.Shiny)) is { } sprite)
                        line.Children.Add(new Image { Source = sprite, Width = 48, Height = 48, Stretch = Stretch.Uniform });
                    var label = Ui.Text((c.Shiny ? "★ " : "") + c.Name, 19);
                    label.VerticalAlignment = VerticalAlignment.Center;
                    line.Children.Add(label);
                    var button = new Button
                    {
                        Content = line,
                        MinHeight = 58,
                        Padding = new Thickness(8, 2),
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        HorizontalContentAlignment = HorizontalAlignment.Left,
                        Background = Ui.Panel,
                        CornerRadius = new CornerRadius(8),
                    };
                    button.Click += (_, _) =>
                    {
                        _residents.Add(new ParkResident { Species = pick.Species, Form = pick.Form, Shiny = pick.Shiny, Name = pick.Name });
                        ParkStore.Save(_residents);
                        _inviting = false;
                        Show();
                    };
                    rows.Children.Add(button);
                }
                if (shown == 0) rows.Children.Add(Ui.Text(candidates.Count == 0 ? "Nothing in your collection yet." : "No match.", 18, false, Ui.Dim));
            }
            search.PropertyChanged += (_, e) =>
            {
                if (e.Property == TextBox.TextProperty) Fill(search.Text ?? "");
            };
            Fill("");
            var body = new DockPanel();
            var hint = Ui.Text("Anything you own can move in (it only copies the picture and name; your save is never touched).", 16, false, Ui.Dim);
            DockPanel.SetDock(hint, Dock.Top);
            body.Children.Add(hint);
            DockPanel.SetDock(search, Dock.Top);
            body.Children.Add(search);
            body.Children.Add(new ScrollViewer { Content = rows, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });
            _host.Content = Workbench.Frame("Invite to the park", Escape, body);
        }
        catch (Exception error)
        {
            _host.Content = Workbench.Frame("Invite to the park", Escape, Ui.Text("Could not read your collection: " + error.Message, 20, false, Ui.Warn));
        }
    }
}
