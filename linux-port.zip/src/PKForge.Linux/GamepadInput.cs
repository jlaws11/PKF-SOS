using PKForge.Linux.Services;

namespace PKForge.Linux;

internal enum PadButton { Up, Down, Left, Right, A, B, X, Y, L1, R1, Start, Select }

/// <summary>
/// Reads game controllers straight from Linux's joystick devices (/dev/input/js*), so the Steam Deck's
/// buttons work without any extra libraries. Raises <see cref="Pressed"/> on a background thread; the window
/// moves it to the UI thread. Held directions repeat. Everything is best effort: no device, no problem.
/// </summary>
internal sealed class GamepadInput
{
    public event Action<PadButton>? Pressed;

    private readonly HashSet<string> _active = [];
    private readonly CancellationTokenSource _cts = new();

    public void Start() => _ = Task.Run(WatchAsync);

    public void Stop() => _cts.Cancel();

    private async Task WatchAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                if (Directory.Exists("/dev/input"))
                {
                    foreach (var path in Directory.GetFiles("/dev/input", "js*"))
                        StartReader(path, false);
                    // Steam's Gaming Mode hands games a virtual pad that may only exist as an event device.
                    foreach (var path in Directory.GetFiles("/dev/input", "event*"))
                        if (IsPadWithoutJoystickNode(Path.GetFileName(path))) StartReader(path, true);
                }
            }
            catch (Exception) { /* no controller support on this machine */ }
            try { await Task.Delay(3000, _cts.Token); } catch (OperationCanceledException) { return; }
        }
    }

    private void StartReader(string path, bool evdev)
    {
        lock (_active)
        {
            if (!_active.Add(path)) return;
        }
        AppPaths.LogCrash((evdev ? "pad (event) " : "pad (js) ") + path + " found");
        _ = Task.Factory.StartNew(() => Read(path, evdev), TaskCreationOptions.LongRunning);
    }

    /// <summary>True for an event device that has gamepad buttons and no /dev/input/js node (those are read as js).</summary>
    private static bool IsPadWithoutJoystickNode(string eventName)
    {
        try
        {
            var device = "/sys/class/input/" + eventName + "/device";
            if (!Directory.Exists(device)) return false;
            if (Directory.GetDirectories(device, "js*").Length > 0) return false;
            var caps = File.ReadAllText(device + "/capabilities/key").Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            // Bit 304 (BTN_SOUTH, the A button): 64-bit words, most significant first.
            var index = caps.Length - 1 - 304 / 64;
            if (index < 0) return false;
            return (Convert.ToUInt64(caps[index], 16) >> (304 % 64) & 1UL) != 0;
        }
        catch (Exception) { return false; }
    }

    private void Read(string path, bool evdev)
    {
        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1, false);
            var buffer = new byte[evdev ? 24 : 8];
            int hatX = 0, hatY = 0, stickX = 0, stickY = 0;
            PadButton? held = null;
            CancellationTokenSource? repeat = null;

            void Recompute()
            {
                PadButton? next = null;
                if (hatY < 0) next = PadButton.Up;
                else if (hatY > 0) next = PadButton.Down;
                else if (hatX < 0) next = PadButton.Left;
                else if (hatX > 0) next = PadButton.Right;
                else if (Math.Abs(stickY) > Math.Abs(stickX) && Math.Abs(stickY) > 0) next = stickY < 0 ? PadButton.Up : PadButton.Down;
                else if (stickX != 0) next = stickX < 0 ? PadButton.Left : PadButton.Right;
                if (next == held) return;
                repeat?.Cancel();
                held = next;
                if (next is not { } direction) return;
                Pressed?.Invoke(direction);
                var source = repeat = new CancellationTokenSource();
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(380, source.Token);
                        while (!source.IsCancellationRequested)
                        {
                            Pressed?.Invoke(direction);
                            await Task.Delay(110, source.Token);
                        }
                    }
                    catch (OperationCanceledException) { }
                });
            }

            void Button(PadButton? button) { if (button is { } pressed) Pressed?.Invoke(pressed); }

            while (stream.Read(buffer, 0, buffer.Length) == buffer.Length)
            {
                if (evdev)
                {
                    var type = BitConverter.ToUInt16(buffer, 16);
                    var code = BitConverter.ToUInt16(buffer, 18);
                    var value = BitConverter.ToInt32(buffer, 20);
                    if (type == 1)
                    {
                        if (value == 1)
                            Button(code switch
                            {
                                304 => PadButton.A, 305 => PadButton.B, 307 => PadButton.X, 308 => PadButton.Y,
                                310 => PadButton.L1, 311 => PadButton.R1, 314 => PadButton.Select, 315 => PadButton.Start,
                                _ => null,
                            });
                        // Some pads report the D-pad as buttons.
                        if (code is >= 544 and <= 547)
                        {
                            var on = value != 0 ? 1 : 0;
                            if (code == 544) hatY = on > 0 ? -1 : (hatY < 0 ? 0 : hatY);
                            else if (code == 545) hatY = on > 0 ? 1 : (hatY > 0 ? 0 : hatY);
                            else if (code == 546) hatX = on > 0 ? -1 : (hatX < 0 ? 0 : hatX);
                            else hatX = on > 0 ? 1 : (hatX > 0 ? 0 : hatX);
                            Recompute();
                        }
                    }
                    else if (type == 3)
                    {
                        switch (code)
                        {
                            case 16: hatX = Math.Sign(value); Recompute(); break;
                            case 17: hatY = Math.Sign(value); Recompute(); break;
                            case 0: stickX = Math.Abs(value) > 16000 ? Math.Sign(value) : 0; Recompute(); break;
                            case 1: stickY = Math.Abs(value) > 16000 ? Math.Sign(value) : 0; Recompute(); break;
                        }
                    }
                    continue;
                }

                var jsValue = BitConverter.ToInt16(buffer, 4);
                var isInitial = (buffer[6] & 0x80) != 0;
                var jsType = buffer[6] & 0x7F;
                var number = buffer[7];
                if (jsType == 1 && !isInitial && jsValue == 1)
                {
                    Button(number switch
                    {
                        0 => PadButton.A, 1 => PadButton.B, 2 => PadButton.X, 3 => PadButton.Y,
                        4 => PadButton.L1, 5 => PadButton.R1, 6 => PadButton.Select, 7 => PadButton.Start,
                        _ => null,
                    });
                }
                else if (jsType == 2)
                {
                    switch (number)
                    {
                        case 6: hatX = Math.Sign(jsValue); Recompute(); break;
                        case 7: hatY = Math.Sign(jsValue); Recompute(); break;
                        case 0: stickX = Math.Abs((int)jsValue) > 16000 ? Math.Sign(jsValue) : 0; Recompute(); break;
                        case 1: stickY = Math.Abs((int)jsValue) > 16000 ? Math.Sign(jsValue) : 0; Recompute(); break;
                    }
                }
            }
            repeat?.Cancel();
        }
        catch (Exception error) { AppPaths.LogCrash("pad " + path + ": " + error.Message); }
        finally
        {
            lock (_active) _active.Remove(path);
        }
    }
}
