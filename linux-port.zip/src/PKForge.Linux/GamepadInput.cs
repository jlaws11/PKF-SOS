namespace PKForge.Linux;

internal enum PadButton { Up, Down, Left, Right, A, B, X, Y, L1, R1, Start, Select }

/// <summary>
/// Reads game controllers straight from Linux's joystick devices (/dev/input/js*), so the Steam Deck's
/// buttons work without any extra libraries. Raises <see cref="Pressed"/> on a background thread; the window
/// moves it to the UI thread. Held directions repeat. Everything is best effort: no device, no problem.
/// </summary>
internal sealed class GamepadInput
{
    public event Action<PadButton>? Pressed;

    private readonly HashSet<string> _active = [];
    private readonly CancellationTokenSource _cts = new();

    public void Start() => _ = Task.Run(WatchAsync);

    public void Stop() => _cts.Cancel();

    private async Task WatchAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                if (Directory.Exists("/dev/input"))
                {
                    foreach (var path in Directory.GetFiles("/dev/input", "js*"))
                    {
                        lock (_active)
                        {
                            if (!_active.Add(path)) continue;
                        }
                        var device = path;
                        _ = Task.Factory.StartNew(() => Read(device), TaskCreationOptions.LongRunning);
                    }
                }
            }
            catch (Exception) { /* no controller support on this machine */ }
            try { await Task.Delay(3000, _cts.Token); } catch (OperationCanceledException) { return; }
        }
    }

    private void Read(string path)
    {
        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1, false);
            var buffer = new byte[8];
            int hatX = 0, hatY = 0, stickX = 0, stickY = 0;
            PadButton? held = null;
            CancellationTokenSource? repeat = null;

            void Recompute()
            {
                PadButton? next = null;
                if (hatY < 0) next = PadButton.Up;
                else if (hatY > 0) next = PadButton.Down;
                else if (hatX < 0) next = PadButton.Left;
                else if (hatX > 0) next = PadButton.Right;
                else if (Math.Abs(stickY) > Math.Abs(stickX) && Math.Abs(stickY) > 0) next = stickY < 0 ? PadButton.Up : PadButton.Down;
                else if (stickX != 0) next = stickX < 0 ? PadButton.Left : PadButton.Right;
                if (next == held) return;
                repeat?.Cancel();
                held = next;
                if (next is not { } direction) return;
                Pressed?.Invoke(direction);
                var source = repeat = new CancellationTokenSource();
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(380, source.Token);
                        while (!source.IsCancellationRequested)
                        {
                            Pressed?.Invoke(direction);
                            await Task.Delay(110, source.Token);
                        }
                    }
                    catch (OperationCanceledException) { }
                });
            }

            while (stream.Read(buffer, 0, 8) == 8)
            {
                var value = BitConverter.ToInt16(buffer, 4);
                var isInitial = (buffer[6] & 0x80) != 0;
                var type = buffer[6] & 0x7F;
                var number = buffer[7];
                if (type == 1 && !isInitial && value == 1)
                {
                    PadButton? button = number switch
                    {
                        0 => PadButton.A,
                        1 => PadButton.B,
                        2 => PadButton.X,
                        3 => PadButton.Y,
                        4 => PadButton.L1,
                        5 => PadButton.R1,
                        6 => PadButton.Select,
                        7 => PadButton.Start,
                        _ => null,
                    };
                    if (button is { } pressed) Pressed?.Invoke(pressed);
                }
                else if (type == 2)
                {
                    switch (number)
                    {
                        case 6: hatX = Math.Sign(value); Recompute(); break;
                        case 7: hatY = Math.Sign(value); Recompute(); break;
                        case 0: stickX = Math.Abs((int)value) > 16000 ? Math.Sign(value) : 0; Recompute(); break;
                        case 1: stickY = Math.Abs((int)value) > 16000 ? Math.Sign(value) : 0; Recompute(); break;
                    }
                }
            }
            repeat?.Cancel();
        }
        catch (Exception) { /* unplugged or not readable: the next scan tries again */ }
        finally
        {
            lock (_active) _active.Remove(path);
        }
    }
}
