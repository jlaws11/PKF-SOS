using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Restore points: every write PKForge makes keeps a copy of the save as it was just before. Pick a save,
/// pick a point, and put it back. The state you restore over is itself kept as a new restore point.
/// </summary>
public sealed class RestorePage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;

    private Workbench? _bench;
    private List<BackupInfo> _points = [];
    private BackupInfo? _picked;
    private bool _confirm;
    private bool _busy;
    private string _note = "";

    public RestorePage(ContentControl host, Action close)
    {
        _host = host;
        _close = close;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_confirm) { _confirm = false; Render(); return; }
        if (_bench is null) { _close(); return; }
        _bench = null;
        _picked = null;
        Start();
    }

    public void Start()
    {
        _host.Content = Workbench.Frame("Restore Points", _close,
            Workbench.SavePicker("Which save do you want to look at the restore points of?", _ => true,
                "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Restore Points", Escape, Ui.Text("Looking for restore points…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            await LoadAsync();
            _picked = null;
            _confirm = false;
            _note = _bench.Refusal ?? "";
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Restore Points", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private async Task LoadAsync()
    {
        var snapshot = _bench!.Session.Snapshot;
        var all = await Svc.Backups.ListAsync();
        _points = [.. all.Where(b => b.BelongsTo(_bench.Save.DocumentId, snapshot)).OrderByDescending(b => b.CreatedUtc)];
    }

    private void Render()
    {
        var bench = _bench!;
        var rows = new StackPanel { Spacing = 6 };
        if (_points.Count == 0)
            rows.Children.Add(Ui.Text("No restore points yet. One is made automatically before every change PKForge writes.", 18, false, Ui.Dim));
        foreach (var point in _points)
        {
            var chosen = point;
            var text = new StackPanel();
            text.Children.Add(Ui.Text(point.CreatedUtc.ToLocalTime().ToString("ddd d MMM yyyy, HH:mm"), 18, true));
            text.Children.Add(Ui.Text(string.IsNullOrWhiteSpace(point.ChangeDescription) ? "Before a change" : "Before: " + point.ChangeDescription, 14, false, Ui.Dim));
            var on = _picked?.BackupId == point.BackupId;
            var button = new Button
            {
                Content = text,
                MinHeight = 62,
                Padding = new Thickness(12, 6),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Background = on ? Ui.PanelHi : Ui.Panel,
                BorderBrush = on ? Ui.Accent : Ui.Clear,
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
            };
            button.Click += (_, _) => { _picked = chosen; _confirm = false; _note = ""; Render(); };
            rows.Children.Add(button);
        }

        var side = new StackPanel { Spacing = 10 };
        if (_picked is { } p)
        {
            side.Children.Add(Ui.Text("This restore point", 22, true));
            side.Children.Add(Ui.Text(p.CreatedUtc.ToLocalTime().ToString("d MMM yyyy, HH:mm"), 18, false, Ui.Gold));
            if (!string.IsNullOrWhiteSpace(p.ChangeDescription)) side.Children.Add(Ui.Text("Made before: " + p.ChangeDescription, 16));
            side.Children.Add(Ui.Text($"{p.Format}, Gen {p.Generation}, {p.SizeBytes / 1024} KB", 15, false, Ui.Dim));
            if (_confirm)
            {
                side.Children.Add(Ui.Text("Put your save back to how it was then? Everything you changed since is undone. The state right now is kept as a new restore point first.", 16, false, Ui.Warn));
                var yes = Ui.Btn("Yes, restore it", () => _ = RestoreAsync(p), primary: true);
                var no = Ui.Btn("No", () => { _confirm = false; Render(); });
                var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
                row.Children.Add(yes);
                row.Children.Add(no);
                side.Children.Add(row);
            }
            else
            {
                var restore = Ui.Btn("Restore this one…", () => { _confirm = true; Render(); }, primary: true);
                restore.IsEnabled = bench.Refusal is null && !_busy;
                side.Children.Add(restore);
            }
        }
        else
        {
            side.Children.Add(Ui.Text("Pick a restore point", 22, true));
            side.Children.Add(Ui.Text("Newest first. Close the emulator before you restore, or it can overwrite the result.", 16, false, Ui.Dim));
        }
        side.Children.Add(Ui.Text(_busy ? "Restoring…" : _note, 16, false, Ui.Warn));

        var panel = new Border
        {
            Width = 380,
            Padding = new Thickness(18),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = side },
        };
        var body = new DockPanel();
        DockPanel.SetDock(panel, Dock.Right);
        body.Children.Add(panel);
        body.Children.Add(new ScrollViewer { Content = rows, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });
        _host.Content = Workbench.Frame($"Restore Points · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape, body);
    }

    private async Task RestoreAsync(BackupInfo point)
    {
        if (_bench is null || _busy) return;
        _busy = true;
        _confirm = false;
        Render();
        try
        {
            var bytes = (await Svc.Backups.ReadAsync(point.BackupId)).ToArray();
            _note = await _bench.RestoreAsync(bytes);
            await LoadAsync();
        }
        catch (Exception error)
        {
            _note = "Restore stopped: " + error.Message;
        }
        _busy = false;
        Render();
    }
}
