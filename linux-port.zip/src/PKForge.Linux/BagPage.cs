using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The bag editor: pick a save, pick a pocket, change counts, add or remove items, then Save.
/// Counts are clamped to what that game allows. Nothing is written until Save.
/// </summary>
public sealed class BagPage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;

    private Workbench? _bench;
    private IReadOnlyList<string> _names = [];
    private string? _pouch;
    private bool _dirty;
    private bool _confirmDiscard;
    private bool _adding;
    private string _search = "";
    private string _note = "";

    public BagPage(ContentControl host, Action close)
    {
        _host = host;
        _close = close;
    }

    public IReadOnlyList<(string Button, string Label)> PadHints =>
        _bench is null ? [] : _adding ? [] : [("L1 / R1", "Pocket"), ("X", "Save")];

    public bool OnKey(Key key)
    {
        if (_bench is null || _adding) return false;
        if (key == Key.PageUp || key == Key.PageDown)
        {
            var bag = _bench.Session.GetBag();
            var at = Math.Max(0, bag.ToList().FindIndex(p => p.Name == _pouch));
            _pouch = bag[(at + (key == Key.PageDown ? 1 : bag.Count - 1)) % bag.Count].Name;
            _note = "";
            Render();
            return true;
        }
        if (key == Key.X && _dirty && _bench.Refusal is null) { _ = SaveAsync(); return true; }
        return false;
    }

    public void Escape()
    {
        if (_adding) { _adding = false; Render(); return; }
        if (_bench is null) { _close(); return; }
        if (_dirty && !_confirmDiscard)
        {
            _confirmDiscard = true;
            _note = "You have unsaved changes. Press Back again to throw them away, or tap Save.";
            Render();
            return;
        }
        _bench = null;
        _dirty = false;
        _confirmDiscard = false;
        Start();
    }

    // ───────────────────────── choose a save ─────────────────────────

    public void Start()
    {
        _host.Content = Workbench.Frame("Bag", _close,
            Workbench.SavePicker("Which save's bag do you want to edit?", _ => true,
                "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Bag", Escape, Ui.Text("Opening the bag…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            _names = _bench.Session.GetItemNames();
            _pouch = _bench.Session.GetBag().FirstOrDefault()?.Name;
            _dirty = false;
            _confirmDiscard = false;
            _adding = false;
            _note = _bench.Refusal ?? "";
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Bag", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    // ───────────────────────── the bag ─────────────────────────

    private string Name(int id) => id > 0 && id < _names.Count && _names[id].Length > 0 ? _names[id] : "Item " + id;

    private static string Pretty(string pouch)
    {
        var text = System.Text.RegularExpressions.Regex.Replace(pouch, "(?<=[a-z])(?=[A-Z])", " ");
        return text.Replace("T M H Ms", "TMs & HMs");
    }

    private void Render()
    {
        var bench = _bench!;
        var session = bench.Session;
        var bag = session.GetBag();
        if (bag.Count == 0)
        {
            _host.Content = Workbench.Frame("Bag", Escape, Ui.Text("This game has no bag the editor can read.", 20, false, Ui.Warn));
            return;
        }
        if (_pouch is null || bag.All(p => p.Name != _pouch)) _pouch = bag[0].Name;
        var pouch = bag.First(p => p.Name == _pouch);

        var body = new DockPanel();

        var tabs = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        foreach (var p in bag)
        {
            var name = p.Name;
            var tab = Ui.Btn($"{Pretty(name)} ({p.Items.Count})", () =>
            {
                _pouch = name; _adding = false; _search = ""; _note = ""; _confirmDiscard = false; Render();
            }, primary: name == _pouch);
            tab.MinWidth = 0;
            tab.MinHeight = 46;
            tab.FontSize = 16;
            tab.Padding = new Thickness(12, 4);
            tab.Margin = new Thickness(0, 0, 8, 8);
            tabs.Children.Add(tab);
        }
        DockPanel.SetDock(tabs, Dock.Top);
        body.Children.Add(tabs);

        // bottom bar
        var bar = new DockPanel { Margin = new Thickness(0, 10, 0, 0) };
        var save = Ui.Btn("Save to the game", () => _ = SaveAsync(), primary: true);
        save.IsEnabled = _dirty && bench.Refusal is null;
        DockPanel.SetDock(save, Dock.Right);
        bar.Children.Add(save);
        var add = Ui.Btn("+ Add item", () => { _adding = true; _search = ""; Render(); });
        add.IsEnabled = bench.Refusal is null;
        add.Margin = new Thickness(0, 0, 12, 0);
        DockPanel.SetDock(add, Dock.Left);
        bar.Children.Add(add);
        bar.Children.Add(Ui.Text(_note, 15, false, Ui.Warn));
        DockPanel.SetDock(bar, Dock.Bottom);
        body.Children.Add(bar);

        body.Children.Add(_adding ? AddPanel(session, pouch) : ItemList(session, pouch));
        _host.Content = Workbench.Frame($"Bag · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape, body);
    }

    private Control ItemList(ISaveEngineSession session, BagPouch pouch)
    {
        var rows = new StackPanel { Spacing = 6 };
        if (pouch.Items.Count == 0)
            rows.Children.Add(Ui.Text("Nothing in this pocket. Use + Add item.", 18, false, Ui.Dim));
        foreach (var item in pouch.Items)
        {
            var id = item.Id;
            var count = Ui.Text(item.Count.ToString(), 22, true, Ui.Gold);
            count.MinWidth = 70;
            count.TextAlignment = TextAlignment.Center;
            count.VerticalAlignment = VerticalAlignment.Center;
            var current = item.Count;

            Button Step(string label, int delta)
            {
                var b = Ui.Btn(label, () => Change(session, pouch.Name, id, current + delta, count, v => current = v));
                b.MinWidth = 0; b.MinHeight = 46; b.FontSize = 16; b.Padding = new Thickness(10, 2);
                return b;
            }

            var controls = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
            controls.Children.Add(Step("−10", -10));
            controls.Children.Add(Step("−1", -1));
            controls.Children.Add(count);
            controls.Children.Add(Step("+1", 1));
            controls.Children.Add(Step("+10", 10));
            var max = Ui.Btn("Max", () => Change(session, pouch.Name, id, 999, count, v => current = v));
            max.MinWidth = 0; max.MinHeight = 46; max.FontSize = 16; max.Padding = new Thickness(10, 2);
            controls.Children.Add(max);
            var remove = Ui.Btn("Remove", () =>
            {
                try { session.SetItemCount(pouch.Name, id, 0); _dirty = true; _note = ""; _confirmDiscard = false; }
                catch (Exception error) { _note = error.Message; }
                Render();
            });
            remove.MinWidth = 0; remove.MinHeight = 46; remove.FontSize = 16; remove.Padding = new Thickness(10, 2);
            controls.Children.Add(remove);
            DockPanel.SetDock(controls, Dock.Right);

            var row = new DockPanel { Margin = new Thickness(4, 2) };
            row.Children.Add(controls);
            var label = Ui.Text(Name(id), 18);
            label.VerticalAlignment = VerticalAlignment.Center;
            row.Children.Add(label);
            rows.Children.Add(new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(6), Padding = new Thickness(10, 4), Child = row });
        }
        return new ScrollViewer { Content = rows, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled };
    }

    private void Change(ISaveEngineSession session, string pouch, int id, int wanted, TextBlock label, Action<int> store)
    {
        try
        {
            var stored = session.SetItemCount(pouch, id, Math.Max(0, wanted));
            _dirty = true;
            _confirmDiscard = false;
            _note = "";
            if (stored <= 0) { Render(); return; }
            label.Text = stored.ToString();
            store(stored);
        }
        catch (Exception error)
        {
            _note = error.Message;
            Render();
        }
    }

    private Control AddPanel(ISaveEngineSession session, BagPouch pouch)
    {
        var have = pouch.Items.Select(i => i.Id).ToHashSet();
        var legal = session.GetPouchLegalItems(pouch.Name).Where(id => id > 0 && !have.Contains(id)).ToList();

        var search = new TextBox { Text = _search, MinHeight = 46, FontSize = 18, Margin = new Thickness(0, 0, 0, 8) };
        var rows = new StackPanel { Spacing = 6 };
        void Fill()
        {
            rows.Children.Clear();
            var terms = _search.ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var matches = legal.Where(id => terms.All(t => Name(id).ToLowerInvariant().Contains(t))).ToList();
            foreach (var id in matches.Take(60))
            {
                var chosen = id;
                var b = Ui.Btn(Name(id), () =>
                {
                    try
                    {
                        var stored = session.SetItemCount(pouch.Name, chosen, 1);
                        _dirty = true; _adding = false; _confirmDiscard = false;
                        _note = $"Added {Name(chosen)} ×{stored}.";
                    }
                    catch (Exception error) { _note = error.Message; _adding = false; }
                    Render();
                });
                b.HorizontalAlignment = HorizontalAlignment.Stretch;
                b.HorizontalContentAlignment = HorizontalAlignment.Left;
                b.MinHeight = 48;
                b.FontSize = 18;
                rows.Children.Add(b);
            }
            if (matches.Count == 0) rows.Children.Add(Ui.Text("No matching item.", 18, false, Ui.Dim));
            else if (matches.Count > 60) rows.Children.Add(Ui.Text($"Showing 60 of {matches.Count}. Type to narrow it down.", 15, false, Ui.Dim));
        }
        search.PropertyChanged += (_, e) =>
        {
            if (e.Property != TextBox.TextProperty) return;
            _search = search.Text ?? "";
            Fill();
        };
        Fill();

        var panel = new DockPanel();
        var title = Ui.Text($"Add to {Pretty(pouch.Name)} (Back to cancel)", 18, false, Ui.Dim);
        DockPanel.SetDock(title, Dock.Top);
        panel.Children.Add(title);
        DockPanel.SetDock(search, Dock.Top);
        panel.Children.Add(search);
        panel.Children.Add(new ScrollViewer { Content = rows });
        return panel;
    }

    private async Task SaveAsync()
    {
        var bench = _bench;
        if (bench is null) return;
        try
        {
            _note = await bench.CommitAsync("Edited the bag in PKForge");
            _dirty = false;
            _confirmDiscard = false;
        }
        catch (Exception error)
        {
            _note = "Could not save: " + error.Message;
        }
        Render();
    }
}
