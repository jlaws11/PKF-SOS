using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The Bank: the vault the Living Dex Autopilot fills. Browse its boxes, and send a Pokémon back
/// into a game save. Sending shows a preview first (what the conversion changes, whether the
/// result is legal), writes to the game with a restore point, and only then takes it out of the Bank.
/// </summary>
public sealed class BankPage : IScreen
{
    private const int Columns = 6;

    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;

    private int _box;
    private Guid? _selected;

    public BankPage(ContentControl host, SpriteStore sprites, Action close)
    {
        _host = host;
        _sprites = sprites;
        _close = close;
    }

    public void Escape() => _close();

    public bool OnKey(Key key)
    {
        switch (key)
        {
            case Key.Left:
            case Key.PageUp:
                Go(-1);
                return true;
            case Key.Right:
            case Key.PageDown:
                Go(1);
                return true;
            default:
                return false;
        }
    }

    private int BoxCount => Math.Max(1, Svc.Bank.BoxCount);

    private void Go(int delta)
    {
        _box = (_box + delta + BoxCount) % BoxCount;
        _selected = null;
        ShowBox();
    }

    // ───────────────────────── the box view ─────────────────────────

    public void Start() => ShowBox();

    private void ShowBox()
    {
        if (_box >= BoxCount) _box = 0;
        var entries = Svc.Bank.GetAll();
        var inBox = entries.Where(e => e.Box == _box).ToDictionary(e => e.Slot);
        var selected = _selected is { } id ? entries.FirstOrDefault(e => e.Id == id) : null;

        var grid = new UniformGrid { Columns = Columns };
        for (var slot = 0; slot < IBankService.SlotsPerBox; slot++)
        {
            inBox.TryGetValue(slot, out var entry);
            grid.Children.Add(Tile(entry, entry is not null && entry.Id == _selected));
        }

        var detail = new StackPanel { Spacing = 10 };
        if (selected is null)
        {
            detail.Children.Add(Ui.Text($"{entries.Count} Pokémon in the Bank.", 20, true));
            detail.Children.Add(Ui.Text("Tap a Pokémon to see it, or to send it back into a game.", 18, false, Ui.Dim));
        }
        else
        {
            FillDetail(detail, selected);
        }

        var back = Ui.Btn("‹ Home", _close);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(back);
        header.Children.Add(Ui.Text("Bank", 32, true));
        DockPanel.SetDock(header, Dock.Top);

        var prev = Ui.Btn("‹ Prev", () => Go(-1));
        DockPanel.SetDock(prev, Dock.Left);
        var next = Ui.Btn("Next ›", () => Go(1));
        DockPanel.SetDock(next, Dock.Right);
        var label = Ui.Text($"Box {_box + 1} of {BoxCount}", 24, true);
        label.HorizontalAlignment = HorizontalAlignment.Center;
        label.VerticalAlignment = VerticalAlignment.Center;
        var nav = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        nav.Children.Add(prev);
        nav.Children.Add(next);
        nav.Children.Add(label);
        DockPanel.SetDock(nav, Dock.Top);

        var side = new Border
        {
            Width = 380,
            Padding = new Thickness(20),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = detail },
        };
        DockPanel.SetDock(side, Dock.Right);

        var root = new DockPanel { Margin = new Thickness(24) };
        root.Children.Add(header);
        root.Children.Add(nav);
        root.Children.Add(side);
        root.Children.Add(grid);
        _host.Content = root;
    }

    private void FillDetail(StackPanel detail, BankEntry entry)
    {
        var info = entry.Info;
        if (_sprites.Get(info.Look) is { } sprite)
        {
            detail.Children.Add(new Image
            {
                Source = sprite,
                Width = 260,
                Height = 220,
                Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Center,
            });
        }
        detail.Children.Add(Ui.Text(Svc.SpeciesName(info.Species), 30, true));
        if (!string.IsNullOrWhiteSpace(info.Nickname) && info.Nickname != Svc.SpeciesName(info.Species))
            detail.Children.Add(Ui.Text("Nickname: " + info.Nickname, 20));
        detail.Children.Add(Ui.Text($"Level {info.Level} · from Generation {info.Generation}", 18, false, Ui.Dim));
        if (info.Form > 0)
            detail.Children.Add(Ui.Text("Form: " + LivingDexCatalogBuilder.FormName(info.Species, info.Form), 18, false, Ui.Dim));
        if (info.Shiny)
            detail.Children.Add(Ui.Text("★ Shiny", 20, true, Ui.Gold));
        if (!string.IsNullOrWhiteSpace(info.SourceName))
            detail.Children.Add(Ui.Text("Came from: " + info.SourceName, 16, false, Ui.Dim));
        detail.Children.Add(Ui.Text($"Box {entry.Box + 1}, slot {entry.Slot + 1}", 16, false, Ui.Dim));
        detail.Children.Add(Ui.Btn("Send to a game…", () => ShowChooser(entry), primary: true));
    }

    private Control Tile(BankEntry? entry, bool selected)
    {
        var content = new Grid();
        if (entry is not null)
        {
            if (_sprites.Get(entry.Info.Look) is { } sprite)
                content.Children.Add(new Image { Source = sprite, Stretch = Stretch.Uniform, Margin = new Thickness(4) });
            else
            {
                var name = Ui.Text(Svc.SpeciesName(entry.Info.Species), 13, false, Ui.Dim);
                name.HorizontalAlignment = HorizontalAlignment.Center;
                name.VerticalAlignment = VerticalAlignment.Center;
                content.Children.Add(name);
            }
            if (entry.Info.Shiny)
            {
                var star = Ui.Text("★", 18, true, Ui.Gold);
                star.HorizontalAlignment = HorizontalAlignment.Right;
                star.VerticalAlignment = VerticalAlignment.Top;
                star.Margin = new Thickness(0, 2, 6, 0);
                content.Children.Add(star);
            }
        }

        var button = new Button
        {
            Content = content,
            Height = 104,
            Margin = new Thickness(3),
            Padding = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalContentAlignment = VerticalAlignment.Stretch,
            Background = selected ? Ui.PanelHi : Ui.Panel,
            BorderBrush = selected ? Ui.Accent : Ui.Clear,
            BorderThickness = new Thickness(selected ? 3 : 1),
            CornerRadius = new CornerRadius(8),
        };
        if (entry is not null)
        {
            var id = entry.Id;
            button.Click += (_, _) =>
            {
                _selected = id;
                ShowBox();
            };
        }
        return button;
    }

    // ───────────────────────── send to a game ─────────────────────────

    private void ShowChooser(BankEntry entry)
    {
        var saves = Shelf.All;
        var body = new StackPanel { Spacing = 12 };
        body.Children.Add(Ui.Text($"Send {Svc.SpeciesName(entry.Info.Species)} to which game?", 26, true));
        body.Children.Add(Ui.Text(
            "It goes into the first empty box slot. You will see what the conversion changes before anything is written.",
            18, false, Ui.Dim));

        if (saves.Count == 0)
            body.Children.Add(Ui.Text("No saves found. Add a folder with saves on the home screen first.", 20, false, Ui.Warn));

        foreach (var save in saves.Where(s => s.Format == SaveFormat.Standard || s.Format == SaveFormat.Auto))
        {
            var target = save;
            var line = string.Join(" · ", new[] { target.TrainerName, target.PlayTime }.Where(x => !string.IsNullOrWhiteSpace(x)));
            var text = new StackPanel { Spacing = 2 };
            text.Children.Add(Ui.Text(target.GameLabel, 22, true));
            text.Children.Add(Ui.Text(line, 16, false, Ui.Dim));
            var button = new Button
            {
                Content = text,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                MinHeight = 72,
                Padding = new Thickness(18, 10),
                Background = Ui.Panel,
                CornerRadius = new CornerRadius(10),
            };
            button.Click += (_, _) => _ = PreviewAsync(entry, target);
            body.Children.Add(button);
        }

        body.Children.Add(Ui.Btn("‹ Back", ShowBox));
        Page("Send to a game", body);
    }

    private async Task PreviewAsync(BankEntry entry, DetectedSave target)
    {
        Page("Send to a game", Ui.Text("Checking what the conversion would change…", 22));
        try
        {
            var data = Svc.Bank.GetData(entry.Id);
            var nickname = NameOf(entry);
            var outcome = await Svc.Transfers.PreviewAsync(data, nickname, target, CancellationToken.None, entry.Info.Format);
            if (!outcome.Success || outcome.Preview is null)
            {
                Page("Send to a game", Message(outcome.Message, () => ShowChooser(entry)));
                return;
            }
            ShowPreview(entry, target, outcome);
        }
        catch (Exception error)
        {
            Page("Send to a game", Message("Could not check: " + error.Message, () => ShowChooser(entry)));
        }
    }

    private void ShowPreview(BankEntry entry, DetectedSave target, TransferPreviewOutcome outcome)
    {
        var preview = outcome.Preview!;
        var body = new StackPanel { Spacing = 12 };
        body.Children.Add(Ui.Text(outcome.Message, 24, true));
        body.Children.Add(Ui.Text(preview.Verdict, 20, true,
            preview.Legality == TransferLegality.Legal ? Ui.Gold : Ui.Warn));

        if (preview.Changes.Count > 0)
        {
            body.Children.Add(Ui.Text("What changes", 22, true));
            body.Children.Add(Lines(preview.Changes));
        }
        if (preview.Warnings.Count > 0)
        {
            body.Children.Add(Ui.Text("Warnings", 22, true, Ui.Warn));
            body.Children.Add(Lines(preview.Warnings));
        }
        if (preview.LegalityLines.Count > 0)
        {
            body.Children.Add(Ui.Text("Legality notes", 22, true));
            body.Children.Add(Lines(preview.LegalityLines));
        }
        if (Shelf.Caution(target) is { } caution)
            body.Children.Add(Ui.Text("⚠ " + caution, 18, false, Ui.Warn));

        body.Children.Add(Ui.Text(
            "A restore point of the game save is made first. Close the emulator before you confirm.", 16, false, Ui.Dim));
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        actions.Children.Add(Ui.Btn("‹ Cancel", () => ShowChooser(entry)));
        actions.Children.Add(Ui.Btn("Send it", () => _ = SendAsync(entry, target), primary: true));
        body.Children.Add(actions);
        Page("Send to a game", body);
    }

    private async Task SendAsync(BankEntry entry, DetectedSave target)
    {
        Page("Send to a game", Ui.Text("Writing to the game…", 22));
        try
        {
            var data = Svc.Bank.GetData(entry.Id);
            var outcome = await Svc.Transfers.SendToGameAsync(data, NameOf(entry), target, CancellationToken.None, entry.Info.Format);
            if (!outcome.Success)
            {
                Page("Send to a game", Message("Nothing was changed. " + outcome.Message, () => ShowChooser(entry)));
                return;
            }

            // The game has it now. Only then does the Bank let go, so a failure here can duplicate, never lose.
            string tail;
            try
            {
                Svc.Bank.Remove(entry.Id);
                tail = "It has been taken out of the Bank.";
            }
            catch (Exception error)
            {
                tail = "But it could not be removed from the Bank (" + error.Message + "), so it is in both places.";
            }
            _selected = null;
            var body = new StackPanel { Spacing = 16 };
            body.Children.Add(Ui.Text("Sent!", 30, true, Ui.Gold));
            body.Children.Add(Ui.Text(outcome.Message + " " + tail, 20));
            if (outcome.BackupId is not null)
                body.Children.Add(Ui.Text("A restore point of the game save was made first (~/.local/share/PKForge/backups).", 16, false, Ui.Dim));
            body.Children.Add(Ui.Btn("Back to the Bank", ShowBox, primary: true));
            Page("Send to a game", body);
        }
        catch (Exception error)
        {
            Page("Send to a game", Message(
                "Nothing was changed: " + error.Message, () => ShowChooser(entry)));
        }
    }

    // ───────────────────────── helpers ─────────────────────────

    private static string NameOf(BankEntry entry) =>
        string.IsNullOrWhiteSpace(entry.Info.Nickname) ? Svc.SpeciesName(entry.Info.Species) : entry.Info.Nickname;

    private static Control Lines(IReadOnlyList<string> lines)
    {
        var list = new StackPanel { Spacing = 4 };
        foreach (var line in lines.Take(40))
            list.Children.Add(Ui.Text("• " + line, 16));
        return new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(10), Padding = new Thickness(16, 12), Child = list };
    }

    private static Control Message(string text, Action back)
    {
        var panel = new StackPanel { Spacing = 16 };
        panel.Children.Add(Ui.Text(text, 20, false, Ui.Warn));
        panel.Children.Add(Ui.Btn("‹ Back", back));
        return panel;
    }

    private void Page(string title, Control body)
    {
        var back = Ui.Btn("‹ Bank", ShowBox);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 16) };
        header.Children.Add(back);
        header.Children.Add(Ui.Text(title, 32, true));
        DockPanel.SetDock(header, Dock.Top);

        var root = new DockPanel { Margin = new Thickness(28, 20) };
        root.Children.Add(header);
        root.Children.Add(new ScrollViewer
        {
            Content = body,
            HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled,
        });
        _host.Content = root;
    }
}
