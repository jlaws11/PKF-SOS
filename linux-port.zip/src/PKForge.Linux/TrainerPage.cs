using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The trainer card: name, IDs, gender, money, play time, and (where the game keeps them) Battle Points and coins.
/// Nothing is written until Save; Save makes a restore point first.
/// </summary>
public sealed class TrainerPage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;

    private Workbench? _bench;
    private string _note = "";
    private bool _noteIsError;

    private TextBox _name = null!, _tid = null!, _sid = null!, _money = null!, _hours = null!, _minutes = null!, _bp = null!, _coins = null!;
    private int _gender;

    public TrainerPage(ContentControl host, Action close)
    {
        _host = host;
        _close = close;
    }

    public void Escape()
    {
        if (_bench is null) { _close(); return; }
        _bench = null;
        Start();
    }

    public void Start()
    {
        _host.Content = Workbench.Frame("Trainer Card", _close,
            Workbench.SavePicker("Which save's trainer card do you want to edit?", _ => true,
                "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Trainer Card", Escape, Ui.Text("Opening the trainer card…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            _note = _bench.Refusal ?? "";
            _noteIsError = _bench.Refusal is not null;
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Trainer Card", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private TextBox Box(string text, bool enabled = true) => new()
    {
        Text = text,
        FontSize = 20,
        MinHeight = 50,
        MinWidth = 260,
        IsEnabled = enabled,
        VerticalContentAlignment = VerticalAlignment.Center,
    };

    private void Render()
    {
        var bench = _bench!;
        var session = bench.Session;
        var trainer = session.GetTrainer();
        var stats = session.GetTrainerStats();
        var editable = bench.Refusal is null;
        _gender = trainer.Gender;

        _name = Box(trainer.Name, editable);
        _tid = Box(trainer.TID.ToString(), editable);
        _sid = Box(trainer.SID.ToString(), editable);
        _money = Box(trainer.Money.ToString(), editable);
        _hours = Box(stats.PlayTimeHours.ToString(), editable);
        _minutes = Box(stats.PlayTimeMinutes.ToString(), editable);
        _bp = Box(stats.BP.ToString(), editable);
        _coins = Box(stats.Coins.ToString(), editable);

        var form = new StackPanel { Spacing = 10, MaxWidth = 720 };
        void Row(string label, Control field, string? hint = null)
        {
            var row = new DockPanel { Margin = new Thickness(0, 2) };
            var text = Ui.Text(label, 20);
            text.Width = 220;
            text.VerticalAlignment = VerticalAlignment.Center;
            DockPanel.SetDock(text, Dock.Left);
            row.Children.Add(text);
            var right = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
            right.Children.Add(field);
            if (hint is not null)
            {
                var h = Ui.Text(hint, 14, false, Ui.Dim);
                h.VerticalAlignment = VerticalAlignment.Center;
                right.Children.Add(h);
            }
            row.Children.Add(right);
            form.Children.Add(row);
        }

        Row("Name", _name);
        Row("Trainer ID (TID)", _tid, "0 to 65535");
        Row("Secret ID (SID)", _sid, "0 to 65535");

        var genderRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        Button male = null!, female = null!;
        void PaintGender()
        {
            male.Background = _gender == 0 ? Ui.Blue : Ui.PanelHi;
            female.Background = _gender == 1 ? Ui.Blue : Ui.PanelHi;
        }
        male = Ui.Btn("Boy", () => { _gender = 0; PaintGender(); });
        female = Ui.Btn("Girl", () => { _gender = 1; PaintGender(); });
        male.IsEnabled = female.IsEnabled = editable;
        male.MinWidth = female.MinWidth = 110;
        genderRow.Children.Add(male);
        genderRow.Children.Add(female);
        PaintGender();
        Row("Gender", genderRow);

        Row("Money", _money);
        if (stats.SupportsPlayTime)
        {
            Row("Play time hours", _hours, $"0 to {stats.PlayTimeHoursMax}");
            Row("Play time minutes", _minutes, "0 to 59");
        }
        if (stats.SupportsBP) Row("Battle Points", _bp, $"0 to {stats.BPMax}");
        if (stats.SupportsCoins) Row("Coins", _coins, $"0 to {stats.CoinsMax}");

        form.Children.Add(Ui.Text(
            "Changing the name or IDs does not change Pokémon you already own: they keep their original trainer.", 15, false, Ui.Dim));

        var save = Ui.Btn("Save to the game", () => _ = SaveAsync(stats), primary: true);
        save.IsEnabled = editable;
        save.HorizontalAlignment = HorizontalAlignment.Left;
        form.Children.Add(save);
        form.Children.Add(Ui.Text(_note, 16, false, _noteIsError ? Ui.Warn : Ui.Gold));

        _host.Content = Workbench.Frame($"Trainer Card · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape,
            new ScrollViewer { Content = form, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });
    }

    private bool Fail(string message)
    {
        _note = message;
        _noteIsError = true;
        return false;
    }

    private async Task SaveAsync(TrainerStats stats)
    {
        var bench = _bench;
        if (bench is null) return;
        try
        {
            var name = (_name.Text ?? "").Trim();
            if (name.Length == 0) { Fail("The name cannot be empty."); Render(); return; }
            if (!int.TryParse(_tid.Text?.Trim(), out var tid) || tid is < 0 or > 65535) { Fail("The Trainer ID must be a number from 0 to 65535."); Render(); return; }
            if (!int.TryParse(_sid.Text?.Trim(), out var sid) || sid is < 0 or > 65535) { Fail("The Secret ID must be a number from 0 to 65535."); Render(); return; }
            if (!uint.TryParse(_money.Text?.Trim(), out var money)) { Fail("Money must be a whole number."); Render(); return; }

            bench.Session.SetTrainer(new TrainerInfo(name, tid, sid, money, _gender));

            int? Num(TextBox box, bool supported)
            {
                if (!supported) return null;
                if (!int.TryParse(box.Text?.Trim(), out var value) || value < 0)
                    throw new InvalidOperationException("Play time, Battle Points and coins must be whole numbers.");
                return value;
            }
            bench.Session.SetTrainerStats(new TrainerStatsEdit(
                Num(_hours, stats.SupportsPlayTime), Num(_minutes, stats.SupportsPlayTime),
                Num(_bp, stats.SupportsBP), Num(_coins, stats.SupportsCoins)));

            _note = await bench.CommitAsync("Edited the trainer card in PKForge");
            _noteIsError = false;
        }
        catch (Exception error)
        {
            // An edit that failed half-way must not ride along with the next save.
            try { await bench.ReloadAsync(); } catch (Exception) { }
            _note = "Could not save: " + error.Message;
            _noteIsError = true;
        }
        Render();
    }
}
