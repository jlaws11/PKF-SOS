#!/usr/bin/env bash
# Turns the self-contained publish/ folder into PKForge-x86_64.AppImage.
set -euo pipefail

rm -rf AppDir
mkdir -p AppDir/usr/bin
cp -r publish/. AppDir/usr/bin/
chmod +x AppDir/usr/bin/PKForge

cp src/PKForge.App/Resources/AppIcon/pkforge.png AppDir/pkforge.png

cat > AppDir/pkforge.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=PKForge
Comment=Pokemon save editor and bank
Exec=PKForge
Icon=pkforge
Categories=Game;Utility;
Terminal=false
DESKTOP

cat > AppDir/AppRun <<'APPRUN'
#!/bin/sh
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/bin/PKForge" "$@"
APPRUN
chmod +x AppDir/AppRun

# appimagetool refuses files that other users could not read or run.
chmod -R a+rX AppDir
chmod a+rx AppDir/AppRun AppDir/usr/bin/PKForge

curl -fsSL -o appimagetool \
  https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage
chmod +x appimagetool
# GitHub's runners have no FUSE, so run the tool unpacked.
ARCH=x86_64 ./appimagetool --appimage-extract-and-run AppDir PKForge-x86_64.AppImage
ls -lh PKForge-x86_64.AppImage
